@echo off
cd /d "%~dp0"
python -m pip install --upgrade -r requirements.txt pyinstaller
python -m PyInstaller --noconfirm --onefile --windowed --name "DortressLocker" dortress_locker.py
echo.
echo Built: dist\DortressLocker.exe
pause
