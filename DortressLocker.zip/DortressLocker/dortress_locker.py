"""
Dortress Locker - black & gold desktop GUI
(c) Dortress Technologies Private Limited

Run:  python dortress_locker.py
"""
from __future__ import annotations

import math
import os
import queue
import sys
import threading
import time
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

import dortress_core as core

# ----------------------------------------------------------------- theme ----
BG = "#050507"
PANEL = "#0c0c11"
PANEL2 = "#13131a"
PANEL3 = "#1a1810"
LINE = "#2c2615"
GOLD = "#d4af37"
GOLD_HI = "#f6dc84"
GOLD_DIM = "#7d6420"
TEXT = "#ece6d2"
MUTED = "#8a8475"
RED = "#e5534b"
AMBER = "#e0a030"
GREEN = "#43c27a"

WIN = sys.platform.startswith("win")
FONT = "Segoe UI" if WIN else "Helvetica"
FONT_B = "Segoe UI Semibold" if WIN else "Helvetica"
MONO = "Consolas" if WIN else "Courier"
AUTO_LOCK_SECONDS = 10 * 60


def lerp_color(a: str, b: str, t: float) -> str:
    t = max(0.0, min(1.0, t))
    ca = [int(a[i:i + 2], 16) for i in (1, 3, 5)]
    cb = [int(b[i:i + 2], 16) for i in (1, 3, 5)]
    return "#%02x%02x%02x" % tuple(int(x + (y - x) * t) for x, y in zip(ca, cb))


# --------------------------------------------------------------- widgets ----
class GoldButton(tk.Label):
    STYLES = {
        "primary": (GOLD, "#0a0a0a", GOLD_HI),
        "ghost": (PANEL2, GOLD, PANEL3),
        "danger": ("#24100e", RED, "#3a1714"),
    }

    def __init__(self, master, text, command=None, kind="primary", size=10, **kw):
        bg, fg, hover = self.STYLES[kind]
        super().__init__(master, text=text, bg=bg, fg=fg, font=(FONT_B, size),
                         padx=kw.pop("padx", 18), pady=kw.pop("pady", 8), cursor="hand2",
                         highlightthickness=1, highlightbackground=GOLD_DIM if kind != "primary" else GOLD,
                         **kw)
        self._bg, self._fg, self._hover = bg, fg, hover
        self.command = command
        self.enabled = True
        self.bind("<Enter>", lambda e: self.enabled and self.config(bg=self._hover))
        self.bind("<Leave>", lambda e: self.config(bg=self._bg if self.enabled else PANEL2))
        self.bind("<Button-1>", self._click)

    def _click(self, _e=None):
        if self.enabled and self.command:
            self.command()

    def set_enabled(self, on: bool):
        self.enabled = on
        self.config(bg=self._bg if on else PANEL2, fg=self._fg if on else MUTED,
                    cursor="hand2" if on else "arrow")


class PasswordEntry(tk.Frame):
    """Password field masked with stars, with a reveal toggle."""

    def __init__(self, master, on_change=None, width=34):
        super().__init__(master, bg=PANEL2, highlightthickness=1,
                         highlightbackground=LINE, highlightcolor=GOLD)
        self.var = tk.StringVar()
        self.entry = tk.Entry(self, textvariable=self.var, show="*", width=width, bd=0,
                              bg=PANEL2, fg=GOLD_HI, insertbackground=GOLD,
                              font=(MONO, 13), relief="flat")
        self.entry.pack(side="left", fill="x", expand=True, padx=(10, 4), pady=8)
        self.eye = tk.Label(self, text="SHOW", bg=PANEL2, fg=MUTED, font=(FONT_B, 8),
                            cursor="hand2", padx=8)
        self.eye.pack(side="right")
        self.eye.bind("<Button-1>", self.toggle)
        self.entry.bind("<FocusIn>", lambda e: self.config(highlightbackground=GOLD))
        self.entry.bind("<FocusOut>", lambda e: self.config(highlightbackground=LINE))
        if on_change:
            self.var.trace_add("write", lambda *a: on_change(self.var.get()))

    def toggle(self, _e=None):
        hidden = self.entry.cget("show") == "*"
        self.entry.config(show="" if hidden else "*")
        self.eye.config(text="HIDE" if hidden else "SHOW", fg=GOLD if hidden else MUTED)

    def get(self) -> str:
        return self.var.get()

    def set(self, v: str):
        self.var.set(v)

    def clear(self):
        self.var.set("")


class StrengthMeter(tk.Frame):
    SEGMENTS = 24

    def __init__(self, master, width=360):
        super().__init__(master, bg=master.cget("bg"))
        self.w = width
        self.canvas = tk.Canvas(self, width=width, height=10, bg=self.cget("bg"),
                                highlightthickness=0)
        self.canvas.pack(anchor="w")
        row = tk.Frame(self, bg=self.cget("bg"))
        row.pack(fill="x", pady=(4, 2))
        self.label = tk.Label(row, text="Strength: —", bg=self.cget("bg"), fg=MUTED,
                              font=(FONT_B, 9))
        self.label.pack(side="left")
        self.bits = tk.Label(row, text="", bg=self.cget("bg"), fg=MUTED, font=(MONO, 9))
        self.bits.pack(side="right")
        chk = tk.Frame(self, bg=self.cget("bg"))
        chk.pack(fill="x")
        self.checks = {}
        names = {"digits": "10 numbers", "upper": "3 UPPER", "lower": "3 lower", "special": "4 special"}
        for k, txt in names.items():
            lb = tk.Label(chk, text="○ " + txt, bg=self.cget("bg"), fg=MUTED, font=(FONT, 9))
            lb.pack(side="left", padx=(0, 12))
            self.checks[k] = (lb, txt)
        self.update_pw("")

    def update_pw(self, pw: str):
        score, label, bits = core.password_strength(pw)
        c = self.canvas
        c.delete("all")
        seg_w = self.w / self.SEGMENTS
        lit = round(score / 100 * self.SEGMENTS)
        for i in range(self.SEGMENTS):
            t = i / (self.SEGMENTS - 1)
            col = lerp_color(RED, AMBER, t * 2) if t < 0.5 else lerp_color(GOLD, GREEN, (t - 0.5) * 2)
            c.create_rectangle(i * seg_w + 1, 0, (i + 1) * seg_w - 2, 10,
                               fill=col if i < lit else "#1d1d24", width=0)
        color = RED if score < 40 else AMBER if score < 60 else GOLD if score < 80 else GREEN
        self.label.config(text=f"Strength: {label}", fg=color if pw else MUTED)
        self.bits.config(text=f"~{bits:.0f} bits" if pw else "")
        for k, (have, need, ok) in core.policy_status(pw).items():
            lb, txt = self.checks[k]
            lb.config(text=("● " if ok else "○ ") + txt + f" ({have}/{need})",
                      fg=GREEN if ok else (MUTED if not pw else AMBER))


class GoldProgress(tk.Canvas):
    def __init__(self, master, height=14):
        super().__init__(master, height=height, bg=master.cget("bg"), highlightthickness=0)
        self.frac = 0.0
        self.h = height
        self.phase = 0
        self.bind("<Configure>", lambda e: self.redraw())
        self._animate()

    def set(self, frac: float):
        self.frac = max(0.0, min(1.0, frac))
        self.redraw()

    def redraw(self):
        self.delete("all")
        w = max(self.winfo_width(), 10)
        self.create_rectangle(0, 0, w, self.h, fill="#17161d", outline=LINE)
        fw = int(w * self.frac)
        if fw > 2:
            steps = 30
            for i in range(steps):
                x0 = fw * i / steps
                x1 = fw * (i + 1) / steps
                self.create_rectangle(x0, 1, x1 + 1, self.h - 1,
                                      fill=lerp_color(GOLD_DIM, GOLD_HI, i / steps), width=0)
            sx = (self.phase % 120) / 120 * fw
            self.create_rectangle(max(0, sx - 25), 1, min(fw, sx), self.h - 1,
                                  fill="#fff3c4", stipple="gray50", width=0)
            self.create_line(0, 2, fw, 2, fill="#fff1b8")

    def _animate(self):
        try:
            if not self.winfo_exists():
                return
            if 0 < self.frac < 1:
                self.phase += 3
                self.redraw()
            self.after(40, self._animate)
        except tk.TclError:
            pass


class Logo(tk.Canvas):
    """Animated hexagon shield with an orbiting gold spark."""

    def __init__(self, master, size=64, animate=True):
        super().__init__(master, width=size, height=size, bg=master.cget("bg"),
                         highlightthickness=0)
        self.s = size
        self.t = 0.0
        self.animate = animate
        self.draw()
        if animate:
            self.after(50, self.tick)

    def hex_points(self, r):
        cx = cy = self.s / 2
        pts = []
        for i in range(6):
            a = math.radians(60 * i - 90)
            pts += [cx + r * math.cos(a), cy + r * math.sin(a)]
        return pts

    def draw(self):
        self.delete("all")
        s = self.s
        r = s * 0.44
        self.create_polygon(self.hex_points(r), outline=GOLD_DIM, fill="", width=1)
        self.create_polygon(self.hex_points(r * 0.84), outline=GOLD, fill="#0e0c06", width=2)
        self.create_text(s / 2, s / 2 + 1, text="D", fill=GOLD_HI,
                         font=(FONT_B, int(s * 0.32), "bold"))
        a = self.t
        x = s / 2 + r * math.cos(a)
        y = s / 2 + r * math.sin(a)
        for k, rad in enumerate((5, 3.5, 2)):
            col = [GOLD_DIM, GOLD, "#fff6d0"][k]
            self.create_oval(x - rad, y - rad, x + rad, y + rad, fill=col, outline="")

    def tick(self):
        try:
            if not self.winfo_exists():
                return
            self.t += 0.09
            self.draw()
            self.after(50, self.tick)
        except tk.TclError:
            pass


def section_title(parent, title, sub=None):
    f = tk.Frame(parent, bg=BG)
    f.pack(fill="x", pady=(0, 14))
    tk.Label(f, text=title, bg=BG, fg=GOLD_HI, font=(FONT_B, 20)).pack(anchor="w")
    if sub:
        tk.Label(f, text=sub, bg=BG, fg=MUTED, font=(FONT, 10), justify="left",
                 wraplength=820).pack(anchor="w", pady=(2, 0))
    tk.Frame(f, bg=GOLD_DIM, height=1).pack(fill="x", pady=(10, 0))
    return f


def card(parent, title=None, **pack):
    outer = tk.Frame(parent, bg=PANEL, highlightthickness=1, highlightbackground=LINE)
    tk.Frame(outer, bg=GOLD, height=2).pack(fill="x")
    inner = tk.Frame(outer, bg=PANEL)
    inner.pack(fill="both", expand=True, padx=16, pady=14)
    if title:
        tk.Label(inner, text=title.upper(), bg=PANEL, fg=GOLD, font=(FONT_B, 9)).pack(anchor="w",
                                                                                      pady=(0, 8))
    if pack:
        outer.pack(**pack)
    return outer, inner


# ------------------------------------------------------------ job panel ----
class JobPanel(tk.Frame):
    """Shared UI for the Encrypt and Decrypt pages."""

    def __init__(self, master, app, mode: str):
        super().__init__(master, bg=BG)
        self.app, self.mode = app, mode
        self.targets: list[str] = []
        enc = mode == "encrypt"
        section_title(
            self,
            "Encrypt & Shred" if enc else "Decrypt & Restore",
            "AES-256-GCM, 4 MiB authenticated chunks, a unique key per file. Originals are "
            "overwritten with random data and deleted after encryption."
            if enc else
            "Every chunk is authenticated before the restored file replaces the locked one. "
            "Tampered or truncated files are rejected.",
        )
        bar = tk.Frame(self, bg=BG)
        bar.pack(fill="x")
        GoldButton(bar, "+  Add files", self.add_files, "ghost").pack(side="left")
        GoldButton(bar, "+  Add folder", self.add_folder, "ghost").pack(side="left", padx=8)
        GoldButton(bar, "Clear", self.clear, "ghost").pack(side="left")
        self.count_lbl = tk.Label(bar, text="0 items", bg=BG, fg=MUTED, font=(FONT, 10))
        self.count_lbl.pack(side="right")

        lf = tk.Frame(self, bg=PANEL2, highlightthickness=1, highlightbackground=LINE)
        lf.pack(fill="both", expand=True, pady=10)
        self.listbox = tk.Listbox(lf, bg=PANEL2, fg=TEXT, bd=0, highlightthickness=0,
                                  selectbackground=GOLD_DIM, selectforeground="#000",
                                  font=(MONO, 10), activestyle="none", height=7)
        sb = ttk.Scrollbar(lf, orient="vertical", command=self.listbox.yview,
                           style="Gold.Vertical.TScrollbar")
        self.listbox.config(yscrollcommand=sb.set)
        self.listbox.pack(side="left", fill="both", expand=True, padx=8, pady=6)
        sb.pack(side="right", fill="y")
        self.listbox.bind("<Delete>", self.remove_selected)

        opt = tk.Frame(self, bg=BG)
        opt.pack(fill="x")
        self.passes = tk.IntVar(value=1)
        if enc:
            tk.Label(opt, text="Shred passes", bg=BG, fg=MUTED, font=(FONT, 10)).pack(side="left")
            self.pass_btns = {}
            for n, lab in ((1, "1 · Fast"), (3, "3 · Strong"), (7, "7 · Paranoid")):
                b = tk.Label(opt, text=lab, font=(FONT_B, 9), padx=10, pady=4, cursor="hand2")
                b.pack(side="left", padx=(8, 0))
                b.bind("<Button-1>", lambda e, n=n: self.set_passes(n))
                self.pass_btns[n] = b
            self.set_passes(1)
        self.go = GoldButton(opt, "ENCRYPT  &  SHRED" if enc else "DECRYPT  &  RESTORE",
                             self.start, "primary", size=11, padx=26, pady=10)
        self.go.pack(side="right")
        self.cancel_btn = GoldButton(opt, "Cancel", self.app.cancel_job, "danger")
        self.cancel_btn.pack(side="right", padx=8)
        self.cancel_btn.set_enabled(False)

        pf = tk.Frame(self, bg=BG)
        pf.pack(fill="x", pady=(14, 4))
        self.progress = GoldProgress(pf)
        self.progress.pack(fill="x")
        stats = tk.Frame(self, bg=BG)
        stats.pack(fill="x")
        self.pct = tk.Label(stats, text="0%", bg=BG, fg=GOLD_HI, font=(FONT_B, 22))
        self.pct.pack(side="left")
        self.speed = tk.Label(stats, text="— Mbps", bg=BG, fg=GOLD, font=(MONO, 14))
        self.speed.pack(side="left", padx=24)
        self.eta = tk.Label(stats, text="", bg=BG, fg=MUTED, font=(FONT, 10))
        self.eta.pack(side="left")
        self.current = tk.Label(stats, text="", bg=BG, fg=MUTED, font=(FONT, 9))
        self.current.pack(side="right")

    def set_passes(self, n):
        self.passes.set(n)
        for k, b in self.pass_btns.items():
            on = k == n
            b.config(bg=GOLD if on else PANEL2, fg="#000" if on else MUTED)

    def _refresh(self):
        self.listbox.delete(0, "end")
        for t in self.targets:
            self.listbox.insert("end", ("📁  " if os.path.isdir(t) else "📄  ") + t)
        self.count_lbl.config(text=f"{len(self.targets)} items")

    def _add(self, paths):
        for p in paths:
            ok, why = core.check_path_allowed(p)
            if not ok:
                messagebox.showwarning("Protected location", f"{p}\n\n{why}.", parent=self)
                continue
            if p not in self.targets:
                self.targets.append(p)
        self._refresh()

    def add_files(self):
        if self.mode == "decrypt":
            paths = filedialog.askopenfilenames(
                parent=self, title="Select locked files",
                filetypes=[("Dortress locked files", "*" + core.EXT), ("All files", "*.*")])
        else:
            paths = filedialog.askopenfilenames(parent=self, title="Select files to encrypt")
        self._add([os.path.abspath(p) for p in paths])

    def add_folder(self):
        d = filedialog.askdirectory(parent=self, title="Select folder")
        if d:
            self._add([os.path.abspath(d)])

    def clear(self):
        self.targets = []
        self._refresh()

    def remove_selected(self, _e=None):
        for i in reversed(self.listbox.curselection()):
            del self.targets[i]
        self._refresh()

    def start(self):
        if not self.targets:
            messagebox.showinfo(core.APP_NAME, "Add files or folders first.", parent=self)
            return
        if self.mode == "encrypt":
            if not messagebox.askyesno(
                    "Confirm encryption",
                    "Selected files will be encrypted and the ORIGINALS SHREDDED.\n\n"
                    "Without your master password AND keybulk file the data cannot be "
                    "recovered by anyone, including Dortress Technologies.\n\nContinue?",
                    icon="warning", parent=self):
                return
        self.app.start_job(self.mode, list(self.targets), self, self.passes.get())

    def set_running(self, on: bool):
        self.go.set_enabled(not on)
        self.cancel_btn.set_enabled(on)
        if on:
            self.progress.set(0)
            self.pct.config(text="0%")
            self.speed.config(text="— Mbps")
            self.eta.config(text="Scanning…")
            self.current.config(text="")

    def on_progress(self, done, total, mbps, name):
        frac = done / total if total else 1.0
        self.progress.set(frac)
        self.pct.config(text=f"{frac * 100:.0f}%")
        self.speed.config(text=f"{mbps:,.0f} Mbps")
        if mbps > 0 and total:
            rem = (total - done) * 8 / 1e6 / mbps
            self.eta.config(text=f"{core.human_bytes(done)} / {core.human_bytes(total)}  ·  "
                                 f"ETA {int(rem // 60)}m {int(rem % 60):02d}s")
        self.current.config(text=name[:60])


# ----------------------------------------------------------------- app ----
class DortressApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f"{core.APP_NAME} — {core.DEVELOPER}")
        self.configure(bg=BG)
        self.geometry("1240x800")
        self.minsize(1080, 720)
        self.kb = core.Keybulk()
        self.dmk: bytes | None = None
        self.q: queue.Queue = queue.Queue()
        self.cancel_evt = threading.Event()
        self.busy = False
        self.active_panel: JobPanel | None = None
        self.last_activity = time.time()
        self.fail_count = 0
        self.last_mbps = None
        self._style()
        self.bind_all("<Key>", self._touch, add="+")
        self.bind_all("<Motion>", self._touch, add="+")
        self.protocol("WM_DELETE_WINDOW", self.on_close)
        self.after(80, self._poll)
        self.after(5000, self._autolock_check)
        self.show_auth()

    # ---------------------------------------------------------- plumbing --
    def _style(self):
        st = ttk.Style(self)
        try:
            st.theme_use("clam")
        except tk.TclError:
            pass
        st.configure("Gold.Vertical.TScrollbar", background=GOLD_DIM, troughcolor=PANEL2,
                     bordercolor=PANEL2, arrowcolor=GOLD, lightcolor=GOLD_DIM, darkcolor=GOLD_DIM)
        st.map("Gold.Vertical.TScrollbar", background=[("active", GOLD)])

    @staticmethod
    def _modal(top):
        try:
            top.wait_visibility()
            top.grab_set()
        except tk.TclError:
            pass

    def _touch(self, _e=None):
        self.last_activity = time.time()

    def _autolock_check(self):
        if self.dmk and not self.busy and time.time() - self.last_activity > AUTO_LOCK_SECONDS:
            self.lock()
        self.after(5000, self._autolock_check)

    def clear(self):
        for w in self.winfo_children():
            w.destroy()

    def on_close(self):
        if self.busy and not messagebox.askyesno(
                core.APP_NAME, "A job is running. Cancel it and exit?", parent=self):
            return
        self.cancel_evt.set()
        self.dmk = None
        self.destroy()

    def lock(self):
        if self.busy:
            messagebox.showinfo(core.APP_NAME, "Wait for the current job to finish.", parent=self)
            return
        self.dmk = None
        self.show_auth()

    # -------------------------------------------------------------- auth --
    def show_auth(self):
        self.clear()
        setup = not self.kb.exists()
        wrap = tk.Frame(self, bg=BG)
        wrap.place(relx=0.5, rely=0.5, anchor="center")
        Logo(wrap, 96).pack()
        tk.Label(wrap, text="DORTRESS  LOCKER", bg=BG, fg=GOLD_HI,
                 font=(FONT_B, 26)).pack(pady=(10, 0))
        tk.Label(wrap, text="Fortress-grade file & drive encryption", bg=BG, fg=MUTED,
                 font=(FONT, 10)).pack(pady=(2, 18))

        outer, box = card(wrap, "Create master password" if setup else "Unlock vault")
        outer.pack(ipadx=10)
        status = tk.Label(box, text="", bg=PANEL, fg=RED, font=(FONT, 9), wraplength=380,
                          justify="left")

        if setup:
            tk.Label(box, text="Recommended: 10 numbers · 3 uppercase · 3 lowercase · "
                               "4 special characters.\nThis master password protects everything. "
                               "It cannot be recovered if lost.",
                     bg=PANEL, fg=MUTED, font=(FONT, 9), justify="left").pack(anchor="w")
            meter = StrengthMeter(box, 380)
            tk.Label(box, text="Master password", bg=PANEL, fg=TEXT, font=(FONT_B, 9)).pack(
                anchor="w", pady=(12, 4))
            pw = PasswordEntry(box, meter.update_pw)
            pw.pack(fill="x")
            meter.pack(fill="x", pady=(8, 4))
            tk.Label(box, text="Confirm password", bg=PANEL, fg=TEXT, font=(FONT_B, 9)).pack(
                anchor="w", pady=(8, 4))
            cf = PasswordEntry(box)
            cf.pack(fill="x")
            status.pack(anchor="w", pady=(8, 0))

            def gen():
                g = core.generate_password()
                pw.set(g)
                cf.set(g)
                self.show_generated(g)

            def create():
                a, b = pw.get(), cf.get()
                if not core.policy_ok(a):
                    status.config(text="Needs at least 10 numbers, 3 uppercase, 3 lowercase "
                                       "and 4 special characters.")
                    return
                if a != b:
                    status.config(text="Passwords do not match.")
                    return
                status.config(text="Forging keybulk (Argon2id)…", fg=GOLD)
                btn.set_enabled(False)

                def work():
                    try:
                        dmk = self.kb.create(a)
                        self.q.put(("auth_ok", dmk))
                    except Exception as e:
                        self.q.put(("auth_err", str(e)))

                self._auth_status, self._auth_btn = status, btn
                threading.Thread(target=work, daemon=True).start()

            row = tk.Frame(box, bg=PANEL)
            row.pack(fill="x", pady=(14, 0))
            GoldButton(row, "Generate", gen, "ghost").pack(side="left")
            btn = GoldButton(row, "CREATE VAULT", create, "primary", padx=28)
            btn.pack(side="right")
            pw.entry.focus_set()
            cf.entry.bind("<Return>", lambda e: create())
        else:
            tk.Label(box, text="Master password", bg=PANEL, fg=TEXT, font=(FONT_B, 9)).pack(
                anchor="w", pady=(4, 4))
            pw = PasswordEntry(box)
            pw.pack(fill="x")
            status.pack(anchor="w", pady=(8, 0))

            def unlock():
                p = pw.get()
                if not p:
                    return
                status.config(text="Deriving key (Argon2id)…", fg=GOLD)
                btn.set_enabled(False)
                delay = min(30, 2 ** self.fail_count - 1) if self.fail_count else 0

                def work():
                    time.sleep(delay)
                    try:
                        self.q.put(("auth_ok", self.kb.unlock(p)))
                    except core.WrongPassword:
                        self.q.put(("auth_err", "Wrong master password."))
                    except Exception as e:
                        self.q.put(("auth_err", str(e)))

                self._auth_status, self._auth_btn = status, btn
                threading.Thread(target=work, daemon=True).start()

            btn = GoldButton(box, "UNLOCK", unlock, "primary", padx=40)
            btn.pack(fill="x", pady=(14, 0))
            pw.entry.bind("<Return>", lambda e: unlock())
            pw.entry.focus_set()

        tk.Label(wrap, text=f"v{core.VERSION}  ·  {core.DEVELOPER}", bg=BG, fg=GOLD_DIM,
                 font=(FONT, 9)).pack(pady=(18, 0))

    def show_generated(self, pw):
        top = tk.Toplevel(self, bg=PANEL)
        top.title("Generated master password")
        top.transient(self)
        self._modal(top)
        tk.Label(top, text="Your generated master password", bg=PANEL, fg=GOLD,
                 font=(FONT_B, 11)).pack(padx=24, pady=(18, 6))
        tk.Label(top, text=pw, bg=PANEL2, fg=GOLD_HI, font=(MONO, 16), padx=16,
                 pady=10).pack(padx=24)
        tk.Label(top, text="Write it down and store it offline. It is never saved anywhere\n"
                           "and cannot be recovered if lost.",
                 bg=PANEL, fg=MUTED, font=(FONT, 9)).pack(padx=24, pady=10)
        row = tk.Frame(top, bg=PANEL)
        row.pack(pady=(0, 18))

        def copy():
            self.clipboard_clear()
            self.clipboard_append(pw)
            # wipe the clipboard after 30 s
            self.after(30000, lambda: (self.clipboard_clear(), self.clipboard_append("")))

        GoldButton(row, "Copy (clears in 30 s)", copy, "ghost").pack(side="left", padx=4)
        GoldButton(row, "I've saved it", top.destroy, "primary").pack(side="left", padx=4)

    # -------------------------------------------------------------- main --
    def show_main(self):
        self.clear()
        side = tk.Frame(self, bg=PANEL, width=230, highlightthickness=0)
        side.pack(side="left", fill="y")
        side.pack_propagate(False)
        tk.Frame(self, bg=GOLD_DIM, width=1).pack(side="left", fill="y")
        brand = tk.Frame(side, bg=PANEL)
        brand.pack(fill="x", pady=(20, 24), padx=18)
        Logo(brand, 46).pack(side="left")
        t = tk.Frame(brand, bg=PANEL)
        t.pack(side="left", padx=10)
        tk.Label(t, text="DORTRESS", bg=PANEL, fg=GOLD_HI, font=(FONT_B, 14)).pack(anchor="w")
        tk.Label(t, text="LOCKER", bg=PANEL, fg=GOLD, font=(FONT, 9)).pack(anchor="w")

        self.content = tk.Frame(self, bg=BG)
        self.content.pack(side="left", fill="both", expand=True, padx=34, pady=26)

        self.pages = {
            "dashboard": self.page_dashboard,
            "encrypt": lambda: JobPanel(self.content, self, "encrypt"),
            "decrypt": lambda: JobPanel(self.content, self, "decrypt"),
            "drives": self.page_drives,
            "security": self.page_security,
            "about": self.page_about,
        }
        self.page_cache: dict = {}
        self.nav = {}
        for key, label in (("dashboard", "◈  Dashboard"), ("encrypt", "⬢  Encrypt"),
                           ("decrypt", "⬡  Decrypt"), ("drives", "▣  Drives"),
                           ("security", "⛨  Security"), ("about", "✦  About")):
            lb = tk.Label(side, text=label, bg=PANEL, fg=MUTED, font=(FONT_B, 11), anchor="w",
                          padx=22, pady=11, cursor="hand2")
            lb.pack(fill="x")
            lb.bind("<Button-1>", lambda e, k=key: self.show_page(k))
            lb.bind("<Enter>", lambda e, w=lb, k=key: self.current_page != k and w.config(fg=GOLD))
            lb.bind("<Leave>", lambda e, w=lb, k=key: self.current_page != k and w.config(fg=MUTED))
            self.nav[key] = lb
        bottom = tk.Frame(side, bg=PANEL)
        bottom.pack(side="bottom", fill="x", padx=18, pady=18)
        tk.Label(bottom, text="● VAULT UNLOCKED", bg=PANEL, fg=GREEN, font=(FONT_B, 8)).pack(
            anchor="w", pady=(0, 8))
        GoldButton(bottom, "Lock now", self.lock, "ghost").pack(fill="x")

        # shared log console (bottom of content)
        self.page_host = tk.Frame(self.content, bg=BG)
        self.page_host.pack(fill="both", expand=True)
        logf = tk.Frame(self.content, bg=PANEL, highlightthickness=1, highlightbackground=LINE)
        logf.pack(fill="x", pady=(14, 0))
        tk.Label(logf, text="ACTIVITY", bg=PANEL, fg=GOLD_DIM, font=(FONT_B, 8)).pack(
            anchor="w", padx=10, pady=(6, 0))
        self.log = tk.Text(logf, height=6, bg=PANEL, fg=MUTED, bd=0, font=(MONO, 9),
                           highlightthickness=0, wrap="none", state="disabled")
        self.log.pack(fill="x", padx=10, pady=(2, 8))
        for tag, col in (("ok", GREEN), ("warn", AMBER), ("err", RED), ("info", GOLD)):
            self.log.tag_config(tag, foreground=col)
        self.current_page = None
        self.show_page("dashboard")
        self.write_log("info", f"Vault unlocked · keybulk id {self.kb.key_id()}")

    def show_page(self, key):
        for k, lb in self.nav.items():
            lb.config(fg=GOLD_HI if k == key else MUTED, bg=PANEL3 if k == key else PANEL)
        for w in self.page_host.winfo_children():
            w.pack_forget()
        if key in ("encrypt", "decrypt"):
            if key not in self.page_cache:
                self.page_cache[key] = self.pages[key]()
            page = self.page_cache[key]
        else:
            if key in self.page_cache:
                self.page_cache[key].destroy()
            page = self.pages[key]()
            self.page_cache[key] = page
        page.pack(in_=self.page_host, fill="both", expand=True)
        self.current_page = key

    def write_log(self, level, text):
        if not hasattr(self, "log") or not self.log.winfo_exists():
            return
        self.log.config(state="normal")
        self.log.insert("end", time.strftime("%H:%M:%S  "), "info")
        self.log.insert("end", text + "\n", level)
        lines = int(self.log.index("end-1c").split(".")[0])
        if lines > 600:
            self.log.delete("1.0", f"{lines - 600}.0")
        self.log.see("end")
        self.log.config(state="disabled")

    # --------------------------------------------------------- dashboard --
    def page_dashboard(self):
        f = tk.Frame(self.content, bg=BG)
        section_title(f, "Command Center",
                      "Your vault is unlocked. Encrypt files, folders and external drives — "
                      "the Windows system drive and system/service folders are never touched.")
        grid = tk.Frame(f, bg=BG)
        grid.pack(fill="x")
        pq, _ = core.pq_assessment()
        stats = [
            ("Cipher", "AES-256-GCM", "Authenticated · 4 MiB chunks"),
            ("Key derivation", "Argon2id", "128 MiB · t=3 · p=4"),
            ("PQ readiness", f"{pq:.1f} / 10", "Self-assessment · see Security"),
            ("Last throughput", f"{self.last_mbps:,.0f} Mbps" if self.last_mbps else "—",
             "Measured on your machine"),
        ]
        for i, (a, b, c) in enumerate(stats):
            outer, inner = card(grid)
            outer.grid(row=0, column=i, sticky="nsew", padx=(0 if i == 0 else 10, 0))
            grid.columnconfigure(i, weight=1)
            tk.Label(inner, text=a.upper(), bg=PANEL, fg=GOLD_DIM, font=(FONT_B, 8)).pack(anchor="w")
            tk.Label(inner, text=b, bg=PANEL, fg=GOLD_HI, font=(FONT_B, 18)).pack(anchor="w", pady=4)
            tk.Label(inner, text=c, bg=PANEL, fg=MUTED, font=(FONT, 9)).pack(anchor="w")

        acts = tk.Frame(f, bg=BG)
        acts.pack(fill="x", pady=22)
        for i, (title, desc, key) in enumerate((
                ("Encrypt files & folders", "Lock and shred originals", "encrypt"),
                ("Decrypt & restore", "Verify and unlock .dlock files", "decrypt"),
                ("Encrypt a drive", "D:, E:, USB & external disks", "drives"))):
            outer, inner = card(acts)
            outer.grid(row=0, column=i, sticky="nsew", padx=(0 if i == 0 else 10, 0))
            acts.columnconfigure(i, weight=1)
            tk.Label(inner, text=title, bg=PANEL, fg=TEXT, font=(FONT_B, 13)).pack(anchor="w")
            tk.Label(inner, text=desc, bg=PANEL, fg=MUTED, font=(FONT, 9)).pack(anchor="w", pady=(2, 12))
            GoldButton(inner, "Open  →", lambda k=key: self.show_page(k), "ghost").pack(anchor="w")

        outer, inner = card(f, "Protection rules", fill="x")
        rules = [
            f"System drive {core.system_drive() if core.IS_WINDOWS else '/'} is never touched.",
            "Windows, Program Files, ProgramData, AppData, Recycle Bin, Recovery and boot "
            "folders are always skipped.",
            "Folders of running programs and services are skipped"
            + ("." if core.psutil else " (install psutil to enable process detection)."),
            "Files that are locked/in use, system files, symlinks and junctions are skipped.",
        ]
        for r in rules:
            tk.Label(inner, text="◆  " + r, bg=PANEL, fg=TEXT, font=(FONT, 10), anchor="w",
                     justify="left", wraplength=880).pack(anchor="w", pady=2)
        return f

    # ------------------------------------------------------------ drives --
    def page_drives(self):
        f = tk.Frame(self.content, bg=BG)
        section_title(f, "Drives",
                      "Encrypt every file on an internal data drive or external disk. "
                      "This is file-level encryption: the drive stays usable and other files "
                      "can still be added.")
        top = tk.Frame(f, bg=BG)
        top.pack(fill="x", pady=(0, 10))
        GoldButton(top, "Refresh", lambda: self.show_page("drives"), "ghost").pack(side="right")
        try:
            drives = core.list_drives()
        except Exception as e:
            drives = []
            self.write_log("err", f"Drive scan failed: {e}")
        for d in drives:
            outer, inner = card(f, fill="x", pady=5)
            row = tk.Frame(inner, bg=PANEL)
            row.pack(fill="x")
            tk.Label(row, text=d["path"], bg=PANEL, fg=GOLD_HI, font=(FONT_B, 16), width=6,
                     anchor="w").pack(side="left")
            info = tk.Frame(row, bg=PANEL)
            info.pack(side="left", fill="x", expand=True, padx=10)
            used = d["total"] - d["free"]
            tk.Label(info, text=f"{d['type']} · {core.human_bytes(used)} used of "
                                f"{core.human_bytes(d['total'])}",
                     bg=PANEL, fg=TEXT, font=(FONT, 10)).pack(anchor="w")
            bar = GoldProgress(info, 6)
            bar.pack(fill="x", pady=(6, 0))
            bar.set(used / d["total"] if d["total"] else 0)
            if d["is_system"]:
                tk.Label(row, text="🔒  SYSTEM DRIVE — PROTECTED", bg=PANEL, fg=MUTED,
                         font=(FONT_B, 9)).pack(side="right")
            elif d["type"] in ("CD/DVD", "Network"):
                tk.Label(row, text="Not supported", bg=PANEL, fg=MUTED,
                         font=(FONT_B, 9)).pack(side="right")
            else:
                GoldButton(row, "Decrypt", lambda p=d["path"]: self.drive_job(p, "decrypt"),
                           "ghost").pack(side="right", padx=(8, 0))
                GoldButton(row, "Encrypt drive", lambda p=d["path"]: self.drive_job(p, "encrypt"),
                           "primary").pack(side="right")
        if not drives:
            tk.Label(f, text="No drives found.", bg=BG, fg=MUTED, font=(FONT, 10)).pack(anchor="w")
        return f

    def drive_job(self, path, mode):
        ok, why = core.check_path_allowed(path)
        if not ok:
            messagebox.showerror("Protected", why, parent=self)
            return
        label = path.rstrip("\\/") or path
        top = tk.Toplevel(self, bg=PANEL)
        top.title("Confirm drive operation")
        top.transient(self)
        self._modal(top)
        verb = "ENCRYPT every file on" if mode == "encrypt" else "DECRYPT every locked file on"
        tk.Label(top, text=f"{verb} {label}", bg=PANEL, fg=GOLD_HI, font=(FONT_B, 13)).pack(
            padx=26, pady=(20, 6))
        tk.Label(top, text=("Originals will be shredded. Keep your master password and a keybulk "
                            "backup safe.\n" if mode == "encrypt" else "")
                 + f"Type  {label}  below to confirm.",
                 bg=PANEL, fg=MUTED, font=(FONT, 10), justify="center").pack(padx=26)
        var = tk.StringVar()
        e = tk.Entry(top, textvariable=var, bg=PANEL2, fg=GOLD_HI, insertbackground=GOLD,
                     font=(MONO, 14), justify="center", relief="flat", width=12)
        e.pack(pady=12, ipady=6)
        e.focus_set()

        def go():
            if var.get().strip().upper().rstrip("\\/") != label.upper():
                e.config(bg="#2a1210")
                return
            top.destroy()
            self.show_page(mode)
            panel = self.page_cache[mode]
            panel.targets = [path]
            panel._refresh()
            self.start_job(mode, [path], panel, 1)

        e.bind("<Return>", lambda _e: go())
        row = tk.Frame(top, bg=PANEL)
        row.pack(pady=(0, 20))
        GoldButton(row, "Cancel", top.destroy, "ghost").pack(side="left", padx=4)
        GoldButton(row, "Confirm", go, "danger" if mode == "encrypt" else "primary").pack(
            side="left", padx=4)

    # ---------------------------------------------------------- security --
    def page_security(self):
        f = tk.Frame(self.content, bg=BG)
        section_title(f, "Security Center")
        cols = tk.Frame(f, bg=BG)
        cols.pack(fill="both", expand=True)
        cols.columnconfigure(0, weight=1)
        cols.columnconfigure(1, weight=1)
        left = tk.Frame(cols, bg=BG)
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 10))
        right = tk.Frame(cols, bg=BG)
        right.grid(row=0, column=1, sticky="nsew", padx=(10, 0))

        # PQ score ring
        score, items = core.pq_assessment()
        outer, inner = card(left, "Post-quantum readiness", fill="x")
        top = tk.Frame(inner, bg=PANEL)
        top.pack(fill="x")
        ring = tk.Canvas(top, width=110, height=110, bg=PANEL, highlightthickness=0)
        ring.pack(side="left")
        ring.create_oval(8, 8, 102, 102, outline="#1f1d25", width=10)
        ring.create_arc(8, 8, 102, 102, start=90, extent=-360 * score / 10, style="arc",
                        outline=GOLD, width=10)
        ring.create_text(55, 50, text=f"{score:.1f}", fill=GOLD_HI, font=(FONT_B, 22))
        ring.create_text(55, 74, text="/ 10", fill=MUTED, font=(FONT, 9))
        lst = tk.Frame(top, bg=PANEL)
        lst.pack(side="left", fill="x", expand=True, padx=(14, 0))
        for text, got, mx in items:
            tk.Label(lst, text=f"{'✔' if got == mx else '–'} {got:.1f}/{mx:.1f}  {text}",
                     bg=PANEL, fg=TEXT if got == mx else AMBER, font=(FONT, 8), anchor="w",
                     justify="left", wraplength=360).pack(anchor="w", pady=1)
        tk.Label(inner, text="Internal self-assessment of this design, not a third-party "
                             "certification.", bg=PANEL, fg=MUTED, font=(FONT, 8)).pack(
            anchor="w", pady=(8, 0))

        # benchmark
        outer, inner = card(left, "Speed benchmark", fill="x", pady=(14, 0))
        res = tk.Label(inner, text="Measure raw AES-256-GCM speed on this machine.", bg=PANEL,
                       fg=MUTED, font=(FONT, 10), justify="left")
        res.pack(anchor="w")
        big = tk.Label(inner, text="", bg=PANEL, fg=GOLD_HI, font=(FONT_B, 22))
        big.pack(anchor="w")

        def bench():
            btn.set_enabled(False)
            res.config(text="Running…")

            def work():
                r = core.benchmark(1.5)
                self.q.put(("bench", r, res, big, btn))

            threading.Thread(target=work, daemon=True).start()

        btn = GoldButton(inner, "Run benchmark", bench, "ghost")
        btn.pack(anchor="w", pady=(8, 0))

        # change master password
        outer, inner = card(right, "Change master password", fill="x")
        tk.Label(inner, text="Only the keybulk is re-wrapped — your encrypted files stay as "
                             "they are.", bg=PANEL, fg=MUTED, font=(FONT, 9)).pack(anchor="w")
        fields = {}
        meter = StrengthMeter(inner, 380)
        for key, lab in (("cur", "Current password"), ("new", "New password"),
                         ("cf", "Confirm new password")):
            tk.Label(inner, text=lab, bg=PANEL, fg=TEXT, font=(FONT_B, 9)).pack(anchor="w",
                                                                                pady=(8, 3))
            pe = PasswordEntry(inner, meter.update_pw if key == "new" else None)
            pe.pack(fill="x")
            fields[key] = pe
            if key == "new":
                meter.pack(fill="x", pady=(6, 0))
        msg = tk.Label(inner, text="", bg=PANEL, fg=RED, font=(FONT, 9))
        msg.pack(anchor="w", pady=(6, 0))

        def gen():
            g = core.generate_password()
            fields["new"].set(g)
            fields["cf"].set(g)
            self.show_generated(g)

        def change():
            cur, new, cf = (fields[k].get() for k in ("cur", "new", "cf"))
            if not core.policy_ok(new):
                msg.config(text="New password needs 10 numbers, 3 upper, 3 lower, 4 special.",
                           fg=RED)
                return
            if new != cf:
                msg.config(text="New passwords do not match.", fg=RED)
                return
            if new == cur:
                msg.config(text="New password must differ from the current one.", fg=RED)
                return
            msg.config(text="Re-wrapping keybulk…", fg=GOLD)
            cbtn.set_enabled(False)

            def work():
                try:
                    self.kb.change_password(cur, new)
                    self.q.put(("pw_changed", msg, cbtn, fields))
                except core.WrongPassword:
                    self.q.put(("pw_err", msg, cbtn, "Current password is wrong."))
                except Exception as e:
                    self.q.put(("pw_err", msg, cbtn, str(e)))

            threading.Thread(target=work, daemon=True).start()

        row = tk.Frame(inner, bg=PANEL)
        row.pack(fill="x", pady=(10, 0))
        GoldButton(row, "Generate", gen, "ghost").pack(side="left")
        cbtn = GoldButton(row, "CHANGE PASSWORD", change, "primary")
        cbtn.pack(side="right")

        # keybulk
        outer, inner = card(right, "Keybulk", fill="x", pady=(14, 0))
        tk.Label(inner, text=f"Key ID  {self.kb.key_id()}\n{self.kb.path}", bg=PANEL, fg=TEXT,
                 font=(MONO, 9), justify="left", wraplength=420).pack(anchor="w")
        tk.Label(inner, text="If this file is lost, locked data cannot be recovered. "
                             "Keep a backup on separate media.",
                 bg=PANEL, fg=AMBER, font=(FONT, 9), wraplength=420, justify="left").pack(
            anchor="w", pady=(6, 8))

        def backup():
            dest = filedialog.asksaveasfilename(parent=self, defaultextension=".dkb",
                                                initialfile="dortress-keybulk-backup.dkb",
                                                filetypes=[("Dortress keybulk", "*.dkb")])
            if dest:
                try:
                    self.kb.export_backup(dest)
                    self.write_log("ok", f"Keybulk backed up to {dest}")
                except Exception as e:
                    messagebox.showerror(core.APP_NAME, str(e), parent=self)

        GoldButton(inner, "Back up keybulk", backup, "ghost").pack(anchor="w")
        return f

    # ------------------------------------------------------------- about --
    def page_about(self):
        f = tk.Frame(self.content, bg=BG)
        section_title(f, "About")
        outer, inner = card(f, fill="x")
        row = tk.Frame(inner, bg=PANEL)
        row.pack(fill="x")
        Logo(row, 110).pack(side="left")
        t = tk.Frame(row, bg=PANEL)
        t.pack(side="left", padx=20)
        tk.Label(t, text="DORTRESS LOCKER", bg=PANEL, fg=GOLD_HI, font=(FONT_B, 24)).pack(anchor="w")
        tk.Label(t, text=f"Version {core.VERSION}", bg=PANEL, fg=MUTED, font=(FONT, 10)).pack(anchor="w")
        tk.Label(t, text="Developed by", bg=PANEL, fg=MUTED, font=(FONT, 9)).pack(anchor="w", pady=(12, 0))
        tk.Label(t, text=core.DEVELOPER, bg=PANEL, fg=GOLD, font=(FONT_B, 14)).pack(anchor="w")

        outer, inner = card(f, "Under the hood", fill="x", pady=(14, 0))
        specs = [
            ("Encryption", "AES-256-GCM, 4 MiB chunks, per-chunk nonce, header + index + final-flag AAD"),
            ("Per-file keys", "HKDF-SHA256 from the Data Master Key and a random 256-bit salt"),
            ("Master password", "Argon2id (128 MiB memory, 3 iterations, 4 lanes)"),
            ("Keybulk AEAD", "Data Master Key wrapped with AES-256-GCM; password changes re-wrap only"),
            ("Shredding", "1/3/7 random-overwrite passes, random rename, then delete"),
            ("Parallelism", f"Multi-threaded file pipeline ({max(2, min(8, os.cpu_count() or 4))} workers)"),
            ("Crypto library", "pyca/cryptography (OpenSSL, AES-NI hardware acceleration)"),
        ]
        for k, v in specs:
            r = tk.Frame(inner, bg=PANEL)
            r.pack(fill="x", pady=2)
            tk.Label(r, text=k, bg=PANEL, fg=GOLD, font=(FONT_B, 10), width=16, anchor="w").pack(side="left")
            tk.Label(r, text=v, bg=PANEL, fg=TEXT, font=(FONT, 10), anchor="w").pack(side="left")
        tk.Label(f, text="Note: on SSDs and flash drives, wear-levelling means overwriting cannot "
                         "guarantee every old copy of a block is erased. For maximum assurance on "
                         "SSDs, store sensitive files only after encrypting them, or combine with "
                         "full-disk encryption.",
                 bg=BG, fg=MUTED, font=(FONT, 9), wraplength=900, justify="left").pack(
            anchor="w", pady=(14, 0))
        tk.Label(f, text=f"© {time.strftime('%Y')} {core.DEVELOPER}. All rights reserved.",
                 bg=BG, fg=GOLD_DIM, font=(FONT, 9)).pack(anchor="w", pady=(8, 0))
        return f

    # -------------------------------------------------------------- jobs --
    def start_job(self, mode, targets, panel: JobPanel, passes: int):
        if self.busy:
            messagebox.showinfo(core.APP_NAME, "Another job is already running.", parent=self)
            return
        if not self.dmk:
            self.lock()
            return
        self.busy = True
        self.cancel_evt = threading.Event()
        self.active_panel = panel
        panel.set_running(True)
        self.write_log("info", f"{mode.title()} started on {len(targets)} target(s)")
        dmk, cancel = self.dmk, self.cancel_evt

        def work():
            skipped = [0]

            def on_skip(p, why):
                skipped[0] += 1
                if skipped[0] <= 200:
                    self.q.put(("log", "warn", f"Skipped {p}  ({why})"))

            try:
                files = core.collect_files(targets, want_encrypted=(mode == "decrypt"),
                                           on_skip=on_skip)
                if skipped[0] > 200:
                    self.q.put(("log", "warn", f"…and {skipped[0] - 200} more skipped"))
                self.q.put(("log", "info", f"{len(files)} file(s) queued"))
                res = core.run_job(mode, files, dmk, self.q.put, cancel, passes)
                res.skipped += skipped[0]
                self.q.put(("job_done", mode, res))
            except Exception as e:
                self.q.put(("job_fail", str(e)))

        threading.Thread(target=work, daemon=True).start()

    def cancel_job(self):
        if self.busy:
            self.cancel_evt.set()
            self.write_log("warn", "Cancelling… (current files finish cleanly, partial outputs removed)")

    def _poll(self):
        try:
            while True:
                ev = self.q.get_nowait()
                self._handle(ev)
        except queue.Empty:
            pass
        self.after(60, self._poll)

    def _handle(self, ev):
        kind = ev[0]
        if kind == "auth_ok":
            self.dmk = ev[1]
            self.fail_count = 0
            self.last_activity = time.time()
            self.show_main()
        elif kind == "auth_err":
            self.fail_count += 1
            try:
                self._auth_status.config(text=ev[1], fg=RED)
                self._auth_btn.set_enabled(True)
            except tk.TclError:
                pass
        elif kind == "progress":
            _, done, total, mbps, name = ev
            if self.active_panel and self.active_panel.winfo_exists():
                self.active_panel.on_progress(done, total, mbps, name)
        elif kind == "log":
            self.write_log(ev[1], ev[2])
        elif kind == "job_done":
            _, mode, r = ev
            self.busy = False
            if r.bytes:
                self.last_mbps = r.mbps
            p = self.active_panel
            if p and p.winfo_exists():
                p.set_running(False)
                p.on_progress(r.bytes, r.bytes or 1, r.mbps, "")
                p.eta.config(text=f"Done in {r.seconds:.1f}s")
                p.clear()
            self.write_log("ok" if not r.failed else "warn",
                           f"{mode.title()} finished · {r.ok} ok · {r.failed} failed · "
                           f"{r.skipped} skipped · {core.human_bytes(r.bytes)} at {r.mbps:,.0f} Mbps")
            if self.cancel_evt.is_set():
                self.write_log("warn", "Job was cancelled.")
        elif kind == "job_fail":
            self.busy = False
            if self.active_panel and self.active_panel.winfo_exists():
                self.active_panel.set_running(False)
            self.write_log("err", f"Job failed: {ev[1]}")
        elif kind == "bench":
            _, r, res, big, btn = ev
            try:
                big.config(text=f"{r['Mbps']:,.0f} Mbps")
                res.config(text=f"{r['MBps']:,.0f} MB/s in memory across {r['threads']} threads. "
                                f"Real-world speed is usually limited by your disk.")
                btn.set_enabled(True)
            except tk.TclError:
                pass
            self.write_log("info", f"Benchmark: {r['Mbps']:,.0f} Mbps AES-256-GCM")
        elif kind == "pw_changed":
            _, msg, btn, fields = ev
            try:
                for pe in fields.values():
                    pe.clear()
                msg.config(text="Master password changed. Back up the keybulk again.", fg=GREEN)
                btn.set_enabled(True)
            except tk.TclError:
                pass
            self.write_log("ok", "Master password changed (keybulk re-wrapped)")
        elif kind == "pw_err":
            _, msg, btn, text = ev
            try:
                msg.config(text=text, fg=RED)
                btn.set_enabled(True)
            except tk.TclError:
                pass


def main():
    if WIN:
        try:
            import ctypes
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except Exception:
            pass
    app = DortressApp()
    app.mainloop()


if __name__ == "__main__":
    main()
