"""
Dortress Locker - black & gold desktop GUI
(c) Dortress Technologies Private Limited

Run:  python dortress_locker.py
"""
from __future__ import annotations

import math
import os
import queue
import sys
import threading
import time
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

import dortress_core as core

# ----------------------------------------------------------------- theme ----
BG = "#050507"
PANEL = "#0d0d12"
PANEL2 = "#15151c"
PANEL3 = "#221d0e"
LINE = "#2c2615"
GOLD = "#d4af37"
GOLD_HI = "#f6dc84"
GOLD_DIM = "#7d6420"
TEXT = "#ece6d2"
MUTED = "#8f897a"
RED = "#e5534b"
AMBER = "#e0a030"
GREEN = "#43c27a"

WIN = sys.platform.startswith("win")
FONT = "Segoe UI" if WIN else "Helvetica"
FONT_B = "Segoe UI Semibold" if WIN else "Helvetica"
MONO = "Consolas" if WIN else "Courier"
AUTO_LOCK_SECONDS = 10 * 60

SHRED_MODES = [
    (0, "Turbo", "Delete only, no overwrite. Fastest. Best for SSDs and USB sticks."),
    (1, "Fast", "1 random overwrite pass, then delete. Recommended for hard disks."),
    (3, "Strong", "3 random overwrite passes, then delete."),
    (7, "Paranoid", "7 random overwrite passes, then delete. Slowest."),
]


def lerp_color(a: str, b: str, t: float) -> str:
    t = max(0.0, min(1.0, t))
    ca = [int(a[i:i + 2], 16) for i in (1, 3, 5)]
    cb = [int(b[i:i + 2], 16) for i in (1, 3, 5)]
    return "#%02x%02x%02x" % tuple(int(x + (y - x) * t) for x, y in zip(ca, cb))


def alive(w) -> bool:
    try:
        return bool(w.winfo_exists())
    except Exception:
        return False


# --------------------------------------------------------------- widgets ----
class GButton(tk.Button):
    """Native Tk button (reliable clicks + keyboard), styled black & gold."""
    STYLES = {
        "primary": (GOLD, "#0a0a0a", GOLD_HI),
        "ghost": (PANEL2, GOLD, PANEL3),
        "danger": ("#2a110f", RED, "#3d1814"),
    }

    def __init__(self, master, text, command=None, kind="primary", size=10, padx=16, pady=7, **kw):
        bg, fg, hover = self.STYLES[kind]
        super().__init__(master, text=text, command=command, bg=bg, fg=fg,
                         activebackground=hover, activeforeground=fg,
                         disabledforeground=MUTED, relief="flat", bd=0, overrelief="flat",
                         highlightthickness=1, highlightbackground=GOLD_DIM, highlightcolor=GOLD_HI,
                         font=(FONT_B, size), padx=padx, pady=pady, cursor="hand2", takefocus=1, **kw)
        self._bg, self._hover = bg, hover
        self.bind("<Enter>", self._in, add="+")
        self.bind("<Leave>", self._out, add="+")
        self.bind("<Return>", lambda e: self.invoke(), add="+")

    def _in(self, _e=None):
        if str(self["state"]) != "disabled":
            self.config(bg=self._hover)

    def _out(self, _e=None):
        self.config(bg=self._bg)

    def set_enabled(self, on: bool):
        self.config(state="normal" if on else "disabled", cursor="hand2" if on else "arrow")
        if not on:
            self.config(bg=self._bg)


class ScrollFrame(tk.Frame):
    """Vertically scrollable area whose content always fits the window width."""

    def __init__(self, master, bg=BG):
        super().__init__(master, bg=bg)
        self.canvas = tk.Canvas(self, bg=bg, highlightthickness=0, bd=0)
        self.vsb = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview,
                                 style="Gold.Vertical.TScrollbar")
        self.inner = tk.Frame(self.canvas, bg=bg)
        self.win = self.canvas.create_window(0, 0, window=self.inner, anchor="nw")
        self.canvas.configure(yscrollcommand=self.vsb.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        self.vsb.pack(side="right", fill="y")
        self.inner.bind("<Configure>", self._sync)
        self.canvas.bind("<Configure>", self._fit)

    def _sync(self, _e=None):
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def _fit(self, e):
        self.canvas.itemconfigure(self.win, width=e.width)
        self._sync()

    def wheel(self, steps: int):
        if self.inner.winfo_height() > self.canvas.winfo_height():
            self.canvas.yview_scroll(steps, "units")

    def to_top(self):
        self.canvas.yview_moveto(0)


class FlowGrid(tk.Frame):
    """Cards that reflow into as many columns as the width allows."""

    def __init__(self, master, min_w=260, gap=14, bg=BG):
        super().__init__(master, bg=bg)
        self.min_w, self.gap = min_w, gap
        self.items: list = []
        self.cols = 0
        self.bind("<Configure>", self._on_resize)

    def add(self, w):
        self.items.append(w)
        self._layout(max(1, self.cols or 1))

    def _on_resize(self, e):
        cols = max(1, min(len(self.items) or 1, (e.width + self.gap) // (self.min_w + self.gap)))
        if cols != self.cols:
            self._layout(cols)

    def _layout(self, cols):
        self.cols = cols
        for c in range(max(len(self.items), 1)):
            self.columnconfigure(c, weight=1 if c < cols else 0, uniform="flow" if c < cols else "")
        for i, w in enumerate(self.items):
            r, c = divmod(i, cols)
            w.grid(row=r, column=c, sticky="nsew",
                   padx=(0 if c == 0 else self.gap, 0), pady=(0 if r == 0 else self.gap, 0))


def wlabel(parent, text, fg=TEXT, font=None, bg=None, **pack):
    """Label that re-wraps its text to the available width."""
    lb = tk.Label(parent, text=text, bg=bg or parent.cget("bg"), fg=fg,
                  font=font or (FONT, 10), justify="left", anchor="w")
    lb.bind("<Configure>", lambda e: lb.config(wraplength=max(60, e.width - 6)))
    lb.pack(fill="x", **pack)
    return lb


def card(parent, title=None, accent=GOLD):
    outer = tk.Frame(parent, bg=PANEL, highlightthickness=1, highlightbackground=LINE)
    tk.Frame(outer, bg=accent, height=2).pack(fill="x")
    inner = tk.Frame(outer, bg=PANEL)
    inner.pack(fill="both", expand=True, padx=16, pady=14)
    if title:
        tk.Label(inner, text=title.upper(), bg=PANEL, fg=GOLD, font=(FONT_B, 9),
                 anchor="w").pack(fill="x", pady=(0, 8))
    return outer, inner


class PasswordEntry(tk.Frame):
    """Password field masked with stars, with a reveal toggle."""

    def __init__(self, master, on_change=None):
        super().__init__(master, bg=PANEL2, highlightthickness=1,
                         highlightbackground=LINE, highlightcolor=GOLD)
        self.var = tk.StringVar()
        self.entry = tk.Entry(self, textvariable=self.var, show="*", width=24, bd=0,
                              bg=PANEL2, fg=GOLD_HI, insertbackground=GOLD,
                              font=(MONO, 13), relief="flat")
        self.entry.pack(side="left", fill="x", expand=True, padx=(10, 4), pady=8)
        self.eye = tk.Button(self, text="SHOW", command=self.toggle, bg=PANEL2, fg=MUTED,
                             activebackground=PANEL3, activeforeground=GOLD, relief="flat", bd=0,
                             font=(FONT_B, 8), cursor="hand2", padx=10, highlightthickness=0)
        self.eye.pack(side="right", fill="y")
        self.entry.bind("<FocusIn>", lambda e: self.config(highlightbackground=GOLD))
        self.entry.bind("<FocusOut>", lambda e: self.config(highlightbackground=LINE))
        if on_change:
            self.var.trace_add("write", lambda *a: on_change(self.var.get()))

    def toggle(self):
        hidden = self.entry.cget("show") == "*"
        self.entry.config(show="" if hidden else "*")
        self.eye.config(text="HIDE" if hidden else "SHOW", fg=GOLD if hidden else MUTED)

    def get(self) -> str:
        return self.var.get()

    def set(self, v: str):
        self.var.set(v)

    def clear(self):
        self.var.set("")


class StrengthMeter(tk.Frame):
    SEGMENTS = 24

    def __init__(self, master):
        super().__init__(master, bg=master.cget("bg"))
        bg = self.cget("bg")
        self.pw = ""
        self.canvas = tk.Canvas(self, height=10, bg=bg, highlightthickness=0)
        self.canvas.pack(fill="x")
        self.canvas.bind("<Configure>", lambda e: self._draw())
        row = tk.Frame(self, bg=bg)
        row.pack(fill="x", pady=(4, 2))
        self.label = tk.Label(row, text="Strength: —", bg=bg, fg=MUTED, font=(FONT_B, 9))
        self.label.pack(side="left")
        self.bits = tk.Label(row, text="", bg=bg, fg=MUTED, font=(MONO, 9))
        self.bits.pack(side="right")
        chk = FlowGrid(self, min_w=120, gap=6, bg=bg)
        chk.pack(fill="x")
        self.checks = {}
        for k, txt in {"digits": "10 numbers", "upper": "3 UPPER", "lower": "3 lower",
                       "special": "4 special"}.items():
            lb = tk.Label(chk, text="○ " + txt, bg=bg, fg=MUTED, font=(FONT, 9), anchor="w")
            chk.add(lb)
            self.checks[k] = (lb, txt)
        self.update_pw("")

    def _draw(self):
        score, _, _ = core.password_strength(self.pw)
        c = self.canvas
        c.delete("all")
        w = max(c.winfo_width(), 50)
        seg = w / self.SEGMENTS
        lit = round(score / 100 * self.SEGMENTS)
        for i in range(self.SEGMENTS):
            t = i / (self.SEGMENTS - 1)
            col = lerp_color(RED, AMBER, t * 2) if t < 0.5 else lerp_color(GOLD, GREEN, (t - 0.5) * 2)
            c.create_rectangle(i * seg + 1, 0, (i + 1) * seg - 2, 10,
                               fill=col if i < lit else "#1d1d24", width=0)

    def update_pw(self, pw: str):
        self.pw = pw
        score, label, bits = core.password_strength(pw)
        self._draw()
        color = RED if score < 40 else AMBER if score < 60 else GOLD if score < 80 else GREEN
        self.label.config(text=f"Strength: {label}", fg=color if pw else MUTED)
        self.bits.config(text=f"~{bits:.0f} bits" if pw else "")
        for k, (have, need, ok) in core.policy_status(pw).items():
            lb, txt = self.checks[k]
            lb.config(text=("● " if ok else "○ ") + f"{txt} ({have}/{need})",
                      fg=GREEN if ok else (MUTED if not pw else AMBER))


class GoldProgress(tk.Canvas):
    def __init__(self, master, height=12):
        super().__init__(master, height=height, bg=master.cget("bg"), highlightthickness=0)
        self.frac = 0.0
        self.h = height
        self.phase = 0
        self.busy = False  # indeterminate shimmer while scanning
        self.bind("<Configure>", lambda e: self.redraw())
        self.after(40, self._animate)

    def set(self, frac: float):
        self.frac = max(0.0, min(1.0, frac))
        self.redraw()

    def redraw(self):
        self.delete("all")
        w = max(self.winfo_width(), 10)
        self.create_rectangle(0, 0, w, self.h, fill="#17161d", outline=LINE)
        if self.busy and self.frac == 0:
            x = (self.phase * 6) % (w + 120) - 120
            self.create_rectangle(max(0, x), 1, min(w, x + 120), self.h - 1, fill=GOLD_DIM, width=0)
            return
        fw = int(w * self.frac)
        if fw > 2:
            steps = 24
            for i in range(steps):
                self.create_rectangle(fw * i / steps, 1, fw * (i + 1) / steps + 1, self.h - 1,
                                      fill=lerp_color(GOLD_DIM, GOLD_HI, i / steps), width=0)
            if self.frac < 1:
                sx = (self.phase % 60) / 60 * fw
                self.create_rectangle(max(0, sx - 30), 1, sx, self.h - 1, fill="#fff3c4",
                                      stipple="gray50", width=0)

    def _animate(self):
        if not alive(self):
            return
        if self.busy or 0 < self.frac < 1:
            self.phase += 1
            self.redraw()
        self.after(40, self._animate)


class Logo(tk.Canvas):
    """Hexagon shield with an orbiting gold spark."""

    def __init__(self, master, size=64, animate=True):
        super().__init__(master, width=size, height=size, bg=master.cget("bg"),
                         highlightthickness=0)
        self.s = size
        self.t = 0.0
        self.draw()
        if animate:
            self.after(60, self.tick)

    def _hex(self, r):
        c = self.s / 2
        pts = []
        for i in range(6):
            a = math.radians(60 * i - 90)
            pts += [c + r * math.cos(a), c + r * math.sin(a)]
        return pts

    def draw(self):
        self.delete("all")
        s = self.s
        r = s * 0.44
        self.create_polygon(self._hex(r), outline=GOLD_DIM, fill="", width=1)
        self.create_polygon(self._hex(r * 0.84), outline=GOLD, fill="#0e0c06", width=2)
        self.create_text(s / 2, s / 2 + 1, text="D", fill=GOLD_HI, font=(FONT_B, max(8, int(s * 0.3)), "bold"))
        x, y = s / 2 + r * math.cos(self.t), s / 2 + r * math.sin(self.t)
        for rad, col in ((max(2, s / 18), GOLD_DIM), (max(1.5, s / 26), GOLD), (max(1, s / 44), "#fff6d0")):
            self.create_oval(x - rad, y - rad, x + rad, y + rad, fill=col, outline="")

    def tick(self):
        if not alive(self):
            return
        self.t += 0.08
        self.draw()
        self.after(60, self.tick)


# ----------------------------------------------------------------- app ----
class DortressApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f"{core.APP_NAME} — {core.DEVELOPER}")
        self.configure(bg=BG)
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        w, h = min(1280, int(sw * 0.86)), min(860, int(sh * 0.86))
        self.geometry(f"{w}x{h}+{(sw - w) // 2}+{max(0, (sh - h) // 2 - 20)}")
        self.minsize(min(640, sw), min(500, sh))
        self.kb = core.Keybulk()
        self.dmk: bytes | None = None
        self.q: queue.Queue = queue.Queue()
        self.cancel_evt = threading.Event()
        self.busy = False
        self.last_activity = time.time()
        self.fail_count = 0
        self.last_mbps = None
        self.scroller: ScrollFrame | None = None
        self.shred = tk.IntVar(value=1)
        self._style()
        self.bind_all("<Key>", self._touch, add="+")
        self.bind_all("<Motion>", self._touch, add="+")
        self.bind_all("<MouseWheel>", self._wheel, add="+")
        self.bind_all("<Button-4>", self._wheel, add="+")
        self.bind_all("<Button-5>", self._wheel, add="+")
        self.bind_all("<Control-l>", lambda e: self.dmk and self.lock())
        self.protocol("WM_DELETE_WINDOW", self.on_close)
        self.after(60, self._poll)
        self.after(5000, self._autolock_check)
        self.show_auth()

    # ---------------------------------------------------------- plumbing --
    def _style(self):
        st = ttk.Style(self)
        try:
            st.theme_use("clam")
        except tk.TclError:
            pass
        st.configure("Gold.Vertical.TScrollbar", background=GOLD_DIM, troughcolor=BG,
                     bordercolor=BG, arrowcolor=GOLD, lightcolor=GOLD_DIM, darkcolor=GOLD_DIM,
                     gripcount=0, arrowsize=12)
        st.map("Gold.Vertical.TScrollbar", background=[("active", GOLD)])

    def _wheel(self, e):
        w = e.widget
        if isinstance(w, (tk.Text, tk.Listbox)) or self.scroller is None or not alive(self.scroller):
            return
        if getattr(e, "num", None) == 4:
            steps = -3
        elif getattr(e, "num", None) == 5:
            steps = 3
        else:
            steps = -3 if e.delta > 0 else 3
        self.scroller.wheel(steps)

    def _touch(self, _e=None):
        self.last_activity = time.time()

    def _autolock_check(self):
        if self.dmk and not self.busy and time.time() - self.last_activity > AUTO_LOCK_SECONDS:
            self.lock()
        self.after(5000, self._autolock_check)

    def clear(self):
        for w in self.winfo_children():
            if not isinstance(w, tk.Toplevel):
                w.destroy()

    def on_close(self):
        if self.busy and not messagebox.askyesno(
                core.APP_NAME, "A job is running. Cancel it and exit?\n\n"
                               "Files being processed are finished or rolled back safely.", parent=self):
            return
        self.cancel_evt.set()
        self.dmk = None
        self.destroy()

    def lock(self):
        if self.busy:
            messagebox.showinfo(core.APP_NAME, "Please wait for the current job to finish.", parent=self)
            return
        self.dmk = None
        self.show_auth()

    def modal(self, title):
        top = tk.Toplevel(self, bg=PANEL)
        top.title(title)
        top.transient(self)
        top.resizable(True, True)
        top.bind("<Escape>", lambda e: top.destroy())
        try:
            top.wait_visibility()
            top.grab_set()
        except tk.TclError:
            pass
        return top

    # -------------------------------------------------------------- auth --
    def show_auth(self):
        self.clear()
        self.scroller = ScrollFrame(self)
        self.scroller.pack(fill="both", expand=True)
        setup = not self.kb.exists()
        col = tk.Frame(self.scroller.inner, bg=BG)
        col.pack(pady=(30, 30), padx=16)
        Logo(col, 90).pack()
        tk.Label(col, text="DORTRESS  LOCKER", bg=BG, fg=GOLD_HI, font=(FONT_B, 24)).pack(pady=(8, 0))
        tk.Label(col, text="Fortress-grade file, folder & drive encryption", bg=BG, fg=MUTED,
                 font=(FONT, 10)).pack(pady=(2, 16))

        outer, box = card(col, "Create master password" if setup else "Unlock vault")
        outer.pack(fill="x")
        box.configure(width=420)
        status = tk.Label(box, text="", bg=PANEL, fg=RED, font=(FONT, 9), anchor="w", justify="left")

        if setup:
            wlabel(box, "Recommended: 10 numbers · 3 uppercase · 3 lowercase · 4 special characters. "
                        "This password protects everything and cannot be recovered if lost.",
                   fg=MUTED, font=(FONT, 9))
            tk.Label(box, text="Master password", bg=PANEL, fg=TEXT, font=(FONT_B, 9),
                     anchor="w").pack(fill="x", pady=(12, 4))
            meter = StrengthMeter(box)
            pw = PasswordEntry(box, meter.update_pw)
            pw.pack(fill="x")
            meter.pack(fill="x", pady=(8, 4))
            tk.Label(box, text="Confirm password", bg=PANEL, fg=TEXT, font=(FONT_B, 9),
                     anchor="w").pack(fill="x", pady=(8, 4))
            cf = PasswordEntry(box)
            cf.pack(fill="x")
            status.pack(fill="x", pady=(8, 0))

            def gen():
                g = core.generate_password()
                pw.set(g)
                cf.set(g)
                self.show_generated(g)

            def create():
                a, b = pw.get(), cf.get()
                if not core.policy_ok(a):
                    status.config(text="Needs at least 10 numbers, 3 uppercase, 3 lowercase and "
                                       "4 special characters.", fg=RED)
                    return
                if a != b:
                    status.config(text="Passwords do not match.", fg=RED)
                    return
                status.config(text="Creating vault (Argon2id)…", fg=GOLD)
                btn.set_enabled(False)
                self._auth_status, self._auth_btn = status, btn

                def work():
                    try:
                        self.q.put(("auth_ok", self.kb.create(a)))
                    except Exception as e:
                        self.q.put(("auth_err", str(e)))

                threading.Thread(target=work, daemon=True).start()

            row = tk.Frame(box, bg=PANEL)
            row.pack(fill="x", pady=(14, 0))
            GButton(row, "Generate strong password", gen, "ghost").pack(side="left")
            btn = GButton(row, "CREATE VAULT", create, "primary", padx=22)
            btn.pack(side="right")
            pw.entry.focus_set()
            pw.entry.bind("<Return>", lambda e: cf.entry.focus_set())
            cf.entry.bind("<Return>", lambda e: create())
        else:
            tk.Label(box, text="Master password", bg=PANEL, fg=TEXT, font=(FONT_B, 9),
                     anchor="w").pack(fill="x", pady=(4, 4))
            pw = PasswordEntry(box)
            pw.pack(fill="x")
            status.pack(fill="x", pady=(8, 0))

            def unlock():
                p = pw.get()
                if not p:
                    status.config(text="Enter your master password.", fg=AMBER)
                    return
                status.config(text="Unlocking (Argon2id)…", fg=GOLD)
                btn.set_enabled(False)
                delay = min(30, 2 ** self.fail_count - 1) if self.fail_count else 0
                self._auth_status, self._auth_btn = status, btn

                def work():
                    time.sleep(delay)
                    try:
                        self.q.put(("auth_ok", self.kb.unlock(p)))
                    except core.WrongPassword:
                        self.q.put(("auth_err", "Wrong master password."))
                    except Exception as e:
                        self.q.put(("auth_err", str(e)))

                threading.Thread(target=work, daemon=True).start()

            btn = GButton(box, "UNLOCK", unlock, "primary", size=11, pady=9)
            btn.pack(fill="x", pady=(14, 0))
            pw.entry.bind("<Return>", lambda e: unlock())
            pw.entry.focus_set()

        tk.Label(col, text=f"v{core.VERSION}  ·  {core.DEVELOPER}", bg=BG, fg=GOLD_DIM,
                 font=(FONT, 9)).pack(pady=(16, 0))

    def show_generated(self, pw):
        top = self.modal("Generated master password")
        tk.Label(top, text="Your generated master password", bg=PANEL, fg=GOLD,
                 font=(FONT_B, 11)).pack(padx=24, pady=(18, 6))
        tk.Label(top, text=pw, bg=PANEL2, fg=GOLD_HI, font=(MONO, 15), padx=14, pady=10).pack(padx=24)
        tk.Label(top, text="Write it down and keep it offline. It is never stored anywhere\n"
                           "and cannot be recovered if lost.",
                 bg=PANEL, fg=MUTED, font=(FONT, 9)).pack(padx=24, pady=10)
        row = tk.Frame(top, bg=PANEL)
        row.pack(pady=(0, 18))

        def copy():
            self.clipboard_clear()
            self.clipboard_append(pw)
            self.after(30000, lambda: (self.clipboard_clear(), self.clipboard_append("")))
            cbtn.config(text="Copied ✓")

        cbtn = GButton(row, "Copy (clears in 30 s)", copy, "ghost")
        cbtn.pack(side="left", padx=4)
        GButton(row, "I've saved it", top.destroy, "primary").pack(side="left", padx=4)

    # -------------------------------------------------------------- main --
    def show_main(self):
        self.clear()
        # top bar
        top = tk.Frame(self, bg=PANEL)
        top.pack(side="top", fill="x")
        tk.Frame(self, bg=GOLD_DIM, height=1).pack(side="top", fill="x")
        brand = tk.Frame(top, bg=PANEL)
        brand.pack(side="left", padx=(14, 10), pady=8)
        Logo(brand, 38).pack(side="left")
        self.brand_txt = tk.Label(brand, text="DORTRESS LOCKER", bg=PANEL, fg=GOLD_HI, font=(FONT_B, 13))
        self.brand_txt.pack(side="left", padx=(8, 0))
        GButton(top, "Lock", self.lock, "ghost", padx=14, pady=5).pack(side="right", padx=14)
        nav = tk.Frame(top, bg=PANEL)
        nav.pack(side="left", padx=6)
        self.nav = {}
        for key, label in (("home", "Home"), ("drives", "Drives"), ("security", "Security"),
                           ("about", "About")):
            b = tk.Button(nav, text=label, command=lambda k=key: self.show_page(k), bg=PANEL, fg=MUTED,
                          activebackground=PANEL3, activeforeground=GOLD_HI, relief="flat", bd=0,
                          font=(FONT_B, 10), padx=14, pady=6, cursor="hand2", highlightthickness=0)
            b.pack(side="left", padx=2)
            self.nav[key] = b
        top.bind("<Configure>", lambda e: (self.brand_txt.pack_forget() if e.width < 760
                                           else self.brand_txt.pack(side="left", padx=(8, 0))))

        # status dock (always visible)
        tk.Frame(self, bg=GOLD_DIM, height=1).pack(side="bottom", fill="x")
        dock = tk.Frame(self, bg=PANEL)
        dock.pack(side="bottom", fill="x")
        dinner = tk.Frame(dock, bg=PANEL)
        dinner.pack(fill="x", padx=16, pady=10)
        r1 = tk.Frame(dinner, bg=PANEL)
        r1.pack(fill="x")
        self.dock_title = tk.Label(r1, text="Ready", bg=PANEL, fg=GOLD_HI, font=(FONT_B, 11), anchor="w")
        self.dock_title.pack(side="left")
        self.dock_cancel = GButton(r1, "Cancel", self.cancel_job, "danger", padx=12, pady=3)
        self.dock_cancel.pack(side="right")
        self.dock_cancel.set_enabled(False)
        self.dock_speed = tk.Label(r1, text="", bg=PANEL, fg=GOLD, font=(MONO, 12))
        self.dock_speed.pack(side="right", padx=12)
        self.dock_bar = GoldProgress(dinner)
        self.dock_bar.pack(fill="x", pady=6)
        self.dock_detail = wlabel(dinner, f"AES-256-GCM · {core.CPU} CPU cores ready", fg=MUTED,
                                  font=(FONT, 9))

        # scrollable page area
        self.scroller = ScrollFrame(self)
        self.scroller.pack(side="top", fill="both", expand=True)
        self.page_host = tk.Frame(self.scroller.inner, bg=BG)
        self.page_host.pack(fill="both", expand=True, padx=22, pady=18)
        self.pages: dict = {}
        self.current_page = None
        self.show_page("home")
        self.write_log("info", f"Vault unlocked · keybulk {self.kb.key_id()}")

    def show_page(self, key):
        builders = {"home": self.page_home, "drives": self.page_drives,
                    "security": self.page_security, "about": self.page_about}
        for k, b in self.nav.items():
            b.config(fg=GOLD_HI if k == key else MUTED, bg=PANEL3 if k == key else PANEL)
        for w in self.page_host.winfo_children():
            w.pack_forget()
        if key == "home" and "home" in self.pages:
            page = self.pages["home"]          # keep log + settings
        else:
            if key in self.pages and key != "home":
                self.pages[key].destroy()
            page = tk.Frame(self.page_host, bg=BG)
            builders[key](page)
            self.pages[key] = page
        page.pack(fill="both", expand=True)
        self.current_page = key
        self.scroller.to_top()

    def heading(self, parent, title, sub=None):
        tk.Label(parent, text=title, bg=BG, fg=GOLD_HI, font=(FONT_B, 20), anchor="w").pack(fill="x")
        if sub:
            wlabel(parent, sub, fg=MUTED, pady=(2, 0))
        tk.Frame(parent, bg=GOLD_DIM, height=1).pack(fill="x", pady=(10, 16))

    def write_log(self, level, text):
        log = getattr(self, "log", None)
        if log is None or not alive(log):
            return
        log.config(state="normal")
        log.insert("end", time.strftime("%H:%M:%S  "), "time")
        log.insert("end", text + "\n", level)
        lines = int(log.index("end-1c").split(".")[0])
        if lines > 800:
            log.delete("1.0", f"{lines - 800}.0")
        log.see("end")
        log.config(state="disabled")

    # -------------------------------------------------------------- home --
    def action_tile(self, parent, glyph, title, desc, button, cmd, lock=True):
        outer = tk.Frame(parent, bg=PANEL, highlightthickness=1, highlightbackground=LINE, cursor="hand2")
        tk.Frame(outer, bg=GOLD if lock else GOLD_DIM, height=3).pack(fill="x")
        inner = tk.Frame(outer, bg=PANEL, cursor="hand2")
        inner.pack(fill="both", expand=True, padx=16, pady=14)
        g = tk.Label(inner, text=glyph, bg=PANEL, fg=GOLD if lock else GOLD_HI, font=(FONT_B, 22),
                     anchor="w", cursor="hand2")
        g.pack(fill="x")
        t = tk.Label(inner, text=title, bg=PANEL, fg=TEXT, font=(FONT_B, 13), anchor="w", cursor="hand2")
        t.pack(fill="x", pady=(2, 0))
        d = wlabel(inner, desc, fg=MUTED, font=(FONT, 9))
        d.config(cursor="hand2")
        GButton(inner, button, cmd, "primary" if lock else "ghost").pack(fill="x", pady=(12, 0))
        for w in (outer, inner, g, t, d):
            w.bind("<Button-1>", lambda e: cmd())
        outer.bind("<Enter>", lambda e: outer.config(highlightbackground=GOLD))
        outer.bind("<Leave>", lambda e: outer.config(highlightbackground=LINE))
        return outer

    def page_home(self, f):
        self.heading(f, "What would you like to do?",
                     "Pick an action. Your choice opens a file or folder picker, then the job runs "
                     "with live speed shown at the bottom.")
        tk.Label(f, text="LOCK", bg=BG, fg=GOLD, font=(FONT_B, 9), anchor="w").pack(fill="x", pady=(0, 6))
        g1 = FlowGrid(f, min_w=230)
        g1.pack(fill="x")
        g1.add(self.action_tile(g1, "◧", "Encrypt files", "Choose one or more files.",
                                "Encrypt files", lambda: self.pick("encrypt", "files")))
        g1.add(self.action_tile(g1, "▤", "Encrypt folder", "Everything inside, including sub-folders.",
                                "Encrypt folder", lambda: self.pick("encrypt", "folder")))
        g1.add(self.action_tile(g1, "⛁", "Encrypt drive", "D:, E:, USB sticks and external disks.",
                                "Encrypt drive", lambda: self.pick("encrypt", "drive")))

        tk.Label(f, text="UNLOCK", bg=BG, fg=GOLD, font=(FONT_B, 9), anchor="w").pack(fill="x", pady=(20, 6))
        g2 = FlowGrid(f, min_w=230)
        g2.pack(fill="x")
        g2.add(self.action_tile(g2, "◨", "Decrypt files", "Choose .dlock files to restore.",
                                "Decrypt files", lambda: self.pick("decrypt", "files"), lock=False))
        g2.add(self.action_tile(g2, "▥", "Decrypt folder", "Restore every locked file in a folder.",
                                "Decrypt folder", lambda: self.pick("decrypt", "folder"), lock=False))
        g2.add(self.action_tile(g2, "⛀", "Decrypt drive", "Restore every locked file on a drive.",
                                "Decrypt drive", lambda: self.pick("decrypt", "drive"), lock=False))

        outer, inner = card(f, "After encrypting, the original files are")
        outer.pack(fill="x", pady=(20, 0))
        modes = FlowGrid(inner, min_w=150, gap=8, bg=PANEL)
        modes.pack(fill="x")
        self.mode_btns = {}
        for n, name, _ in SHRED_MODES:
            b = tk.Button(modes, text=name if n == 0 else f"{name} · {n} pass{'es' if n > 1 else ''}",
                          command=lambda n=n: self.set_shred(n), relief="flat", bd=0,
                          font=(FONT_B, 10), pady=7, cursor="hand2", highlightthickness=1,
                          highlightbackground=GOLD_DIM)
            modes.add(b)
            self.mode_btns[n] = b
        self.mode_desc = wlabel(inner, "", fg=MUTED, font=(FONT, 9), pady=(8, 0))
        self.set_shred(self.shred.get())

        outer, inner = card(f, "Activity")
        outer.pack(fill="x", pady=(16, 0))
        self.log = tk.Text(inner, height=9, bg=PANEL, fg=MUTED, bd=0, font=(MONO, 9),
                           highlightthickness=0, wrap="word", state="disabled")
        self.log.pack(fill="x")
        for tag, col in (("ok", GREEN), ("warn", AMBER), ("err", RED), ("info", GOLD), ("time", GOLD_DIM)):
            self.log.tag_config(tag, foreground=col)

        wlabel(f, f"Never touched: system drive {core.system_drive() if core.IS_WINDOWS else '/'}, "
                  "Windows, Program Files, ProgramData, AppData, Recycle Bin, boot/recovery folders, "
                  "folders of running programs, and files that are in use.",
               fg=GOLD_DIM, font=(FONT, 9), pady=(14, 0))

    def set_shred(self, n):
        self.shred.set(n)
        for k, b in self.mode_btns.items():
            on = k == n
            b.config(bg=GOLD if on else PANEL2, fg="#0a0a0a" if on else MUTED,
                     activebackground=GOLD_HI if on else PANEL3, activeforeground="#0a0a0a" if on else GOLD)
        self.mode_desc.config(text=dict((m[0], m[2]) for m in SHRED_MODES)[n])

    # ------------------------------------------------------------ actions --
    def pick(self, mode, kind):
        if self.busy:
            messagebox.showinfo(core.APP_NAME, "A job is already running. Please wait or cancel it.",
                                parent=self)
            return
        if kind == "drive":
            self.pick_drive(mode)
            return
        if kind == "files":
            if mode == "decrypt":
                paths = filedialog.askopenfilenames(
                    parent=self, title="Select locked files",
                    filetypes=[("Dortress locked files", "*" + core.EXT), ("All files", "*.*")])
            else:
                paths = filedialog.askopenfilenames(parent=self, title="Select files to encrypt")
            targets = [os.path.abspath(p) for p in paths]
        else:
            d = filedialog.askdirectory(parent=self, title=f"Select folder to {mode}")
            targets = [os.path.abspath(d)] if d else []
        if not targets:
            return
        allowed = []
        for t in targets:
            ok, why = core.check_path_allowed(t)
            if ok:
                allowed.append(t)
            else:
                messagebox.showwarning("Protected location", f"{t}\n\n{why}. It will not be touched.",
                                       parent=self)
        if allowed:
            self.run_action(mode, allowed)

    def pick_drive(self, mode):
        try:
            drives = [d for d in core.list_drives()
                      if not d["is_system"] and d["type"] not in ("CD/DVD", "Network")
                      and core.check_path_allowed(d["path"])[0]]
        except Exception as e:
            messagebox.showerror(core.APP_NAME, f"Could not list drives: {e}", parent=self)
            return
        if not drives:
            messagebox.showinfo(core.APP_NAME, "No data or external drives found.\n\nConnect a USB "
                                "or external drive and try again. The system drive is always protected.",
                                parent=self)
            return
        top = self.modal("Choose a drive")
        tk.Label(top, text=f"Choose a drive to {mode}", bg=PANEL, fg=GOLD_HI,
                 font=(FONT_B, 13)).pack(padx=24, pady=(18, 10))
        for d in drives:
            used = d["total"] - d["free"]
            txt = (f"{d['path']}    {d['type']}  ·  {core.human_bytes(used)} used of "
                   f"{core.human_bytes(d['total'])}")
            GButton(top, txt, lambda p=d["path"]: (top.destroy(), self.confirm_drive(p, mode)),
                    "ghost", pady=9).pack(fill="x", padx=24, pady=3)
        GButton(top, "Cancel", top.destroy, "danger").pack(pady=(10, 18))

    def confirm_drive(self, path, mode):
        ok, why = core.check_path_allowed(path)
        if not ok:
            messagebox.showerror("Protected", why, parent=self)
            return
        label = path.rstrip("\\/") or path
        top = self.modal("Confirm drive")
        verb = "Encrypt every file on" if mode == "encrypt" else "Decrypt every locked file on"
        tk.Label(top, text=f"{verb} {label}", bg=PANEL, fg=GOLD_HI, font=(FONT_B, 13)).pack(
            padx=26, pady=(20, 6))
        tk.Label(top, text=f"Type  {label}  below to confirm.", bg=PANEL, fg=MUTED,
                 font=(FONT, 10)).pack(padx=26)
        var = tk.StringVar()
        e = tk.Entry(top, textvariable=var, bg=PANEL2, fg=GOLD_HI, insertbackground=GOLD,
                     font=(MONO, 14), justify="center", relief="flat", width=12)
        e.pack(pady=12, ipady=6)
        e.focus_set()
        err = tk.Label(top, text="", bg=PANEL, fg=RED, font=(FONT, 9))
        err.pack()

        def go():
            if var.get().strip().upper().rstrip("\\/") != label.upper():
                err.config(text=f"Please type {label} exactly.")
                return
            top.destroy()
            self.run_action(mode, [path], skip_confirm=False)

        e.bind("<Return>", lambda _e: go())
        row = tk.Frame(top, bg=PANEL)
        row.pack(pady=(6, 20))
        GButton(row, "Cancel", top.destroy, "ghost").pack(side="left", padx=4)
        GButton(row, "Continue", go, "primary").pack(side="left", padx=4)

    def run_action(self, mode, targets, skip_confirm=False):
        if self.busy or not self.dmk:
            return
        self.busy = True
        self.cancel_evt = threading.Event()
        self.dock_running(True, "Scanning…")
        self.write_log("info", f"Scanning {len(targets)} location(s) for {mode}ion…")

        def work():
            skipped = [0]

            def on_skip(p, why):
                skipped[0] += 1
                if skipped[0] <= 100:
                    self.q.put(("log", "warn", f"Skipped {p}  ({why})"))

            try:
                files = core.collect_files(targets, want_encrypted=(mode == "decrypt"), on_skip=on_skip)
                total = 0
                for fp in files:
                    try:
                        total += os.path.getsize(fp)
                    except OSError:
                        pass
                if skipped[0] > 100:
                    self.q.put(("log", "warn", f"…and {skipped[0] - 100} more skipped"))
                self.q.put(("scanned", mode, files, total, skipped[0]))
            except Exception as e:
                self.q.put(("job_fail", str(e)))

        threading.Thread(target=work, daemon=True).start()

    def _after_scan(self, mode, files, total, skipped):
        if self.cancel_evt.is_set():
            self._job_idle("Cancelled")
            return
        if not files:
            self._job_idle("Nothing to do")
            messagebox.showinfo(core.APP_NAME,
                                "No locked (.dlock) files were found there." if mode == "decrypt"
                                else "No files that can be encrypted were found there.", parent=self)
            return
        if mode == "encrypt":
            name = dict((m[0], m[1]) for m in SHRED_MODES)[self.shred.get()]
            if not messagebox.askyesno(
                    "Confirm encryption",
                    f"Encrypt {len(files):,} file(s) ({core.human_bytes(total)})?\n\n"
                    f"Originals will be removed using '{name}' mode.\n\n"
                    "Without your master password AND the keybulk file, nobody can recover them.",
                    icon="warning", parent=self):
                self._job_idle("Cancelled")
                return
        self.dock_running(True, f"{'Encrypting' if mode == 'encrypt' else 'Decrypting'} "
                                f"{len(files):,} file(s)…")
        dmk, cancel, passes = self.dmk, self.cancel_evt, self.shred.get()

        def work():
            try:
                res = core.run_job(mode, files, dmk, self.q.put, cancel, passes)
                res.skipped += skipped
                self.q.put(("job_done", mode, res))
            except Exception as e:
                self.q.put(("job_fail", str(e)))

        threading.Thread(target=work, daemon=True).start()

    def cancel_job(self):
        if self.busy:
            self.cancel_evt.set()
            self.dock_title.config(text="Cancelling…")
            self.write_log("warn", "Cancelling… files in progress are finished or rolled back safely.")

    def dock_running(self, on, title=""):
        self.dock_cancel.set_enabled(on)
        self.dock_title.config(text=title or "Ready")
        if on:
            self.dock_bar.busy = True
            self.dock_bar.set(0)
            self.dock_speed.config(text="")
            self.dock_detail.config(text="")

    def _job_idle(self, title):
        self.busy = False
        self.dock_bar.busy = False
        self.dock_bar.set(0)
        self.dock_running(False, title)
        self.dock_detail.config(text=f"AES-256-GCM · {core.CPU} CPU cores ready")

    # ------------------------------------------------------------ drives --
    def page_drives(self, f):
        self.heading(f, "Drives", "Encrypt or decrypt every file on a data or external drive. "
                                  "File-level encryption: the drive stays usable.")
        GButton(f, "Refresh", lambda: self.show_page("drives"), "ghost").pack(anchor="e", pady=(0, 10))
        try:
            drives = core.list_drives()
        except Exception as e:
            drives = []
            self.write_log("err", f"Drive scan failed: {e}")
        grid = FlowGrid(f, min_w=320)
        grid.pack(fill="x")
        for d in drives:
            outer, inner = card(grid, accent=GOLD_DIM if d["is_system"] else GOLD)
            grid.add(outer)
            tk.Label(inner, text=d["path"], bg=PANEL, fg=GOLD_HI, font=(FONT_B, 18), anchor="w").pack(fill="x")
            used = d["total"] - d["free"]
            tk.Label(inner, text=f"{d['type']} · {core.human_bytes(used)} used of {core.human_bytes(d['total'])}",
                     bg=PANEL, fg=TEXT, font=(FONT, 10), anchor="w").pack(fill="x")
            bar = GoldProgress(inner, 6)
            bar.pack(fill="x", pady=8)
            bar.set(used / d["total"] if d["total"] else 0)
            if d["is_system"]:
                tk.Label(inner, text="SYSTEM DRIVE — ALWAYS PROTECTED", bg=PANEL, fg=MUTED,
                         font=(FONT_B, 9), anchor="w").pack(fill="x", pady=(4, 0))
            elif d["type"] in ("CD/DVD", "Network"):
                tk.Label(inner, text="Not supported", bg=PANEL, fg=MUTED, font=(FONT_B, 9),
                         anchor="w").pack(fill="x")
            else:
                row = tk.Frame(inner, bg=PANEL)
                row.pack(fill="x")
                row.columnconfigure(0, weight=1)
                row.columnconfigure(1, weight=1)
                GButton(row, "Encrypt", lambda p=d["path"]: self.drive_action(p, "encrypt"),
                        "primary").grid(row=0, column=0, sticky="ew", padx=(0, 4))
                GButton(row, "Decrypt", lambda p=d["path"]: self.drive_action(p, "decrypt"),
                        "ghost").grid(row=0, column=1, sticky="ew", padx=(4, 0))
        if not drives:
            tk.Label(f, text="No drives found.", bg=BG, fg=MUTED, font=(FONT, 10)).pack(anchor="w")

    def drive_action(self, path, mode):
        if self.busy:
            messagebox.showinfo(core.APP_NAME, "A job is already running.", parent=self)
            return
        self.show_page("home")
        self.confirm_drive(path, mode)

    # ---------------------------------------------------------- security --
    def page_security(self, f):
        self.heading(f, "Security")
        grid = FlowGrid(f, min_w=400)
        grid.pack(fill="x")

        score, items = core.pq_assessment()
        outer, inner = card(grid, "Post-quantum readiness")
        grid.add(outer)
        top = tk.Frame(inner, bg=PANEL)
        top.pack(fill="x")
        ring = tk.Canvas(top, width=104, height=104, bg=PANEL, highlightthickness=0)
        ring.pack(side="left", anchor="n")
        ring.create_oval(8, 8, 96, 96, outline="#1f1d25", width=10)
        ring.create_arc(8, 8, 96, 96, start=90, extent=-359.9 * score / 10, style="arc",
                        outline=GOLD, width=10)
        ring.create_text(52, 47, text=f"{score:.1f}", fill=GOLD_HI, font=(FONT_B, 20))
        ring.create_text(52, 70, text="/ 10", fill=MUTED, font=(FONT, 9))
        lst = tk.Frame(top, bg=PANEL)
        lst.pack(side="left", fill="x", expand=True, padx=(12, 0))
        for text, got, mx in items:
            wlabel(lst, f"{'✓' if got == mx else '–'} {got:.1f}/{mx:.1f}  {text}",
                   fg=TEXT if got == mx else AMBER, font=(FONT, 8), pady=1)
        wlabel(inner, "Internal self-assessment of the design, not a third-party certification.",
               fg=MUTED, font=(FONT, 8), pady=(8, 0))

        outer, inner = card(grid, "Speed benchmark")
        grid.add(outer)
        big = tk.Label(inner, text=f"{self.last_mbps:,.0f} Mbps" if self.last_mbps else "—",
                       bg=PANEL, fg=GOLD_HI, font=(FONT_B, 24), anchor="w")
        big.pack(fill="x")
        res = wlabel(inner, "Measures raw AES-256-GCM speed on this computer.", fg=MUTED)

        def bench():
            bbtn.set_enabled(False)
            res.config(text="Running…")
            threading.Thread(target=lambda: self.q.put(("bench", core.benchmark(1.5), res, big, bbtn)),
                             daemon=True).start()

        bbtn = GButton(inner, "Run benchmark", bench, "ghost")
        bbtn.pack(anchor="w", pady=(10, 0))

        outer, inner = card(grid, "Change master password")
        grid.add(outer)
        wlabel(inner, "Only the keybulk is re-wrapped. Your locked files stay as they are.",
               fg=MUTED, font=(FONT, 9))
        fields = {}
        meter = StrengthMeter(inner)
        for key, lab in (("cur", "Current password"), ("new", "New password"),
                         ("cf", "Confirm new password")):
            tk.Label(inner, text=lab, bg=PANEL, fg=TEXT, font=(FONT_B, 9), anchor="w").pack(
                fill="x", pady=(8, 3))
            pe = PasswordEntry(inner, meter.update_pw if key == "new" else None)
            pe.pack(fill="x")
            fields[key] = pe
            if key == "new":
                meter.pack(fill="x", pady=(6, 0))
        msg = wlabel(inner, "", fg=RED, font=(FONT, 9), pady=(6, 0))

        def gen():
            g = core.generate_password()
            fields["new"].set(g)
            fields["cf"].set(g)
            self.show_generated(g)

        def change():
            cur, new, cf = (fields[k].get() for k in ("cur", "new", "cf"))
            if not core.policy_ok(new):
                msg.config(text="New password needs 10 numbers, 3 upper, 3 lower, 4 special.", fg=RED)
                return
            if new != cf:
                msg.config(text="New passwords do not match.", fg=RED)
                return
            if new == cur:
                msg.config(text="New password must differ from the current one.", fg=RED)
                return
            msg.config(text="Re-wrapping keybulk…", fg=GOLD)
            cbtn.set_enabled(False)

            def work():
                try:
                    self.kb.change_password(cur, new)
                    self.q.put(("pw_changed", msg, cbtn, fields))
                except core.WrongPassword:
                    self.q.put(("pw_err", msg, cbtn, "Current password is wrong."))
                except Exception as e:
                    self.q.put(("pw_err", msg, cbtn, str(e)))

            threading.Thread(target=work, daemon=True).start()

        row = tk.Frame(inner, bg=PANEL)
        row.pack(fill="x", pady=(10, 0))
        GButton(row, "Generate", gen, "ghost").pack(side="left")
        cbtn = GButton(row, "CHANGE PASSWORD", change, "primary")
        cbtn.pack(side="right")

        outer, inner = card(grid, "Keybulk backup")
        grid.add(outer)
        wlabel(inner, f"Key ID  {self.kb.key_id()}\n{self.kb.path}", font=(MONO, 9))
        wlabel(inner, "If this file is lost, locked data cannot be recovered. Keep a backup on "
                      "separate media, e.g. a USB stick kept somewhere safe.",
               fg=AMBER, font=(FONT, 9), pady=(6, 10))

        def backup():
            dest = filedialog.asksaveasfilename(parent=self, defaultextension=".dkb",
                                                initialfile="dortress-keybulk-backup.dkb",
                                                filetypes=[("Dortress keybulk", "*.dkb")])
            if dest:
                try:
                    self.kb.export_backup(dest)
                    self.write_log("ok", f"Keybulk backed up to {dest}")
                    messagebox.showinfo(core.APP_NAME, "Keybulk backup saved.", parent=self)
                except Exception as e:
                    messagebox.showerror(core.APP_NAME, str(e), parent=self)

        GButton(inner, "Back up keybulk", backup, "ghost").pack(anchor="w")

    # ------------------------------------------------------------- about --
    def page_about(self, f):
        self.heading(f, "About")
        outer, inner = card(f)
        outer.pack(fill="x")
        row = tk.Frame(inner, bg=PANEL)
        row.pack(fill="x")
        Logo(row, 100).pack(side="left")
        t = tk.Frame(row, bg=PANEL)
        t.pack(side="left", fill="x", expand=True, padx=18)
        tk.Label(t, text="DORTRESS LOCKER", bg=PANEL, fg=GOLD_HI, font=(FONT_B, 22), anchor="w").pack(fill="x")
        tk.Label(t, text=f"Version {core.VERSION}", bg=PANEL, fg=MUTED, font=(FONT, 10), anchor="w").pack(fill="x")
        tk.Label(t, text="Developed by", bg=PANEL, fg=MUTED, font=(FONT, 9), anchor="w").pack(fill="x", pady=(10, 0))
        wlabel(t, core.DEVELOPER, fg=GOLD, font=(FONT_B, 14))

        outer, inner = card(f, "Under the hood")
        outer.pack(fill="x", pady=(14, 0))
        for k, v in (
                ("Encryption", "AES-256-GCM, 4 MiB chunks encrypted in parallel on all CPU cores"),
                ("Integrity", "Every chunk authenticated; reordering, truncation and tampering rejected"),
                ("Per-file keys", "HKDF-SHA256 from the Data Master Key and a random 256-bit salt"),
                ("Master password", "Argon2id: 128 MiB memory, 3 iterations, 4 lanes"),
                ("Keybulk AEAD", "Data Master Key wrapped with AES-256-GCM; password changes re-wrap only"),
                ("Shredding", "Turbo / 1 / 3 / 7 passes of AES-CTR random data, random rename, delete"),
                ("Library", "pyca/cryptography (OpenSSL with AES-NI hardware acceleration)")):
            r = tk.Frame(inner, bg=PANEL)
            r.pack(fill="x", pady=3)
            tk.Label(r, text=k, bg=PANEL, fg=GOLD, font=(FONT_B, 10), width=15, anchor="nw").pack(side="left", anchor="n")
            wlabel(r, v, font=(FONT, 10))
        wlabel(f, "On SSDs and flash drives, wear-levelling means overwriting cannot guarantee "
                  "every old copy of a block is erased. For maximum assurance, also enable full-disk "
                  "encryption (BitLocker).", fg=MUTED, font=(FONT, 9), pady=(14, 0))
        wlabel(f, f"© {time.strftime('%Y')} {core.DEVELOPER}. All rights reserved.",
               fg=GOLD_DIM, font=(FONT, 9), pady=(6, 0))

    # -------------------------------------------------------------- events --
    def _poll(self):
        try:
            for _ in range(400):
                self._handle(self.q.get_nowait())
        except queue.Empty:
            pass
        except Exception as e:  # never let one bad event stop the UI loop
            print("event error:", e, file=sys.stderr)
        self.after(50, self._poll)

    def _handle(self, ev):
        kind = ev[0]
        if kind == "auth_ok":
            self.dmk = ev[1]
            self.fail_count = 0
            self.last_activity = time.time()
            self.show_main()
        elif kind == "auth_err":
            self.fail_count += 1
            if alive(self._auth_status):
                self._auth_status.config(text=ev[1], fg=RED)
                self._auth_btn.set_enabled(True)
        elif kind == "scanned":
            self._after_scan(*ev[1:])
        elif kind == "progress":
            _, done, total, mbps, name = ev
            frac = done / total if total else 1.0
            self.dock_bar.busy = False
            self.dock_bar.set(frac)
            self.dock_speed.config(text=f"{frac * 100:4.0f}%   {mbps:,.0f} Mbps")
            eta = ""
            if mbps > 0 and total:
                rem = (total - done) * 8 / 1e6 / mbps
                eta = f"  ·  about {int(rem // 60)}m {int(rem % 60):02d}s left"
            self.dock_detail.config(text=f"{core.human_bytes(done)} of {core.human_bytes(total)}{eta}  ·  {name}")
        elif kind == "log":
            self.write_log(ev[1], ev[2])
        elif kind == "job_done":
            _, mode, r = ev
            if r.bytes:
                self.last_mbps = r.mbps
            cancelled = self.cancel_evt.is_set()
            self._job_idle("Cancelled" if cancelled else "Done")
            self.dock_bar.set(1 if not cancelled else 0)
            summary = (f"{r.ok:,} file(s) {'encrypted' if mode == 'encrypt' else 'decrypted'} · "
                       f"{core.human_bytes(r.bytes)} in {r.seconds:.1f}s at {r.mbps:,.0f} Mbps")
            if r.failed or r.skipped:
                summary += f" · {r.failed} failed · {r.skipped} skipped"
            self.dock_detail.config(text=summary)
            self.write_log("ok" if not r.failed else "warn", summary)
            (messagebox.showwarning if r.failed else messagebox.showinfo)(
                core.APP_NAME, summary + ("\n\nSee Activity on the Home page for details." if r.failed or r.skipped else ""),
                parent=self)
        elif kind == "job_fail":
            self._job_idle("Failed")
            self.write_log("err", f"Job failed: {ev[1]}")
            messagebox.showerror(core.APP_NAME, f"Job failed:\n{ev[1]}", parent=self)
        elif kind == "bench":
            _, r, res, big, btn = ev
            self.write_log("info", f"Benchmark: {r['Mbps']:,.0f} Mbps AES-256-GCM")
            if alive(big):
                big.config(text=f"{r['Mbps']:,.0f} Mbps")
                res.config(text=f"{r['MBps']:,.0f} MB/s in memory on {r['threads']} threads. "
                                "Real-world speed is usually limited by your disk.")
                btn.set_enabled(True)
        elif kind == "pw_changed":
            _, msg, btn, fields = ev
            self.write_log("ok", "Master password changed (keybulk re-wrapped)")
            if alive(msg):
                for pe in fields.values():
                    pe.clear()
                msg.config(text="Master password changed. Back up the keybulk again.", fg=GREEN)
                btn.set_enabled(True)
        elif kind == "pw_err":
            _, msg, btn, text = ev
            if alive(msg):
                msg.config(text=text, fg=RED)
                btn.set_enabled(True)


def main():
    if WIN:
        try:
            import ctypes
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except Exception:
            pass
    app = DortressApp()
    app.mainloop()


if __name__ == "__main__":
    main()
