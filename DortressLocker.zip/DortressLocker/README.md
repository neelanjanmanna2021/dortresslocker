# Dortress Locker v1.0.0
**Developed by Dortress Technologies Private Limited**

Black & gold desktop app for encrypting files, folders and non-system drives with AES-256-GCM.

## Run (Windows)
1. Install Python 3.10+ from python.org (tick "Add Python to PATH"; Tkinter is included).
2. Double-click `run_windows.bat` (installs `cryptography` and `psutil`, then starts the app).
3. Optional: `build_exe.bat` makes a single `dist\DortressLocker.exe`.

## First launch
Create the master password. Policy: at least **10 numbers, 3 uppercase, 3 lowercase, 4 special**.
"Generate" makes one that fits. Password and confirm fields are masked with `*`.

## How the keys work (keybulk AEAD)
- Master password -> Argon2id (128 MiB, t=3, p=4) -> key-encryption key
- A random 256-bit Data Master Key is wrapped with AES-256-GCM in `%APPDATA%\DortressLocker\keybulk.dkb`
- Changing the master password re-wraps only that key; files are not re-encrypted
- Each file gets its own key via HKDF-SHA256 + random salt

**Back up the keybulk (Security page).** Lose it or the password and the data is gone for good.

## What it never touches
System drive (C:), Windows, Program Files, ProgramData, AppData, Recycle Bin, Recovery, boot/EFI,
folders of running programs/services (via psutil), locked/in-use files, system files, symlinks, junctions.

## Measured in testing (Linux test box)
- Raw AES-256-GCM: ~67,000 Mbps per core
- Encrypt + shred from disk (512 MB file): ~1,620 Mbps; decrypt ~4,800 Mbps
Real speed on your PC depends mainly on the disk (USB 2.0 drives cap near 300 Mbps).

## Honest limits
- File-level encryption, not BitLocker-style full-volume encryption.
- On SSDs/flash, overwrite shredding can't guarantee old blocks are gone (wear-levelling).
- The 9.5/10 post-quantum score is an internal self-assessment of the design, not a certification.
