# Dortress Locker v1.1.0
**Developed by Dortress Technologies Private Limited**

Black & gold desktop app for encrypting files, folders and non-system drives with AES-256-GCM.

## Run (Windows)
1. Install Python 3.10+ from python.org (tick "Add Python to PATH"; Tkinter is included).
2. Double-click `run_windows.bat` (installs `cryptography` and `psutil`, then starts the app).
3. Optional: `build_exe.bat` makes a single `dist\DortressLocker.exe`.

## Using it
Home has six one-click actions: **Encrypt files / folder / drive** and **Decrypt files / folder / drive**.
Choose one, pick what to lock, confirm, and watch progress and speed in the bar at the bottom.
Pick how originals are removed: Turbo (delete only, best for SSD/USB), Fast (1 pass), Strong (3), Paranoid (7).
The window fits any screen size; pages scroll and cards rearrange on small screens.

## First launch
Create the master password. Policy: at least **10 numbers, 3 uppercase, 3 lowercase, 4 special**.
"Generate" makes one that fits. Password and confirm fields are masked with `*`.

## How the keys work (keybulk AEAD)
- Master password -> Argon2id (128 MiB, t=3, p=4) -> key-encryption key
- A random 256-bit Data Master Key is wrapped with AES-256-GCM in `%APPDATA%\DortressLocker\keybulk.dkb`
- Changing the master password re-wraps only that key; files are not re-encrypted
- Each file gets its own key via HKDF-SHA256 + random salt

**Back up the keybulk (Security page).** Lose it or the password and the data is gone for good.

## What it never touches
System drive (C:), Windows, Program Files, ProgramData, AppData, Recycle Bin, Recovery, boot/EFI,
folders of running programs/services (via psutil), locked/in-use files, system files, symlinks, junctions.

## Measured in testing (2-core Linux test box, 1 GB file)
- Encrypt + 1-pass shred: ~2,430 Mbps (v1.0 was ~1,370)
- Encrypt in Turbo mode: ~3,890 Mbps · Decrypt: ~4,400 Mbps
- Raw AES-256-GCM: ~130,000 Mbps across 2 cores (chunks now run on all cores)
Real speed on your PC depends mainly on the disk (USB 2.0 drives cap near 300 Mbps).
Files locked with v1.0 open normally in v1.1.

## Honest limits
- File-level encryption, not BitLocker-style full-volume encryption.
- On SSDs/flash, overwrite shredding can't guarantee old blocks are gone (wear-levelling).
- The 9.5/10 post-quantum score is an internal self-assessment of the design, not a certification.
