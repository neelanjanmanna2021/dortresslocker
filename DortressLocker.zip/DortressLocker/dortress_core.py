"""
Dortress Locker - core encryption engine
(c) Dortress Technologies Private Limited

Design
------
* Master password --Argon2id--> KEK  (memory-hard, GPU/ASIC resistant)
* KEK --AES-256-GCM--> wraps a random 256-bit Data Master Key (DMK)
  stored in the "Keybulk" file.  Changing the master password only
  re-wraps the DMK (the internal "keybulk AEAD" feature) - no file needs
  to be re-encrypted.
* Every file gets its own key:  HKDF-SHA256(DMK, random 256-bit salt)
* Files are streamed in 4 MiB chunks with AES-256-GCM.  Each chunk's
  nonce is unique, and the chunk index + "final chunk" flag + header are
  bound as AAD, so reordering, truncation or tampering is detected.
* Original file name/size/mtime are stored encrypted inside the file.
* After a verified encryption, the plaintext original is overwritten
  with random data, renamed to a random name, and deleted (shredded).
"""
from __future__ import annotations

import base64
import json
import math
import os
import secrets
import stat
import string
import struct
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Iterable, Optional

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.argon2 import Argon2id
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

try:  # optional: lets us protect folders of running services/processes
    import psutil  # type: ignore
except Exception:  # pragma: no cover
    psutil = None

APP_NAME = "Dortress Locker"
VERSION = "1.0.0"
DEVELOPER = "Dortress Technologies Private Limited"

EXT = ".dlock"
MAGIC = b"DTLK"
FORMAT_VERSION = 1
CHUNK = 4 * 1024 * 1024
MAX_CHUNK = 64 * 1024 * 1024
TAG = 16
HEADER_FMT = ">4sBB32s12sI"  # magic, version, flags, salt, base nonce, chunk size
HEADER_LEN = struct.calcsize(HEADER_FMT)

KDF_PARAMS = {"alg": "argon2id", "t": 3, "m_kib": 131072, "p": 4}  # 128 MiB

IS_WINDOWS = os.name == "nt"


class LockerError(Exception):
    pass


class WrongPassword(LockerError):
    pass


# --------------------------------------------------------------------------
# Password policy & strength meter
# --------------------------------------------------------------------------
SPECIALS = "!@#$%^&*()-_=+[]{};:,.?/<>~|"
POLICY = {"digits": 10, "upper": 3, "lower": 3, "special": 4}


def policy_status(pw: str) -> dict:
    counts = {
        "digits": sum(c.isdigit() for c in pw),
        "upper": sum(c.isupper() for c in pw),
        "lower": sum(c.islower() for c in pw),
        "special": sum((not c.isalnum()) and not c.isspace() for c in pw),
    }
    return {k: (counts[k], POLICY[k], counts[k] >= POLICY[k]) for k in POLICY}


def policy_ok(pw: str) -> bool:
    return all(v[2] for v in policy_status(pw).values())


def password_strength(pw: str) -> tuple[int, str, float]:
    """Return (score 0-100, label, estimated entropy bits)."""
    if not pw:
        return 0, "Empty", 0.0
    pool = 0
    if any(c.islower() for c in pw):
        pool += 26
    if any(c.isupper() for c in pw):
        pool += 26
    if any(c.isdigit() for c in pw):
        pool += 10
    if any(not c.isalnum() for c in pw):
        pool += 32
    bits = len(pw) * math.log2(max(pool, 2))
    # penalties: repeats and sequences
    unique_ratio = len(set(pw)) / len(pw)
    bits *= 0.55 + 0.45 * unique_ratio
    seq = sum(
        1 for a, b, c in zip(pw, pw[1:], pw[2:]) if ord(b) - ord(a) == 1 and ord(c) - ord(b) == 1
    )
    bits -= seq * 4
    lowered = pw.lower()
    for bad in ("password", "qwerty", "admin", "dortress", "123456", "letmein", "welcome"):
        if bad in lowered:
            bits -= 25
    bits = max(bits, 0.0)
    score = int(min(100, bits / 1.3))
    if not policy_ok(pw):
        score = min(score, 59)
    label = (
        "Very weak" if score < 20 else
        "Weak" if score < 40 else
        "Fair" if score < 60 else
        "Strong" if score < 80 else
        "Fortress-grade"
    )
    return score, label, bits


def generate_password() -> str:
    """10 digits + 3 upper + 3 lower + 4 special, shuffled with a CSPRNG."""
    rng = secrets.SystemRandom()
    chars = (
        [secrets.choice(string.digits) for _ in range(POLICY["digits"])]
        + [secrets.choice(string.ascii_uppercase) for _ in range(POLICY["upper"])]
        + [secrets.choice(string.ascii_lowercase) for _ in range(POLICY["lower"])]
        + [secrets.choice(SPECIALS) for _ in range(POLICY["special"])]
    )
    rng.shuffle(chars)
    return "".join(chars)


# --------------------------------------------------------------------------
# Keybulk: master-password-wrapped Data Master Key
# --------------------------------------------------------------------------
def app_data_dir() -> Path:
    if IS_WINDOWS:
        base = Path(os.environ.get("APPDATA", Path.home() / "AppData" / "Roaming"))
    else:
        base = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config"))
    d = base / "DortressLocker"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _derive_kek(password: str, salt: bytes, params: dict) -> bytes:
    return Argon2id(
        salt=salt,
        length=32,
        iterations=params["t"],
        lanes=params["p"],
        memory_cost=params["m_kib"],
    ).derive(password.encode("utf-8"))


def _b64(b: bytes) -> str:
    return base64.b64encode(b).decode()


def _ub64(s: str) -> bytes:
    return base64.b64decode(s.encode())


class Keybulk:
    """The vault holding the wrapped Data Master Key."""

    def __init__(self, path: Optional[Path] = None):
        self.path = Path(path) if path else app_data_dir() / "keybulk.dkb"

    def exists(self) -> bool:
        return self.path.exists()

    @staticmethod
    def _aad(params: dict, salt: bytes, key_id: str) -> bytes:
        return json.dumps(
            {"v": 1, "kdf": params, "salt": _b64(salt), "key_id": key_id}, sort_keys=True
        ).encode()

    def _wrap_and_save(self, password: str, dmk: bytes, key_id: str, created: float) -> None:
        params = dict(KDF_PARAMS)
        salt = os.urandom(32)
        nonce = os.urandom(12)
        kek = _derive_kek(password, salt, params)
        ct = AESGCM(kek).encrypt(nonce, dmk, self._aad(params, salt, key_id))
        doc = {
            "format": "dortress-keybulk",
            "v": 1,
            "kdf": params,
            "salt": _b64(salt),
            "nonce": _b64(nonce),
            "wrapped_dmk": _b64(ct),
            "key_id": key_id,
            "created": created,
            "updated": time.time(),
        }
        tmp = self.path.with_suffix(".tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(doc, f, indent=2)
            f.flush()
            os.fsync(f.fileno())
        if self.path.exists():
            bak = self.path.with_suffix(".bak")
            try:
                os.replace(self.path, bak)
            except OSError:
                pass
        os.replace(tmp, self.path)

    def create(self, password: str) -> bytes:
        if not policy_ok(password):
            raise LockerError("Master password does not meet the Dortress policy.")
        dmk = os.urandom(32)
        self._wrap_and_save(password, dmk, secrets.token_hex(8), time.time())
        return dmk

    def _load(self) -> dict:
        with open(self.path, "r", encoding="utf-8") as f:
            doc = json.load(f)
        if doc.get("format") != "dortress-keybulk":
            raise LockerError("Not a Dortress keybulk file.")
        return doc

    def unlock(self, password: str) -> bytes:
        doc = self._load()
        salt = _ub64(doc["salt"])
        kek = _derive_kek(password, salt, doc["kdf"])
        try:
            return AESGCM(kek).decrypt(
                _ub64(doc["nonce"]), _ub64(doc["wrapped_dmk"]),
                self._aad(doc["kdf"], salt, doc["key_id"]),
            )
        except InvalidTag:
            raise WrongPassword("Wrong master password.") from None

    def change_password(self, old: str, new: str) -> bytes:
        if not policy_ok(new):
            raise LockerError("New master password does not meet the Dortress policy.")
        doc = self._load()
        dmk = self.unlock(old)
        self._wrap_and_save(new, dmk, doc["key_id"], doc.get("created", time.time()))
        return dmk

    def key_id(self) -> str:
        return self._load().get("key_id", "?")

    def export_backup(self, dest: Path) -> None:
        data = self.path.read_bytes()
        Path(dest).write_bytes(data)


# --------------------------------------------------------------------------
# Safety guards: never touch the system drive, Windows, or service folders
# --------------------------------------------------------------------------
PROTECTED_NAMES = {
    "windows", "program files", "program files (x86)", "programdata",
    "$recycle.bin", "system volume information", "recovery", "boot", "efi",
    "$windows.~bt", "$windows.~ws", "windowsapps", "appdata", "msocache",
    "pagefile.sys", "hiberfil.sys", "swapfile.sys", "bootmgr", "dumpstack.log.tmp",
    "config.msi", "perflogs", "intel", "amd", "nvidia",
}
POSIX_PROTECTED = [
    "/bin", "/boot", "/dev", "/etc", "/lib", "/lib32", "/lib64", "/proc", "/run",
    "/sbin", "/sys", "/usr", "/var", "/opt", "/snap", "/srv", "/root",
    "/System", "/Library", "/Applications", "/private",
]
FILE_ATTRIBUTE_SYSTEM = 0x4
FILE_ATTRIBUTE_REPARSE_POINT = 0x400

_proc_cache: dict = {"t": 0.0, "dirs": set()}
_proc_lock = threading.Lock()


def system_drive() -> str:
    return os.environ.get("SystemDrive", "C:").upper()


def running_process_dirs() -> set:
    """Folders containing executables of running processes/services."""
    if psutil is None:
        return set()
    with _proc_lock:
        if time.time() - _proc_cache["t"] < 30:
            return _proc_cache["dirs"]
        dirs = set()
        for p in psutil.process_iter(["exe"]):
            try:
                exe = p.info.get("exe")
                if exe:
                    dirs.add(os.path.normcase(os.path.dirname(os.path.abspath(exe))))
            except Exception:
                continue
        _proc_cache.update(t=time.time(), dirs=dirs)
        return dirs


def check_path_allowed(path) -> tuple[bool, str]:
    p = os.path.abspath(str(path))
    if IS_WINDOWS:
        drive, _ = os.path.splitdrive(p)
        if not drive or drive.startswith("\\\\"):
            return False, "Network/UNC paths are not supported"
        if drive.upper() == system_drive():
            return False, f"System drive {system_drive()} is never touched"
    else:
        if p == "/":
            return False, "Filesystem root is protected"
        for root in POSIX_PROTECTED:
            if p == root or p.startswith(root + "/"):
                return False, f"System location {root} is protected"
    parts = {part.lower() for part in Path(p).parts}
    hit = parts & PROTECTED_NAMES
    if hit:
        return False, f"Protected system folder '{sorted(hit)[0]}'"
    try:
        if Path(p).resolve().is_relative_to(app_data_dir().resolve()):
            return False, "Dortress Locker's own vault is protected"
    except Exception:
        pass
    nc = os.path.normcase(p)
    for d in running_process_dirs():
        if nc == d or nc.startswith(d + os.sep):
            return False, "Folder belongs to a running program/service"
    return True, "ok"


def _skip_entry(path: str) -> Optional[str]:
    try:
        st = os.stat(path, follow_symlinks=False)
    except OSError as e:
        return f"cannot stat ({e.strerror})"
    if stat.S_ISLNK(st.st_mode):
        return "symbolic link"
    attrs = getattr(st, "st_file_attributes", 0)
    if attrs & FILE_ATTRIBUTE_REPARSE_POINT:
        return "junction/reparse point"
    if attrs & FILE_ATTRIBUTE_SYSTEM:
        return "system file"
    return None


def collect_files(targets: Iterable, want_encrypted: bool,
                  on_skip: Callable[[str, str], None] = lambda p, r: None) -> list:
    """Expand files/folders into a list of files to process, applying guards."""
    out, seen = [], set()

    def consider(fp: str):
        key = os.path.normcase(os.path.abspath(fp))
        if key in seen:
            return
        seen.add(key)
        is_enc = fp.lower().endswith(EXT)
        if want_encrypted != is_enc:
            return
        if fp.lower().endswith(EXT + ".part"):
            return
        ok, why = check_path_allowed(fp)
        if not ok:
            on_skip(fp, why)
            return
        r = _skip_entry(fp)
        if r:
            on_skip(fp, r)
            return
        out.append(fp)

    for t in targets:
        t = os.path.abspath(str(t))
        ok, why = check_path_allowed(t)
        if not ok:
            on_skip(t, why)
            continue
        if os.path.isfile(t):
            consider(t)
        elif os.path.isdir(t):
            for root, dirs, files in os.walk(t, followlinks=False):
                keep = []
                for d in dirs:
                    full = os.path.join(root, d)
                    okd, whyd = check_path_allowed(full)
                    r = _skip_entry(full)
                    if okd and not r:
                        keep.append(d)
                    else:
                        on_skip(full, whyd if not okd else r)
                dirs[:] = keep
                for f in files:
                    consider(os.path.join(root, f))
    return out


# --------------------------------------------------------------------------
# File encryption / decryption
# --------------------------------------------------------------------------
def _file_key(dmk: bytes, salt: bytes) -> bytes:
    return HKDF(algorithm=hashes.SHA256(), length=32, salt=salt,
                info=b"dortress-locker/file-key/v1").derive(dmk)


def _nonce(base: bytes, idx: int) -> bytes:
    ctr = int.from_bytes(base[4:], "big") ^ idx
    return base[:4] + ctr.to_bytes(8, "big")


def _aad(header: bytes, idx: int, final: bool) -> bytes:
    return header + struct.pack(">QB", idx, 1 if final else 0)


def unique_path(p: Path) -> Path:
    if not p.exists():
        return p
    stem, suf = p.stem, p.suffix
    i = 1
    while True:
        cand = p.with_name(f"{stem} ({i}){suf}")
        if not cand.exists():
            return cand
        i += 1


def shred_file(path, passes: int = 1, chunk: int = CHUNK) -> None:
    """Overwrite with random data, rename to a random name, then delete."""
    p = Path(path)
    try:
        os.chmod(p, stat.S_IREAD | stat.S_IWRITE)
    except OSError:
        pass
    size = p.stat().st_size
    with open(p, "r+b", buffering=0) as f:
        for _ in range(max(1, passes)):
            f.seek(0)
            remaining = size
            while remaining > 0:
                n = min(chunk, remaining)
                f.write(os.urandom(n))
                remaining -= n
            os.fsync(f.fileno())
        f.truncate(0)
        os.fsync(f.fileno())
    rnd = p.with_name(secrets.token_hex(12))
    os.replace(p, rnd)
    os.remove(rnd)


ProgressCB = Optional[Callable[[int], None]]
CancelFlag = Optional[threading.Event]


def encrypt_file(src, dmk: bytes, progress: ProgressCB = None,
                 shred_passes: int = 1, cancel: CancelFlag = None) -> Path:
    src = Path(src)
    st = src.stat()
    salt, base = os.urandom(32), os.urandom(12)
    header = struct.pack(HEADER_FMT, MAGIC, FORMAT_VERSION, 0, salt, base, CHUNK)
    aead = AESGCM(_file_key(dmk, salt))
    dst = unique_path(src.with_name(src.name + EXT))
    tmp = dst.with_name(dst.name + ".part")
    meta = json.dumps({"name": src.name, "size": st.st_size, "mtime": st.st_mtime}).encode()
    n_chunks = max(1, math.ceil(st.st_size / CHUNK))
    try:
        # Opening for r+b first fails fast on files locked by running programs.
        with open(src, "r+b") as fi, open(tmp, "wb") as fo:
            fo.write(header)
            mct = aead.encrypt(_nonce(base, 0), meta, _aad(header, 0, False))
            fo.write(struct.pack(">I", len(mct)))
            fo.write(mct)
            buf = bytearray(CHUNK)
            mv = memoryview(buf)
            for i in range(n_chunks):
                if cancel is not None and cancel.is_set():
                    raise LockerError("Cancelled")
                n = fi.readinto(buf)
                final = i == n_chunks - 1
                if n != CHUNK and not final:
                    raise LockerError("File changed while encrypting")
                fo.write(aead.encrypt(_nonce(base, i + 1), mv[:n], _aad(header, i + 1, final)))
                if progress:
                    progress(n)
            if fi.read(1):
                raise LockerError("File grew while encrypting")
            fo.flush()
            os.fsync(fo.fileno())
        os.replace(tmp, dst)
    except BaseException:
        try:
            tmp.unlink()
        except OSError:
            pass
        raise
    shred_file(src, shred_passes)
    return dst


def read_encrypted_meta(src, dmk: bytes) -> dict:
    with open(src, "rb") as fi:
        header, aead, base, _ = _open_header(fi, dmk)
        return _read_meta(fi, aead, base, header)


def _open_header(fi, dmk):
    header = fi.read(HEADER_LEN)
    if len(header) != HEADER_LEN:
        raise LockerError("Not a Dortress file (too short)")
    magic, ver, _flags, salt, base, chunk = struct.unpack(HEADER_FMT, header)
    if magic != MAGIC:
        raise LockerError("Not a Dortress Locker file")
    if ver != FORMAT_VERSION:
        raise LockerError(f"Unsupported format version {ver}")
    if not (1024 <= chunk <= MAX_CHUNK):
        raise LockerError("Corrupt header")
    return header, AESGCM(_file_key(dmk, salt)), base, chunk


def _read_meta(fi, aead, base, header) -> dict:
    raw = fi.read(4)
    if len(raw) != 4:
        raise LockerError("Corrupt file")
    (mlen,) = struct.unpack(">I", raw)
    if mlen > 65536:
        raise LockerError("Corrupt metadata")
    try:
        meta = json.loads(aead.decrypt(_nonce(base, 0), fi.read(mlen), _aad(header, 0, False)))
    except InvalidTag:
        raise WrongPassword("Authentication failed: wrong key or tampered file") from None
    return meta


def decrypt_file(src, dmk: bytes, progress: ProgressCB = None,
                 cancel: CancelFlag = None) -> Path:
    src = Path(src)
    total = src.stat().st_size
    with open(src, "rb") as fi:
        header, aead, base, chunk = _open_header(fi, dmk)
        meta = _read_meta(fi, aead, base, header)
        name = Path(str(meta.get("name", ""))).name
        if not name or name in (".", ".."):
            name = src.name[: -len(EXT)] if src.name.lower().endswith(EXT) else src.name + ".out"
        dst = unique_path(src.with_name(name))
        tmp = dst.with_name(dst.name + ".dlock.part")
        data_len = total - fi.tell()
        rec = chunk + TAG
        n = math.ceil(data_len / rec)
        if n < 1:
            raise LockerError("Truncated file")
        written = 0
        try:
            with open(tmp, "wb") as fo:
                for i in range(n):
                    if cancel is not None and cancel.is_set():
                        raise LockerError("Cancelled")
                    ct = fi.read(rec)
                    try:
                        pt = aead.decrypt(_nonce(base, i + 1), ct, _aad(header, i + 1, i == n - 1))
                    except InvalidTag:
                        raise LockerError("Integrity check failed: file is corrupt, "
                                          "truncated or tampered") from None
                    fo.write(pt)
                    written += len(pt)
                    if progress:
                        progress(len(pt))
                if written != meta.get("size", written):
                    raise LockerError("Size mismatch after decryption")
                fo.flush()
                os.fsync(fo.fileno())
            os.replace(tmp, dst)
        except BaseException:
            try:
                tmp.unlink()
            except OSError:
                pass
            raise
    try:
        mt = float(meta.get("mtime", 0))
        if mt:
            os.utime(dst, (mt, mt))
    except Exception:
        pass
    os.remove(src)
    return dst


# --------------------------------------------------------------------------
# Batch jobs with throughput reporting
# --------------------------------------------------------------------------
@dataclass
class JobResult:
    ok: int = 0
    failed: int = 0
    skipped: int = 0
    bytes: int = 0
    seconds: float = 0.0
    errors: list = field(default_factory=list)

    @property
    def mbps(self) -> float:
        return (self.bytes * 8 / 1e6) / self.seconds if self.seconds > 0 else 0.0


def run_job(mode: str, files: list, dmk: bytes, emit: Callable[[tuple], None],
            cancel: threading.Event, shred_passes: int = 1, workers: Optional[int] = None) -> JobResult:
    """mode: 'encrypt' | 'decrypt'.  emit receives ('progress', done, total, rate_mbps, name)
    and ('log', level, text) tuples. Runs files in parallel worker threads."""
    total = 0
    for f in files:
        try:
            total += os.path.getsize(f)
        except OSError:
            pass
    res = JobResult()
    done = [0]
    lock = threading.Lock()
    t0 = time.perf_counter()
    last = [0.0]

    def prog(n, name):
        with lock:
            done[0] += n
            now = time.perf_counter()
            if now - last[0] > 0.08 or done[0] >= total:
                last[0] = now
                el = max(now - t0, 1e-6)
                emit(("progress", done[0], total, done[0] * 8 / 1e6 / el, name))

    def work(fp):
        name = os.path.basename(fp)
        if mode == "encrypt":
            return encrypt_file(fp, dmk, lambda n: prog(n, name), shred_passes, cancel)
        return decrypt_file(fp, dmk, lambda n: prog(n, name), cancel)

    workers = workers or max(2, min(8, (os.cpu_count() or 4)))
    with ThreadPoolExecutor(max_workers=workers) as ex:
        futs = {ex.submit(work, f): f for f in files}
        for fut in as_completed(futs):
            fp = futs[fut]
            try:
                out = fut.result()
                res.ok += 1
                emit(("log", "ok", f"{'Locked' if mode == 'encrypt' else 'Unlocked'}: {out}"))
            except PermissionError:
                res.skipped += 1
                emit(("log", "warn", f"Skipped (in use / no permission): {fp}"))
            except Exception as e:  # noqa
                if cancel.is_set():
                    res.skipped += 1
                else:
                    res.failed += 1
                    res.errors.append((fp, str(e)))
                    emit(("log", "err", f"Failed: {fp} - {e}"))
    res.seconds = time.perf_counter() - t0
    res.bytes = done[0]
    return res


def benchmark(seconds: float = 1.5, threads: Optional[int] = None) -> dict:
    """In-memory AES-256-GCM throughput (pure crypto speed, no disk)."""
    threads = threads or max(1, min(8, os.cpu_count() or 1))
    key = AESGCM.generate_key(256)
    data = os.urandom(CHUNK)
    counts = [0] * threads
    stop = threading.Event()

    def worker(i):
        a = AESGCM(key)
        base = os.urandom(12)
        j = 0
        while not stop.is_set():
            a.encrypt(_nonce(base, j), data, None)
            j += 1
            counts[i] += len(data)

    ts = [threading.Thread(target=worker, args=(i,), daemon=True) for i in range(threads)]
    t0 = time.perf_counter()
    for t in ts:
        t.start()
    time.sleep(seconds)
    stop.set()
    for t in ts:
        t.join()
    el = time.perf_counter() - t0
    b = sum(counts)
    return {"threads": threads, "MBps": b / el / 1e6, "Mbps": b * 8 / el / 1e6}


# --------------------------------------------------------------------------
# Drives
# --------------------------------------------------------------------------
def list_drives() -> list:
    """Return dicts: letter/path, label type, total, free, is_system."""
    drives = []
    if IS_WINDOWS:
        import ctypes
        kinds = {2: "Removable", 3: "Fixed", 4: "Network", 5: "CD/DVD", 6: "RAM disk"}
        mask = ctypes.windll.kernel32.GetLogicalDrives()
        for i, letter in enumerate(string.ascii_uppercase):
            if not mask & (1 << i):
                continue
            root = f"{letter}:\\"
            kind = kinds.get(ctypes.windll.kernel32.GetDriveTypeW(root), "Unknown")
            try:
                import shutil
                du = shutil.disk_usage(root)
                tot, free = du.total, du.free
            except OSError:
                continue
            drives.append({"path": root, "type": kind, "total": tot, "free": free,
                           "is_system": f"{letter}:" == system_drive()})
    else:
        import shutil
        cands = ["/"]
        for base in ("/media", "/mnt", "/Volumes", f"/run/media/{os.environ.get('USER', '')}"):
            if os.path.isdir(base):
                for d in sorted(os.listdir(base)):
                    full = os.path.join(base, d)
                    if os.path.isdir(full):
                        cands.append(full)
        for c in cands:
            try:
                du = shutil.disk_usage(c)
            except OSError:
                continue
            drives.append({"path": c, "type": "Mount", "total": du.total, "free": du.free,
                           "is_system": c == "/"})
    return drives


# --------------------------------------------------------------------------
# Post-quantum readiness self-assessment (transparent scoring)
# --------------------------------------------------------------------------
def pq_assessment() -> tuple[float, list]:
    items = [
        ("AES-256 symmetric core (Grover's algorithm leaves ~128-bit security)", 2.0, 2.0),
        ("No RSA / ECC anywhere in the data path (immune to Shor's algorithm)", 2.0, 2.0),
        ("Argon2id memory-hard password KDF (128 MiB, t=3)", 1.5, 1.5),
        ("256-bit keys from the OS CSPRNG, unique key per file (HKDF-SHA256)", 1.5, 1.5),
        ("AEAD with chunk binding: tamper, reorder & truncation detection", 1.5, 1.5),
        ("Key rotation by re-wrapping (keybulk AEAD) without re-encrypting data", 1.0, 1.0),
        ("No hybrid ML-KEM (FIPS 203) for sharing keys with other users", 0.0, 0.5),
    ]
    score = sum(i[1] for i in items)
    return score, items


def human_bytes(n: float) -> str:
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if abs(n) < 1024 or unit == "TB":
            return f"{n:.1f} {unit}" if unit != "B" else f"{int(n)} B"
        n /= 1024
    return f"{n:.1f} TB"
