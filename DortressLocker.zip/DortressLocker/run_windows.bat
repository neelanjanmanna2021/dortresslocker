@echo off
title Dortress Locker
cd /d "%~dp0"
python -m pip install --upgrade -r requirements.txt
python dortress_locker.py
pause
