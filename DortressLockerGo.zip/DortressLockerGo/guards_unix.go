//go:build !windows

package main

import (
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"sort"
	"syscall"
)

func platformSkip(st os.FileInfo) string { return "" }

func processExePaths() []string {
	ents, err := os.ReadDir("/proc")
	if err != nil {
		return nil
	}
	var out []string
	for _, e := range ents {
		if exe, err := os.Readlink(filepath.Join("/proc", e.Name(), "exe")); err == nil {
			out = append(out, exe)
		}
	}
	return out
}

func ListDrives() []Drive {
	cands := []string{"/"}
	for _, base := range []string{"/media", "/mnt", "/Volumes", "/run/media/" + os.Getenv("USER")} {
		ents, err := os.ReadDir(base)
		if err != nil {
			continue
		}
		names := []string{}
		for _, e := range ents {
			if e.IsDir() {
				names = append(names, e.Name())
			}
		}
		sort.Strings(names)
		for _, n := range names {
			cands = append(cands, filepath.Join(base, n))
		}
	}
	var out []Drive
	for _, c := range cands {
		var s syscall.Statfs_t
		if err := syscall.Statfs(c, &s); err != nil {
			continue
		}
		ok, _ := CheckPathAllowed(c)
		out = append(out, Drive{c, "Mount", uint64(s.Blocks) * uint64(s.Bsize), uint64(s.Bavail) * uint64(s.Bsize), c == "/", ok})
	}
	return out
}

func QuickPlaces() [][2]string {
	h, _ := os.UserHomeDir()
	out := [][2]string{{"Home", h}}
	for _, n := range []string{"Desktop", "Documents", "Downloads", "Pictures"} {
		p := filepath.Join(h, n)
		if st, err := os.Stat(p); err == nil && st.IsDir() {
			out = append(out, [2]string{n, p})
		}
	}
	return out
}

func OpenAppWindow(url string) error {
	for _, b := range []string{"microsoft-edge", "google-chrome", "chromium", "chromium-browser"} {
		if p, err := exec.LookPath(b); err == nil {
			return exec.Command(p, "--app="+url, "--window-size=1280,860").Start()
		}
	}
	if runtime.GOOS == "darwin" {
		return exec.Command("open", url).Start()
	}
	return exec.Command("xdg-open", url).Start()
}
