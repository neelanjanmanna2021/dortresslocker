// Keybulk: the master-password-wrapped Data Master Key (same format as the
// Python edition, so both editions open each other's vaults).
// (c) Dortress Technologies Private Limited
package main

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"runtime"
	"time"
)

type KDFParams struct {
	Alg  string `json:"alg"`
	T    uint32 `json:"t"`
	MKiB uint32 `json:"m_kib"`
	P    uint8  `json:"p"`
}

var DefaultKDF = KDFParams{Alg: "argon2id", T: 3, MKiB: 131072, P: 4}

var (
	ErrWrongPassword = errors.New("wrong master password")
	ErrPolicy        = errors.New("password does not meet the Dortress policy (10 numbers, 3 uppercase, 3 lowercase, 4 special)")
)

type keybulkDoc struct {
	Format     string    `json:"format"`
	V          int       `json:"v"`
	KDF        KDFParams `json:"kdf"`
	Salt       string    `json:"salt"`
	Nonce      string    `json:"nonce"`
	WrappedDMK string    `json:"wrapped_dmk"`
	KeyID      string    `json:"key_id"`
	Created    float64   `json:"created"`
	Updated    float64   `json:"updated"`
}

type Keybulk struct{ Path string }

func AppDataDir() string {
	var base string
	if runtime.GOOS == "windows" {
		base = os.Getenv("APPDATA")
		if base == "" {
			h, _ := os.UserHomeDir()
			base = filepath.Join(h, "AppData", "Roaming")
		}
	} else {
		base = os.Getenv("XDG_CONFIG_HOME")
		if base == "" {
			h, _ := os.UserHomeDir()
			base = filepath.Join(h, ".config")
		}
	}
	d := filepath.Join(base, "DortressLocker")
	_ = os.MkdirAll(d, 0o700)
	return d
}

func NewKeybulk() *Keybulk { return &Keybulk{Path: filepath.Join(AppDataDir(), "keybulk.dkb")} }

func (k *Keybulk) Exists() bool {
	_, err := os.Stat(k.Path)
	return err == nil
}

// keybulkAAD reproduces Python's json.dumps(..., sort_keys=True) byte for byte.
func keybulkAAD(p KDFParams, salt []byte, keyID string) []byte {
	return []byte(fmt.Sprintf(`{"kdf": {"alg": %q, "m_kib": %d, "p": %d, "t": %d}, "key_id": %q, "salt": %q, "v": 1}`,
		p.Alg, p.MKiB, p.P, p.T, keyID, base64.StdEncoding.EncodeToString(salt)))
}

func deriveKEK(password string, salt []byte, p KDFParams) []byte {
	return Argon2idKey([]byte(password), salt, nil, nil, p.T, p.MKiB, p.P, 32)
}

func nowF() float64 { return float64(time.Now().UnixNano()) / 1e9 }

func (k *Keybulk) wrapAndSave(password string, dmk []byte, keyID string, created float64) error {
	p := DefaultKDF
	salt, nonce := randBytes(32), randBytes(12)
	kek := deriveKEK(password, salt, p)
	defer wipe(kek)
	blk, _ := aes.NewCipher(kek)
	g, _ := cipher.NewGCM(blk)
	ct := g.Seal(nil, nonce, dmk, keybulkAAD(p, salt, keyID))
	doc := keybulkDoc{"dortress-keybulk", 1, p, b64(salt), b64(nonce), b64(ct), keyID, created, nowF()}
	data, _ := json.MarshalIndent(doc, "", "  ")
	tmp := k.Path[:len(k.Path)-len(filepath.Ext(k.Path))] + ".tmp"
	f, err := os.OpenFile(tmp, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0o600)
	if err != nil {
		return err
	}
	if _, err = f.Write(data); err == nil {
		err = f.Sync()
	}
	f.Close()
	if err != nil {
		os.Remove(tmp)
		return err
	}
	if k.Exists() {
		_ = os.Rename(k.Path, k.Path[:len(k.Path)-len(filepath.Ext(k.Path))]+".bak")
	}
	return os.Rename(tmp, k.Path)
}

func (k *Keybulk) Create(password string) ([]byte, error) {
	if !PolicyOK(password) {
		return nil, ErrPolicy
	}
	dmk := randBytes(32)
	if err := k.wrapAndSave(password, dmk, hex.EncodeToString(randBytes(8)), nowF()); err != nil {
		return nil, err
	}
	return dmk, nil
}

func (k *Keybulk) load() (*keybulkDoc, error) {
	data, err := os.ReadFile(k.Path)
	if err != nil {
		return nil, err
	}
	var d keybulkDoc
	if err := json.Unmarshal(data, &d); err != nil || d.Format != "dortress-keybulk" {
		return nil, errors.New("not a Dortress keybulk file")
	}
	if d.KDF.T < 1 || d.KDF.T > 64 || d.KDF.MKiB < 8192 || d.KDF.MKiB > 4194304 || d.KDF.P < 1 || d.KDF.P > 64 {
		return nil, errors.New("keybulk has unsafe KDF parameters")
	}
	return &d, nil
}

func (k *Keybulk) Unlock(password string) ([]byte, error) {
	d, err := k.load()
	if err != nil {
		return nil, err
	}
	salt, err1 := unb64(d.Salt)
	nonce, err2 := unb64(d.Nonce)
	ct, err3 := unb64(d.WrappedDMK)
	if err1 != nil || err2 != nil || err3 != nil || len(nonce) != 12 {
		return nil, errors.New("corrupt keybulk")
	}
	kek := deriveKEK(password, salt, d.KDF)
	defer wipe(kek)
	blk, _ := aes.NewCipher(kek)
	g, _ := cipher.NewGCM(blk)
	dmk, err := g.Open(nil, nonce, ct, keybulkAAD(d.KDF, salt, d.KeyID))
	if err != nil {
		return nil, ErrWrongPassword
	}
	return dmk, nil
}

func (k *Keybulk) ChangePassword(old, nw string) error {
	if !PolicyOK(nw) {
		return ErrPolicy
	}
	d, err := k.load()
	if err != nil {
		return err
	}
	dmk, err := k.Unlock(old)
	if err != nil {
		return err
	}
	defer wipe(dmk)
	return k.wrapAndSave(nw, dmk, d.KeyID, d.Created)
}

func (k *Keybulk) KeyID() string {
	d, err := k.load()
	if err != nil {
		return "?"
	}
	return d.KeyID
}

func randBytes(n int) []byte {
	b := make([]byte, n)
	if _, err := rand.Read(b); err != nil {
		panic(err)
	}
	return b
}

func wipe(b []byte) {
	for i := range b {
		b[i] = 0
	}
}

func b64(b []byte) string            { return base64.StdEncoding.EncodeToString(b) }
func unb64(s string) ([]byte, error) { return base64.StdEncoding.DecodeString(s) }
