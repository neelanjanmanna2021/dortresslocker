// Local-only HTTP server that powers the black & gold interface.
// Bound to 127.0.0.1 with a random port and a 256-bit session token.
// (c) Dortress Technologies Private Limited
package main

import (
	"crypto/subtle"
	_ "embed"
	"encoding/json"
	"errors"
	"fmt"
	"math"
	"net/http"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"sync"
	"time"
)

//go:embed web/index.html
var indexHTML []byte

const (
	AppName       = "Dortress Locker"
	Version       = "2.0.0 (Go)"
	Developer     = "Dortress Technologies Private Limited"
	AutoLockAfter = 10 * time.Minute
	ExitIfGone    = 3 * time.Minute
)

type App struct {
	mu           sync.Mutex
	authMu       sync.Mutex
	kb           *Keybulk
	dmk          []byte
	job          *Job
	log          Logger
	token        string
	host         string
	lastMbps     float64
	failCount    int
	lastActivity time.Time
	lastSeen     time.Time
	jobSeq       int64
	quit         chan struct{}
	quitOnce     sync.Once
}

func (a *App) exit() { a.quitOnce.Do(func() { close(a.quit) }) }

func NewApp(token string) *App {
	return &App{kb: NewKeybulk(), token: token, lastActivity: time.Now(), lastSeen: time.Now(), quit: make(chan struct{})}
}

func (a *App) busy() bool { return a.job != nil && a.job.Active() }

func (a *App) lock(reason string) {
	a.mu.Lock()
	defer a.mu.Unlock()
	if a.dmk != nil {
		wipe(a.dmk)
		a.dmk = nil
		a.log.Add("info", "%s", reason)
	}
}

func (a *App) watchdog() {
	for range time.Tick(5 * time.Second) {
		a.mu.Lock()
		busy, unlocked := a.busy(), a.dmk != nil
		idle, gone := time.Since(a.lastActivity), time.Since(a.lastSeen)
		a.mu.Unlock()
		if unlocked && !busy && idle > AutoLockAfter {
			a.lock("Vault auto-locked after inactivity")
		}
		if !busy && gone > ExitIfGone {
			a.lock("Window closed")
			a.exit()
			return
		}
	}
}

// ------------------------------------------------------------- plumbing --
func writeJSON(w http.ResponseWriter, code int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	_ = json.NewEncoder(w).Encode(v)
}

func fail(w http.ResponseWriter, code int, msg string) {
	writeJSON(w, code, map[string]string{"error": msg})
}

func (a *App) secure(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		h := w.Header()
		h.Set("X-Frame-Options", "DENY")
		h.Set("X-Content-Type-Options", "nosniff")
		h.Set("Referrer-Policy", "no-referrer")
		h.Set("Cache-Control", "no-store")
		h.Set("Content-Security-Policy", "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; "+
			"img-src data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'")
		if r.Host != a.host && r.Host != strings.Replace(a.host, "127.0.0.1", "localhost", 1) {
			http.Error(w, "forbidden", http.StatusForbidden) // DNS-rebinding guard
			return
		}
		if r.URL.Path == "/" {
			if t := r.URL.Query().Get("t"); t != "" {
				if subtle.ConstantTimeCompare([]byte(t), []byte(a.token)) == 1 {
					http.SetCookie(w, &http.Cookie{Name: "dl_session", Value: a.token, Path: "/", HttpOnly: true,
						SameSite: http.SameSiteStrictMode})
					http.Redirect(w, r, "/", http.StatusFound)
					return
				}
			}
		}
		c, err := r.Cookie("dl_session")
		if err != nil || subtle.ConstantTimeCompare([]byte(c.Value), []byte(a.token)) != 1 {
			w.Header().Set("Content-Type", "text/html; charset=utf-8")
			w.WriteHeader(http.StatusForbidden)
			fmt.Fprint(w, `<body style="background:#050507;color:#d4af37;font-family:sans-serif;padding:40px">`+
				`<h2>Dortress Locker</h2><p style="color:#8f897a">Please open Dortress Locker from its own program window.</p></body>`)
			return
		}
		if strings.HasPrefix(r.URL.Path, "/api/") && r.Method == http.MethodPost {
			if r.Header.Get("X-Dortress") != "1" {
				fail(w, http.StatusForbidden, "missing request header")
				return
			}
			if o := r.Header.Get("Origin"); o != "" && o != "http://"+r.Host {
				fail(w, http.StatusForbidden, "bad origin")
				return
			}
		}
		a.mu.Lock()
		a.lastSeen = time.Now()
		if r.Method == http.MethodPost || r.Header.Get("X-Active") == "1" {
			a.lastActivity = time.Now()
		}
		a.mu.Unlock()
		next.ServeHTTP(w, r)
	})
}

func readBody(r *http.Request, v any) error {
	r.Body = http.MaxBytesReader(nil, r.Body, 1<<20)
	return json.NewDecoder(r.Body).Decode(v)
}

// --------------------------------------------------------------- routes --
func (a *App) Routes() http.Handler {
	m := http.NewServeMux()
	m.HandleFunc("GET /{$}", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		w.Write(indexHTML)
	})
	m.HandleFunc("GET /api/state", a.hState)
	m.HandleFunc("GET /api/status", a.hStatus)
	m.HandleFunc("POST /api/setup", a.hSetup)
	m.HandleFunc("POST /api/unlock", a.hUnlock)
	m.HandleFunc("POST /api/lock", func(w http.ResponseWriter, r *http.Request) {
		a.mu.Lock()
		busy := a.busy()
		a.mu.Unlock()
		if busy {
			fail(w, 409, "Please wait for the current job to finish.")
			return
		}
		a.lock("Vault locked")
		writeJSON(w, 200, map[string]bool{"ok": true})
	})
	m.HandleFunc("POST /api/change_password", a.hChangePassword)
	m.HandleFunc("POST /api/generate", func(w http.ResponseWriter, r *http.Request) {
		writeJSON(w, 200, map[string]string{"password": GeneratePassword()})
	})
	m.HandleFunc("GET /api/drives", a.needUnlocked(func(w http.ResponseWriter, r *http.Request) {
		writeJSON(w, 200, ListDrives())
	}))
	m.HandleFunc("GET /api/list", a.needUnlocked(a.hList))
	m.HandleFunc("POST /api/job", a.needUnlocked(a.hJob))
	m.HandleFunc("POST /api/job/confirm", a.hConfirm)
	m.HandleFunc("POST /api/job/cancel", func(w http.ResponseWriter, r *http.Request) {
		a.mu.Lock()
		j := a.job
		a.mu.Unlock()
		if j != nil && j.Active() {
			j.cancel.Store(true)
			select {
			case j.confirm <- false:
			default:
			}
			a.log.Add("warn", "Cancelling… files in progress are finished or rolled back safely.")
		}
		writeJSON(w, 200, map[string]bool{"ok": true})
	})
	m.HandleFunc("POST /api/benchmark", func(w http.ResponseWriter, r *http.Request) {
		res := Benchmark(1500 * time.Millisecond)
		a.log.Add("info", "Benchmark: %.0f Mbps AES-256-GCM", res["Mbps"])
		writeJSON(w, 200, res)
	})
	m.HandleFunc("GET /api/backup", a.needUnlocked(func(w http.ResponseWriter, r *http.Request) {
		data, err := os.ReadFile(a.kb.Path)
		if err != nil {
			fail(w, 500, err.Error())
			return
		}
		w.Header().Set("Content-Type", "application/octet-stream")
		w.Header().Set("Content-Disposition", `attachment; filename="dortress-keybulk-backup.dkb"`)
		w.Write(data)
		a.log.Add("ok", "Keybulk backup downloaded")
	}))
	m.HandleFunc("POST /api/quit", func(w http.ResponseWriter, r *http.Request) {
		a.mu.Lock()
		busy := a.busy()
		a.mu.Unlock()
		if busy {
			fail(w, 409, "A job is running. Cancel it first.")
			return
		}
		writeJSON(w, 200, map[string]bool{"ok": true})
		a.lock("Exiting")
		go func() { time.Sleep(300 * time.Millisecond); a.exit() }()
	})
	return a.secure(m)
}

func (a *App) needUnlocked(h http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		a.mu.Lock()
		ok := a.dmk != nil
		a.mu.Unlock()
		if !ok {
			fail(w, 401, "Vault is locked.")
			return
		}
		h(w, r)
	}
}

func (a *App) hState(w http.ResponseWriter, r *http.Request) {
	score, items := PQAssessment()
	a.mu.Lock()
	defer a.mu.Unlock()
	writeJSON(w, 200, map[string]any{
		"app": AppName, "version": Version, "developer": Developer, "vault_exists": a.kb.Exists(),
		"unlocked": a.dmk != nil, "busy": a.busy(), "key_id": a.kb.KeyID(), "keybulk_path": a.kb.Path,
		"cpu": CPU, "system_drive": map[bool]string{true: SystemDrive(), false: "/"}[IsWindows()],
		"windows": IsWindows(), "last_mbps": a.lastMbps, "pq_score": score, "pq_items": items,
		"autolock_min": int(AutoLockAfter.Minutes()),
	})
}

func (a *App) hStatus(w http.ResponseWriter, r *http.Request) {
	var since int64
	fmt.Sscan(r.URL.Query().Get("since"), &since)
	a.mu.Lock()
	j := a.job
	resp := map[string]any{"unlocked": a.dmk != nil, "busy": a.busy(), "last_mbps": a.lastMbps}
	a.mu.Unlock()
	if j != nil {
		resp["job"] = j.snapshot()
	}
	resp["logs"] = a.log.Since(since)
	writeJSON(w, 200, resp)
}

func (a *App) hSetup(w http.ResponseWriter, r *http.Request) {
	var in struct{ Password, Confirm string }
	if readBody(r, &in) != nil {
		fail(w, 400, "bad request")
		return
	}
	a.authMu.Lock()
	defer a.authMu.Unlock()
	if a.kb.Exists() {
		fail(w, 409, "A vault already exists.")
		return
	}
	if in.Password != in.Confirm {
		fail(w, 400, "Passwords do not match.")
		return
	}
	dmk, err := a.kb.Create(in.Password)
	if err != nil {
		fail(w, 400, err.Error())
		return
	}
	a.mu.Lock()
	a.dmk = dmk
	a.mu.Unlock()
	a.log.Add("ok", "Vault created · keybulk %s", a.kb.KeyID())
	writeJSON(w, 200, map[string]bool{"ok": true})
}

func (a *App) hUnlock(w http.ResponseWriter, r *http.Request) {
	var in struct{ Password string }
	if readBody(r, &in) != nil || in.Password == "" {
		fail(w, 400, "Enter your master password.")
		return
	}
	a.authMu.Lock()
	defer a.authMu.Unlock()
	if a.failCount > 0 {
		time.Sleep(time.Duration(math.Min(30, math.Pow(2, float64(a.failCount))-1)) * time.Second)
	}
	dmk, err := a.kb.Unlock(in.Password)
	if err != nil {
		if errors.Is(err, ErrWrongPassword) {
			a.failCount++
			fail(w, 401, "Wrong master password.")
		} else {
			fail(w, 500, err.Error())
		}
		return
	}
	a.failCount = 0
	a.mu.Lock()
	a.dmk = dmk
	a.mu.Unlock()
	a.log.Add("info", "Vault unlocked · keybulk %s", a.kb.KeyID())
	writeJSON(w, 200, map[string]bool{"ok": true})
}

func (a *App) hChangePassword(w http.ResponseWriter, r *http.Request) {
	var in struct{ Current, New, Confirm string }
	if readBody(r, &in) != nil {
		fail(w, 400, "bad request")
		return
	}
	switch {
	case !PolicyOK(in.New):
		fail(w, 400, "New password needs 10 numbers, 3 upper, 3 lower, 4 special.")
		return
	case in.New != in.Confirm:
		fail(w, 400, "New passwords do not match.")
		return
	case in.New == in.Current:
		fail(w, 400, "New password must differ from the current one.")
		return
	}
	a.authMu.Lock()
	defer a.authMu.Unlock()
	if err := a.kb.ChangePassword(in.Current, in.New); err != nil {
		if errors.Is(err, ErrWrongPassword) {
			fail(w, 401, "Current password is wrong.")
		} else {
			fail(w, 500, err.Error())
		}
		return
	}
	a.log.Add("ok", "Master password changed (keybulk re-wrapped)")
	writeJSON(w, 200, map[string]bool{"ok": true})
}

type listEntry struct {
	Name      string `json:"name"`
	Path      string `json:"path"`
	Dir       bool   `json:"dir"`
	Size      int64  `json:"size"`
	Enc       bool   `json:"enc"`
	Protected bool   `json:"protected"`
	Reason    string `json:"reason,omitempty"`
}

func (a *App) hList(w http.ResponseWriter, r *http.Request) {
	p := r.URL.Query().Get("path")
	quick := []map[string]any{}
	for _, d := range ListDrives() {
		label := d.Path
		quick = append(quick, map[string]any{"label": label, "path": d.Path, "drive": true, "protected": !d.Allowed})
	}
	for _, q := range QuickPlaces() {
		if st, err := os.Stat(q[1]); err == nil && st.IsDir() {
			ok, _ := CheckPathAllowed(q[1])
			quick = append(quick, map[string]any{"label": q[0], "path": q[1], "drive": false, "protected": !ok})
		}
	}
	if p == "" {
		writeJSON(w, 200, map[string]any{"path": "", "parent": "", "entries": []listEntry{}, "quick": quick})
		return
	}
	p, _ = filepath.Abs(p)
	ents, err := os.ReadDir(p)
	if err != nil {
		fail(w, 400, "Cannot open folder: "+err.Error())
		return
	}
	dirOK, dirWhy := CheckPathAllowed(p)
	out := []listEntry{}
	for _, e := range ents {
		full := filepath.Join(p, e.Name())
		info, err := e.Info()
		if err != nil {
			continue
		}
		le := listEntry{Name: e.Name(), Path: full, Dir: e.IsDir(), Enc: strings.HasSuffix(strings.ToLower(e.Name()), EXT)}
		if !e.IsDir() {
			le.Size = info.Size()
		}
		if info.Mode()&os.ModeSymlink != 0 {
			le.Protected, le.Reason = true, "symbolic link"
		} else if !dirOK {
			le.Protected, le.Reason = true, dirWhy
		} else if ok, why := CheckPathAllowed(full); !ok {
			le.Protected, le.Reason = true, why
		} else if why := platformSkip(info); why != "" {
			le.Protected, le.Reason = true, why
		}
		out = append(out, le)
	}
	sort.Slice(out, func(i, k int) bool {
		if out[i].Dir != out[k].Dir {
			return out[i].Dir
		}
		return strings.ToLower(out[i].Name) < strings.ToLower(out[k].Name)
	})
	parent := filepath.Dir(p)
	if parent == p {
		parent = ""
	}
	writeJSON(w, 200, map[string]any{"path": p, "parent": parent, "entries": out, "quick": quick,
		"protected": !dirOK, "reason": dirWhy, "sep": string(os.PathSeparator)})
}

func (a *App) hJob(w http.ResponseWriter, r *http.Request) {
	var in struct {
		Mode    string   `json:"mode"`
		Targets []string `json:"targets"`
		Passes  int      `json:"passes"`
	}
	if readBody(r, &in) != nil || len(in.Targets) == 0 {
		fail(w, 400, "Nothing selected.")
		return
	}
	var ok []string
	for _, t := range in.Targets {
		if allowed, why := CheckPathAllowed(t); allowed {
			ok = append(ok, t)
		} else {
			a.log.Add("warn", "Protected location, not touched: %s (%s)", t, why)
		}
	}
	if len(ok) == 0 {
		fail(w, 400, "Everything selected is in a protected location.")
		return
	}
	if _, err := a.StartJob(in.Mode, ok, in.Passes); err != nil {
		fail(w, 409, err.Error())
		return
	}
	writeJSON(w, 200, map[string]bool{"ok": true})
}

func (a *App) hConfirm(w http.ResponseWriter, r *http.Request) {
	var in struct{ Go bool }
	_ = readBody(r, &in)
	a.mu.Lock()
	j := a.job
	a.mu.Unlock()
	if j == nil {
		fail(w, 404, "no job")
		return
	}
	select {
	case j.confirm <- in.Go:
	default:
	}
	writeJSON(w, 200, map[string]bool{"ok": true})
}
