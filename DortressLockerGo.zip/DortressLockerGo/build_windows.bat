@echo off
cd /d "%~dp0"
set CGO_ENABLED=0
go build -trimpath -ldflags "-s -w -H windowsgui" -o dist\DortressLocker.exe .
echo Built: dist\DortressLocker.exe
pause
