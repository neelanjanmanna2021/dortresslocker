// Password policy, strength meter and generator. (c) Dortress Technologies Private Limited
package main

import (
	"crypto/rand"
	"math"
	"math/big"
	"strings"
	"unicode"
)

const Specials = "!@#$%^&*()-_=+[]{};:,.?/<>~|"

var Policy = map[string]int{"digits": 10, "upper": 3, "lower": 3, "special": 4}

type PolicyItem struct {
	Have int  `json:"have"`
	Need int  `json:"need"`
	OK   bool `json:"ok"`
}

func PolicyStatus(pw string) map[string]PolicyItem {
	c := map[string]int{}
	for _, r := range pw {
		switch {
		case unicode.IsDigit(r):
			c["digits"]++
		case unicode.IsUpper(r):
			c["upper"]++
		case unicode.IsLower(r):
			c["lower"]++
		case !unicode.IsLetter(r) && !unicode.IsNumber(r) && !unicode.IsSpace(r):
			c["special"]++
		}
	}
	out := map[string]PolicyItem{}
	for k, need := range Policy {
		out[k] = PolicyItem{c[k], need, c[k] >= need}
	}
	return out
}

func PolicyOK(pw string) bool {
	for _, v := range PolicyStatus(pw) {
		if !v.OK {
			return false
		}
	}
	return true
}

// PasswordStrength mirrors the Python version: (score 0-100, label, bits).
func PasswordStrength(pw string) (int, string, float64) {
	rs := []rune(pw)
	if len(rs) == 0 {
		return 0, "Empty", 0
	}
	pool := 0
	var lo, up, dg, sp bool
	set := map[rune]bool{}
	for _, r := range rs {
		set[r] = true
		switch {
		case unicode.IsLower(r):
			lo = true
		case unicode.IsUpper(r):
			up = true
		case unicode.IsDigit(r):
			dg = true
		}
		if !(unicode.IsLetter(r) || unicode.IsNumber(r)) {
			sp = true
		}
	}
	if lo {
		pool += 26
	}
	if up {
		pool += 26
	}
	if dg {
		pool += 10
	}
	if sp {
		pool += 32
	}
	bits := float64(len(rs)) * math.Log2(math.Max(float64(pool), 2))
	bits *= 0.55 + 0.45*float64(len(set))/float64(len(rs))
	for i := 0; i+2 < len(rs); i++ {
		if rs[i+1]-rs[i] == 1 && rs[i+2]-rs[i+1] == 1 {
			bits -= 4
		}
	}
	low := strings.ToLower(pw)
	for _, bad := range []string{"password", "qwerty", "admin", "dortress", "123456", "letmein", "welcome"} {
		if strings.Contains(low, bad) {
			bits -= 25
		}
	}
	bits = math.Max(bits, 0)
	score := int(math.Min(100, bits/1.3))
	if !PolicyOK(pw) && score > 59 {
		score = 59
	}
	label := "Fortress-grade"
	switch {
	case score < 20:
		label = "Very weak"
	case score < 40:
		label = "Weak"
	case score < 60:
		label = "Fair"
	case score < 80:
		label = "Strong"
	}
	return score, label, bits
}

func randInt(n int) int {
	v, err := rand.Int(rand.Reader, big.NewInt(int64(n)))
	if err != nil {
		panic(err)
	}
	return int(v.Int64())
}

// GeneratePassword: 10 digits + 3 upper + 3 lower + 4 special, CSPRNG-shuffled.
func GeneratePassword() string {
	pick := func(s string, n int) []byte {
		out := make([]byte, n)
		for i := range out {
			out[i] = s[randInt(len(s))]
		}
		return out
	}
	b := append(pick("0123456789", 10), pick("ABCDEFGHIJKLMNOPQRSTUVWXYZ", 3)...)
	b = append(b, pick("abcdefghijklmnopqrstuvwxyz", 3)...)
	b = append(b, pick(Specials, 4)...)
	for i := len(b) - 1; i > 0; i-- {
		j := randInt(i + 1)
		b[i], b[j] = b[j], b[i]
	}
	return string(b)
}
