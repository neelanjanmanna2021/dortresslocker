# Dortress Locker v2.0.0 (Go edition)
**Developed by Dortress Technologies Private Limited**

Same features, look and file formats as the Python edition, now as a single
native program written in Go, using only Go's standard library and no third-party code.

## Run
- **Windows:** double-click `dist\DortressLocker.exe`. It opens in its own app window
  (Microsoft Edge or Chrome app mode). Unsigned, so Windows SmartScreen may ask:
  *More info → Run anyway*. Verify the file against `dist\SHA256SUMS.txt` first.
- **Linux:** `./dist/dortresslocker-linux`
- **Build yourself:** install Go 1.24+, then `build_windows.bat` (or `go build .`).
  Option: `-no-browser` prints the address instead of opening a window.

## Compatible with the Python edition
Both editions use the same keybulk (`%APPDATA%\DortressLocker\keybulk.dkb`) and `.dlock`
format. Files locked by one open in the other, verified in both directions during testing.

## What's inside
| Part | Implementation |
|---|---|
| File encryption | AES-256-GCM, 4 MiB chunks, encrypted in parallel on all CPU cores |
| Integrity | Every chunk authenticated with header, index and final-flag; tampering/truncation rejected |
| Per-file keys | HKDF-SHA256(DMK, random 256-bit salt) |
| Master password | Argon2id (128 MiB, t=3, p=4). Pure-Go implementation, checked against the RFC 9106 test vector and pyca/cryptography |
| Keybulk AEAD | DMK wrapped with AES-256-GCM; password change re-wraps only |
| Shredding | Turbo / 1 / 3 / 7 passes of AES-CTR random data, random rename, delete |
| Protection | System drive, Windows, Program Files, ProgramData, AppData, Recycle Bin, boot/recovery, folders of running programs, in-use files, system files, symlinks and junctions are never touched |
| Memory | Master key bytes are zeroed on lock and exit |

## How the window works
The app runs a private server on `127.0.0.1` (random port) and opens the interface in an app window.
- Only reachable from this computer; never listens on the network
- 256-bit session token, HttpOnly SameSite=Strict cookie
- Host-header check (blocks DNS rebinding), custom request header and Origin check on every action
- Strict Content-Security-Policy; no external scripts, fonts or images
- Auto-lock after 10 minutes idle; the app exits a few minutes after its window is closed (never mid-job)

## Measured on a 2-core Linux test machine (1 GB file)
| | Python v1.1 | Go v2.0 |
|---|---|---|
| Encrypt + 1-pass shred | 2,434 Mbps | 3,118 Mbps |
| Encrypt (Turbo) | 3,887 Mbps | 4,543 Mbps |
| Decrypt | 4,406 Mbps | 5,054 – 5,401 Mbps |
| Raw AES-256-GCM | — | ~70,000 Mbps |

## Honest limits
- File-level encryption, not full-disk encryption like BitLocker; use both for best protection.
- On SSDs/flash, overwriting can't guarantee old blocks are erased (wear-levelling).
- Go's AES cipher keeps its expanded key internally until garbage-collected.
- Not independently audited yet.
