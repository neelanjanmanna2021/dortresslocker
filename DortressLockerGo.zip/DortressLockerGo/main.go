// Dortress Locker - Go edition
// (c) Dortress Technologies Private Limited
//
// Starts a private server on 127.0.0.1 and opens the black & gold interface
// in an app window (Microsoft Edge / Chrome app mode, or the default browser).
package main

import (
	"context"
	"encoding/hex"
	"flag"
	"fmt"
	"net"
	"net/http"
	"os"
	"time"
)

func main() {
	noBrowser := flag.Bool("no-browser", false, "print the URL instead of opening a window")
	port := flag.Int("port", 0, "port to listen on (default: random)")
	flag.Parse()

	ln, err := net.Listen("tcp", fmt.Sprintf("127.0.0.1:%d", *port))
	if err != nil {
		fmt.Fprintln(os.Stderr, "cannot start:", err)
		os.Exit(1)
	}
	token := hex.EncodeToString(randBytes(32))
	app := NewApp(token)
	app.host = ln.Addr().String()
	srv := &http.Server{Handler: app.Routes(), ReadHeaderTimeout: 10 * time.Second}
	go func() { _ = srv.Serve(ln) }()
	go app.watchdog()

	url := fmt.Sprintf("http://%s/?t=%s", app.host, token)
	if *noBrowser {
		fmt.Println(url)
	} else if err := OpenAppWindow(url); err != nil {
		fmt.Println("Open this address in your browser:", url)
	}
	<-app.quit
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel()
	_ = srv.Shutdown(ctx)
}
