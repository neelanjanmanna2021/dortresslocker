//go:build windows

package main

import (
	"os"
	"os/exec"
	"strings"
	"syscall"
	"unsafe"
)

var (
	kernel32         = syscall.NewLazyDLL("kernel32.dll")
	pGetLogical      = kernel32.NewProc("GetLogicalDrives")
	pGetDriveType    = kernel32.NewProc("GetDriveTypeW")
	pGetDiskFree     = kernel32.NewProc("GetDiskFreeSpaceExW")
	pQueryFullImgNam = kernel32.NewProc("QueryFullProcessImageNameW")
)

const (
	attrSystem   = 0x4
	attrReparse  = 0x400
	queryLimited = 0x1000
)

func platformSkip(st os.FileInfo) string {
	if a, ok := st.Sys().(*syscall.Win32FileAttributeData); ok {
		if a.FileAttributes&attrReparse != 0 {
			return "junction/reparse point"
		}
		if a.FileAttributes&attrSystem != 0 {
			return "system file"
		}
	}
	return ""
}

func processExePaths() []string {
	snap, err := syscall.CreateToolhelp32Snapshot(syscall.TH32CS_SNAPPROCESS, 0)
	if err != nil {
		return nil
	}
	defer syscall.CloseHandle(snap)
	var e syscall.ProcessEntry32
	e.Size = uint32(unsafe.Sizeof(e))
	var out []string
	for err = syscall.Process32First(snap, &e); err == nil; err = syscall.Process32Next(snap, &e) {
		h, err := syscall.OpenProcess(queryLimited, false, e.ProcessID)
		if err != nil {
			continue
		}
		buf := make([]uint16, 1024)
		n := uint32(len(buf))
		r, _, _ := pQueryFullImgNam.Call(uintptr(h), 0, uintptr(unsafe.Pointer(&buf[0])), uintptr(unsafe.Pointer(&n)))
		if r != 0 {
			out = append(out, syscall.UTF16ToString(buf[:n]))
		}
		syscall.CloseHandle(h)
	}
	return out
}

func ListDrives() []Drive {
	kinds := map[uintptr]string{2: "Removable", 3: "Fixed", 4: "Network", 5: "CD/DVD", 6: "RAM disk"}
	mask, _, _ := pGetLogical.Call()
	var out []Drive
	for i := 0; i < 26; i++ {
		if mask&(1<<uint(i)) == 0 {
			continue
		}
		letter := string(rune('A' + i))
		root := letter + `:\`
		rp, _ := syscall.UTF16PtrFromString(root)
		t, _, _ := pGetDriveType.Call(uintptr(unsafe.Pointer(rp)))
		kind := kinds[t]
		if kind == "" {
			kind = "Unknown"
		}
		var free, total, tfree uint64
		r, _, _ := pGetDiskFree.Call(uintptr(unsafe.Pointer(rp)), uintptr(unsafe.Pointer(&free)),
			uintptr(unsafe.Pointer(&total)), uintptr(unsafe.Pointer(&tfree)))
		if r == 0 {
			continue
		}
		ok, _ := CheckPathAllowed(root)
		out = append(out, Drive{root, kind, total, free, strings.EqualFold(letter+":", SystemDrive()),
			ok && kind != "Network" && kind != "CD/DVD"})
	}
	return out
}

func QuickPlaces() [][2]string {
	h, _ := os.UserHomeDir()
	var out [][2]string
	for _, n := range []string{"Desktop", "Documents", "Downloads", "Pictures", "Videos"} {
		out = append(out, [2]string{n, h + `\` + n})
	}
	return out
}

func OpenAppWindow(url string) error {
	cands := []string{
		os.Getenv("ProgramFiles(x86)") + `\Microsoft\Edge\Application\msedge.exe`,
		os.Getenv("ProgramFiles") + `\Microsoft\Edge\Application\msedge.exe`,
		os.Getenv("ProgramFiles") + `\Google\Chrome\Application\chrome.exe`,
		os.Getenv("ProgramFiles(x86)") + `\Google\Chrome\Application\chrome.exe`,
		os.Getenv("LocalAppData") + `\Google\Chrome\Application\chrome.exe`,
	}
	for _, c := range cands {
		if _, err := os.Stat(c); err == nil {
			return exec.Command(c, "--app="+url, "--window-size=1280,860", "--new-window").Start()
		}
	}
	return exec.Command("rundll32", "url.dll,FileProtocolHandler", url).Start()
}
