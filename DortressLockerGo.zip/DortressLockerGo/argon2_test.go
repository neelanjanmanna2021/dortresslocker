package main

import (
	"bytes"
	"encoding/hex"
	"testing"
)

func rep(b byte, n int) []byte { return bytes.Repeat([]byte{b}, n) }

func TestBlake2bVector(t *testing.T) {
	// RFC 7693 Appendix A: BLAKE2b-512("abc")
	want := "ba80a53f981c4d0d6a2797b69f12f6e94c212f14685ac4b74b12bb6fdbffa2d17d87c5392aab792dc252d5de4533cc9518d38aa8dbf1925ab92386edd4009923"
	if got := hex.EncodeToString(blake2bSum(64, []byte("abc"))); got != want {
		t.Fatalf("blake2b mismatch %s", got)
	}
}

func TestArgon2idRFC9106(t *testing.T) {
	got := Argon2idKey(rep(1, 32), rep(2, 16), rep(3, 8), rep(4, 12), 3, 32, 4, 32)
	want := "0d640df58d78766c08c037a34a8b53c9d01ef0452d75b65eb52520e96b01e659"
	if hex.EncodeToString(got) != want {
		t.Fatalf("argon2id RFC vector mismatch: %x", got)
	}
}
