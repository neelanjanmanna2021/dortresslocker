// File encryption engine. Byte-compatible with the Python edition's .dlock format.
// (c) Dortress Technologies Private Limited
//
//	header: "DTLK" | ver u8 | flags u8 | salt[32] | base nonce[12] | chunk size u32 (BE)
//	meta  : u32 len | AES-GCM(meta JSON)          nonce index 0, AAD = header|idx|final
//	chunks: AES-GCM(4 MiB) ...                    nonce index i+1, last chunk final=1
//	file key = HKDF-SHA256(DMK, salt, "dortress-locker/file-key/v1")
package main

import (
	"bytes"
	"crypto/aes"
	"crypto/cipher"
	"crypto/hkdf"
	"crypto/sha256"
	"encoding/binary"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

const (
	EXT        = ".dlock"
	Magic      = "DTLK"
	FormatVer  = 1
	ChunkSize  = 4 << 20
	MaxChunk   = 64 << 20
	TagLen     = 16
	HeaderLen  = 4 + 1 + 1 + 32 + 12 + 4
	fileKeyCtx = "dortress-locker/file-key/v1"
)

var (
	CPU         = runtime.NumCPU()
	ErrCanceled = errors.New("cancelled")
	ErrTamper   = errors.New("integrity check failed: file is corrupt, truncated or tampered")
	ErrAuthMeta = errors.New("authentication failed: wrong key or tampered file")
	inflight    = make(chan struct{}, clamp(CPU*4, 8, 32)) // bounds RAM across all files
)

func clamp(v, lo, hi int) int {
	if v < lo {
		return lo
	}
	if v > hi {
		return hi
	}
	return v
}

func fileAEAD(dmk, salt []byte) cipher.AEAD {
	key, err := hkdf.Key(sha256.New, dmk, salt, fileKeyCtx, 32)
	if err != nil {
		panic(err)
	}
	blk, _ := aes.NewCipher(key)
	wipe(key)
	g, _ := cipher.NewGCM(blk)
	return g
}

func chunkNonce(base []byte, idx uint64) []byte {
	n := make([]byte, 12)
	copy(n, base[:4])
	binary.BigEndian.PutUint64(n[4:], binary.BigEndian.Uint64(base[4:])^idx)
	return n
}

func chunkAAD(header []byte, idx uint64, final bool) []byte {
	a := make([]byte, len(header)+9)
	copy(a, header)
	binary.BigEndian.PutUint64(a[len(header):], idx)
	if final {
		a[len(a)-1] = 1
	}
	return a
}

func uniquePath(p string) string {
	if _, err := os.Lstat(p); os.IsNotExist(err) {
		return p
	}
	dir, name := filepath.Split(p)
	ext := filepath.Ext(name)
	stem := strings.TrimSuffix(name, ext)
	if stem == "" {
		stem, ext = name, ""
	}
	for i := 1; ; i++ {
		c := filepath.Join(dir, fmt.Sprintf("%s (%d)%s", stem, i, ext))
		if _, err := os.Lstat(c); os.IsNotExist(err) {
			return c
		}
	}
}

// pipeline reads n records, transforms them in parallel and writes them in order.
func pipeline(n int, recSize int, r io.Reader, fn func(i int, in []byte) ([]byte, error),
	w io.Writer, progress func(int), cancel *atomic.Bool) error {
	type res struct {
		b   []byte
		err error
	}
	type item struct{ ch chan res }
	depth := CPU + 2
	order := make(chan *item, depth)
	stop := make(chan struct{})
	var once sync.Once
	halt := func() { once.Do(func() { close(stop) }) }
	var prodErr error
	go func() {
		defer close(order)
		for i := 0; i < n; i++ {
			if cancel != nil && cancel.Load() {
				prodErr = ErrCanceled
				return
			}
			select {
			case <-stop:
				return
			default:
			}
			in := make([]byte, recSize)
			k, err := io.ReadFull(r, in)
			if err == io.EOF || err == io.ErrUnexpectedEOF {
				err = nil
			}
			if err != nil {
				prodErr = err
				return
			}
			it := &item{ch: make(chan res, 1)}
			inflight <- struct{}{}
			order <- it
			go func(i int, in []byte) {
				defer func() { <-inflight }()
				out, err := fn(i, in)
				it.ch <- res{b: out, err: err}
			}(i, in[:k])
		}
	}()
	var firstErr error
	for it := range order {
		r := <-it.ch
		if firstErr != nil {
			continue
		}
		if r.err != nil {
			firstErr = r.err
			halt()
			continue
		}
		if _, err := w.Write(r.b); err != nil {
			firstErr = err
			halt()
			continue
		}
		if progress != nil {
			progress(len(r.b))
		}
	}
	if firstErr != nil {
		return firstErr
	}
	return prodErr
}

type fileMeta struct {
	Name  string  `json:"name"`
	Size  int64   `json:"size"`
	Mtime float64 `json:"mtime"`
}

func EncryptFile(src string, dmk []byte, progress func(int), shredPasses int, cancel *atomic.Bool) (string, error) {
	st, err := os.Stat(src)
	if err != nil {
		return "", err
	}
	salt, base := randBytes(32), randBytes(12)
	header := make([]byte, HeaderLen)
	copy(header, Magic)
	header[4], header[5] = FormatVer, 0
	copy(header[6:], salt)
	copy(header[38:], base)
	binary.BigEndian.PutUint32(header[50:], ChunkSize)
	aead := fileAEAD(dmk, salt)
	dst := uniquePath(src + EXT)
	tmp := dst + ".part"
	meta, _ := json.Marshal(fileMeta{filepath.Base(src), st.Size(), float64(st.ModTime().UnixNano()) / 1e9})
	nChunks := int((st.Size() + ChunkSize - 1) / ChunkSize)
	if nChunks < 1 {
		nChunks = 1
	}
	fail := func(e error) (string, error) { os.Remove(tmp); return "", e }

	fi, err := os.OpenFile(src, os.O_RDWR, 0) // fails fast on locked / read-only files
	if err != nil {
		return "", err
	}
	defer fi.Close()
	fo, err := os.OpenFile(tmp, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0o600)
	if err != nil {
		return "", err
	}
	mct := aead.Seal(nil, chunkNonce(base, 0), meta, chunkAAD(header, 0, false))
	var hb bytes.Buffer
	hb.Write(header)
	binary.Write(&hb, binary.BigEndian, uint32(len(mct)))
	hb.Write(mct)
	if _, err := fo.Write(hb.Bytes()); err != nil {
		fo.Close()
		return fail(err)
	}
	err = pipeline(nChunks, ChunkSize, fi, func(i int, in []byte) ([]byte, error) {
		final := i == nChunks-1
		if len(in) != ChunkSize && !final {
			return nil, errors.New("file changed while encrypting")
		}
		return aead.Seal(make([]byte, 0, len(in)+TagLen), chunkNonce(base, uint64(i+1)), in, chunkAAD(header, uint64(i+1), final)), nil
	}, fo, func(n int) {
		if progress != nil {
			progress(n - TagLen)
		}
	}, cancel)
	if err == nil {
		var one [1]byte
		if k, _ := fi.Read(one[:]); k > 0 {
			err = errors.New("file grew while encrypting")
		}
	}
	if err == nil {
		err = fo.Sync()
	}
	if cerr := fo.Close(); err == nil {
		err = cerr
	}
	if err != nil {
		return fail(err)
	}
	fi.Close()
	if err := os.Rename(tmp, dst); err != nil {
		return fail(err)
	}
	if err := ShredFile(src, shredPasses); err != nil {
		return dst, fmt.Errorf("encrypted, but could not remove original: %w", err)
	}
	return dst, nil
}

func openHeader(fi *os.File, dmk []byte) (header []byte, aead cipher.AEAD, base []byte, chunk int, err error) {
	header = make([]byte, HeaderLen)
	if _, err = io.ReadFull(fi, header); err != nil {
		return nil, nil, nil, 0, errors.New("not a Dortress file (too short)")
	}
	if string(header[:4]) != Magic {
		return nil, nil, nil, 0, errors.New("not a Dortress Locker file")
	}
	if header[4] != FormatVer {
		return nil, nil, nil, 0, fmt.Errorf("unsupported format version %d", header[4])
	}
	chunk = int(binary.BigEndian.Uint32(header[50:]))
	if chunk < 1024 || chunk > MaxChunk {
		return nil, nil, nil, 0, errors.New("corrupt header")
	}
	return header, fileAEAD(dmk, header[6:38]), header[38:50], chunk, nil
}

func readMeta(fi *os.File, aead cipher.AEAD, base, header []byte) (*fileMeta, error) {
	var l [4]byte
	if _, err := io.ReadFull(fi, l[:]); err != nil {
		return nil, errors.New("corrupt file")
	}
	n := binary.BigEndian.Uint32(l[:])
	if n > 65536 {
		return nil, errors.New("corrupt metadata")
	}
	ct := make([]byte, n)
	if _, err := io.ReadFull(fi, ct); err != nil {
		return nil, ErrAuthMeta
	}
	pt, err := aead.Open(nil, chunkNonce(base, 0), ct, chunkAAD(header, 0, false))
	if err != nil {
		return nil, ErrAuthMeta
	}
	var m fileMeta
	if err := json.Unmarshal(pt, &m); err != nil {
		return nil, errors.New("corrupt metadata")
	}
	return &m, nil
}

func DecryptFile(src string, dmk []byte, progress func(int), cancel *atomic.Bool) (string, error) {
	st, err := os.Stat(src)
	if err != nil {
		return "", err
	}
	fi, err := os.Open(src)
	if err != nil {
		return "", err
	}
	defer fi.Close()
	header, aead, base, chunk, err := openHeader(fi, dmk)
	if err != nil {
		return "", err
	}
	meta, err := readMeta(fi, aead, base, header)
	if err != nil {
		return "", err
	}
	name := filepath.Base(filepath.Clean("/" + strings.ReplaceAll(meta.Name, "\\", "/")))
	if name == "" || name == "." || name == ".." || name == "/" {
		name = strings.TrimSuffix(filepath.Base(src), EXT)
	}
	dst := uniquePath(filepath.Join(filepath.Dir(src), name))
	tmp := dst + ".dlock.part"
	pos, _ := fi.Seek(0, io.SeekCurrent)
	rec := chunk + TagLen
	n := int((st.Size() - pos + int64(rec) - 1) / int64(rec))
	if n < 1 {
		return "", errors.New("truncated file")
	}
	fo, err := os.OpenFile(tmp, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0o600)
	if err != nil {
		return "", err
	}
	var written int64
	err = pipeline(n, rec, fi, func(i int, in []byte) ([]byte, error) {
		pt, err := aead.Open(make([]byte, 0, len(in)), chunkNonce(base, uint64(i+1)), in, chunkAAD(header, uint64(i+1), i == n-1))
		if err != nil {
			return nil, ErrTamper
		}
		return pt, nil
	}, fo, func(k int) {
		written += int64(k)
		if progress != nil {
			progress(k)
		}
	}, cancel)
	if err == nil && written != meta.Size {
		err = errors.New("size mismatch after decryption")
	}
	if err == nil {
		err = fo.Sync()
	}
	if cerr := fo.Close(); err == nil {
		err = cerr
	}
	if err == nil {
		err = os.Rename(tmp, dst)
	}
	if err != nil {
		os.Remove(tmp)
		return "", err
	}
	if meta.Mtime > 0 {
		t := time.Unix(0, int64(meta.Mtime*1e9))
		_ = os.Chtimes(dst, t, t)
	}
	fi.Close()
	if err := os.Remove(src); err != nil {
		return dst, fmt.Errorf("restored, but could not remove locked copy: %w", err)
	}
	return dst, nil
}

// ShredFile overwrites with an AES-CTR keystream (passes>0), renames to a random
// name and deletes. passes == 0 ("Turbo") only renames and deletes.
func ShredFile(path string, passes int) error {
	_ = os.Chmod(path, 0o600)
	if passes > 0 {
		f, err := os.OpenFile(path, os.O_RDWR, 0)
		if err != nil {
			return err
		}
		st, _ := f.Stat()
		size := st.Size()
		zero := make([]byte, ChunkSize)
		buf := make([]byte, ChunkSize)
		for p := 0; p < passes; p++ {
			blk, _ := aes.NewCipher(randBytes(32))
			ctr := cipher.NewCTR(blk, randBytes(16))
			if _, err := f.Seek(0, io.SeekStart); err != nil {
				f.Close()
				return err
			}
			for rem := size; rem > 0; {
				k := int64(ChunkSize)
				if rem < k {
					k = rem
				}
				ctr.XORKeyStream(buf[:k], zero[:k])
				if _, err := f.Write(buf[:k]); err != nil {
					f.Close()
					return err
				}
				rem -= k
			}
			if err := f.Sync(); err != nil {
				f.Close()
				return err
			}
		}
		_ = f.Truncate(0)
		_ = f.Sync()
		f.Close()
	}
	rnd := filepath.Join(filepath.Dir(path), hex.EncodeToString(randBytes(12)))
	if err := os.Rename(path, rnd); err != nil {
		return os.Remove(path)
	}
	return os.Remove(rnd)
}

// Benchmark measures in-memory AES-256-GCM throughput on all cores.
func Benchmark(d time.Duration) map[string]any {
	threads := clamp(CPU, 1, 16)
	key := randBytes(32)
	data := randBytes(ChunkSize)
	var total atomic.Int64
	var stop atomic.Bool
	var wg sync.WaitGroup
	start := time.Now()
	for t := 0; t < threads; t++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			blk, _ := aes.NewCipher(key)
			g, _ := cipher.NewGCM(blk)
			base := randBytes(12)
			out := make([]byte, 0, ChunkSize+TagLen)
			for j := uint64(0); !stop.Load(); j++ {
				out = g.Seal(out[:0], chunkNonce(base, j), data, nil)
				total.Add(ChunkSize)
			}
		}()
	}
	time.Sleep(d)
	stop.Store(true)
	wg.Wait()
	el := time.Since(start).Seconds()
	b := float64(total.Load())
	return map[string]any{"threads": threads, "MBps": b / el / 1e6, "Mbps": b * 8 / el / 1e6}
}

type PQItem struct {
	Text string  `json:"text"`
	Got  float64 `json:"got"`
	Max  float64 `json:"max"`
}

func PQAssessment() (float64, []PQItem) {
	items := []PQItem{
		{"AES-256 symmetric core (Grover's algorithm leaves ~128-bit security)", 2, 2},
		{"No RSA / ECC anywhere in the data path (immune to Shor's algorithm)", 2, 2},
		{"Argon2id memory-hard password KDF (128 MiB, t=3)", 1.5, 1.5},
		{"256-bit keys from the OS CSPRNG, unique key per file (HKDF-SHA256)", 1.5, 1.5},
		{"AEAD with chunk binding: tamper, reorder & truncation detection", 1.5, 1.5},
		{"Key rotation by re-wrapping (keybulk AEAD) without re-encrypting data", 1, 1},
		{"No hybrid ML-KEM (FIPS 203) for sharing keys with other users", 0, 0.5},
	}
	s := 0.0
	for _, i := range items {
		s += i.Got
	}
	return s, items
}

func HumanBytes(n float64) string {
	units := []string{"B", "KB", "MB", "GB", "TB"}
	i := 0
	for n >= 1024 && i < len(units)-1 {
		n /= 1024
		i++
	}
	if i == 0 {
		return fmt.Sprintf("%d B", int64(n))
	}
	return fmt.Sprintf("%.1f %s", n, units[i])
}
