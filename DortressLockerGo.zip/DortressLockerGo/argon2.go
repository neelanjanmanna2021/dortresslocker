// Pure-Go Argon2id (RFC 9106, version 0x13), parallel lanes.
// Validated against the RFC 9106 test vector and pyca/cryptography.
// (c) Dortress Technologies Private Limited
package main

import (
	"encoding/binary"
	"math/bits"
	"sync"
)

const (
	argonVersion   = 0x13
	argonTypeID    = 2 // Argon2id
	argonBlockWord = 128
	argonSyncPts   = 4
)

type argonBlock [argonBlockWord]uint64

func le32(v uint32) []byte {
	b := make([]byte, 4)
	binary.LittleEndian.PutUint32(b, v)
	return b
}

// hPrime is the variable-length hash H' from RFC 9106 section 3.3.
func hPrime(outLen int, parts ...[]byte) []byte {
	in := append([][]byte{le32(uint32(outLen))}, parts...)
	if outLen <= 64 {
		return blake2bSum(outLen, in...)
	}
	out := make([]byte, 0, outLen)
	v := blake2bSum(64, in...)
	out = append(out, v[:32]...)
	r := (outLen+31)/32 - 2
	for i := 1; i < r; i++ {
		v = blake2bSum(64, v)
		out = append(out, v[:32]...)
	}
	v = blake2bSum(outLen-32*r, v)
	return append(out, v...)
}

func fBlaMka(x, y uint64) uint64 {
	return x + y + 2*uint64(uint32(x))*uint64(uint32(y))
}

func argonP(v *argonBlock, i [16]int) {
	gg := func(a, b, c, d int) {
		va, vb, vc, vd := v[i[a]], v[i[b]], v[i[c]], v[i[d]]
		va = fBlaMka(va, vb)
		vd = bits.RotateLeft64(vd^va, -32)
		vc = fBlaMka(vc, vd)
		vb = bits.RotateLeft64(vb^vc, -24)
		va = fBlaMka(va, vb)
		vd = bits.RotateLeft64(vd^va, -16)
		vc = fBlaMka(vc, vd)
		vb = bits.RotateLeft64(vb^vc, -63)
		v[i[a]], v[i[b]], v[i[c]], v[i[d]] = va, vb, vc, vd
	}
	gg(0, 4, 8, 12)
	gg(1, 5, 9, 13)
	gg(2, 6, 10, 14)
	gg(3, 7, 11, 15)
	gg(0, 5, 10, 15)
	gg(1, 6, 11, 12)
	gg(2, 7, 8, 13)
	gg(3, 4, 9, 14)
}

var rowIdx, colIdx [8][16]int

func init() {
	for r := 0; r < 8; r++ {
		for k := 0; k < 16; k++ {
			rowIdx[r][k] = 16*r + k
		}
	}
	for c := 0; c < 8; c++ {
		for k := 0; k < 8; k++ {
			colIdx[c][2*k] = 16*k + 2*c
			colIdx[c][2*k+1] = 16*k + 2*c + 1
		}
	}
}

// compressG computes out = G(x, y); if xorInto, out ^= G(x, y) instead.
func compressG(out, x, y *argonBlock, xorInto bool) {
	var r, z argonBlock
	for i := range r {
		r[i] = x[i] ^ y[i]
	}
	z = r
	for k := 0; k < 8; k++ {
		argonP(&z, rowIdx[k])
	}
	for k := 0; k < 8; k++ {
		argonP(&z, colIdx[k])
	}
	if xorInto {
		for i := range out {
			out[i] ^= z[i] ^ r[i]
		}
	} else {
		for i := range out {
			out[i] = z[i] ^ r[i]
		}
	}
}

func bytesToBlock(b []byte, blk *argonBlock) {
	for i := range blk {
		blk[i] = binary.LittleEndian.Uint64(b[i*8:])
	}
}

// Argon2idKey derives keyLen bytes. memKiB is the memory cost in KiB (= 1 KiB blocks).
func Argon2idKey(password, salt, secret, ad []byte, time, memKiB uint32, lanes uint8, keyLen uint32) []byte {
	p := uint32(lanes)
	if p < 1 || time < 1 || keyLen < 4 {
		panic("argon2: invalid parameters")
	}
	if memKiB < 8*p {
		memKiB = 8 * p
	}
	h0 := blake2bSum(64,
		le32(p), le32(keyLen), le32(memKiB), le32(time), le32(argonVersion), le32(argonTypeID),
		le32(uint32(len(password))), password, le32(uint32(len(salt))), salt,
		le32(uint32(len(secret))), secret, le32(uint32(len(ad))), ad)

	mPrime := 4 * p * (memKiB / (4 * p))
	q := mPrime / p
	segLen := q / argonSyncPts
	B := make([]argonBlock, mPrime)
	idx := func(l, c uint32) uint32 { return l*q + c }

	for l := uint32(0); l < p; l++ {
		bytesToBlock(hPrime(1024, h0, le32(0), le32(l)), &B[idx(l, 0)])
		bytesToBlock(hPrime(1024, h0, le32(1), le32(l)), &B[idx(l, 1)])
	}

	fillSegment := func(pass, slice, lane uint32) {
		dataIndependent := pass == 0 && slice < 2
		var addr, in, zero argonBlock
		if dataIndependent {
			in[0], in[1], in[2], in[3], in[4], in[5] =
				uint64(pass), uint64(lane), uint64(slice), uint64(mPrime), uint64(time), argonTypeID
		}
		nextAddresses := func() {
			in[6]++
			var tmp argonBlock
			compressG(&tmp, &zero, &in, false)
			compressG(&addr, &zero, &tmp, false)
		}
		start := uint32(0)
		if pass == 0 && slice == 0 {
			start = 2
		}
		if dataIndependent && start != 0 {
			nextAddresses()
		}
		for j := start; j < segLen; j++ {
			col := slice*segLen + j
			cur := idx(lane, col)
			prevCol := col - 1
			if col == 0 {
				prevCol = q - 1
			}
			prev := idx(lane, prevCol)
			var rnd uint64
			if dataIndependent {
				if j%argonBlockWord == 0 {
					nextAddresses()
				}
				rnd = addr[j%argonBlockWord]
			} else {
				rnd = B[prev][0]
			}
			j1 := uint64(uint32(rnd))
			refLane := uint32(rnd>>32) % p
			if pass == 0 && slice == 0 {
				refLane = lane
			}
			var area uint64
			sameLane := refLane == lane
			if pass == 0 {
				if sameLane {
					area = uint64(slice*segLen + j - 1)
				} else {
					area = uint64(slice * segLen)
					if j == 0 {
						area--
					}
				}
			} else {
				if sameLane {
					area = uint64(q - segLen + j - 1)
				} else {
					area = uint64(q - segLen)
					if j == 0 {
						area--
					}
				}
			}
			x := (j1 * j1) >> 32
			y := (area * x) >> 32
			rel := area - 1 - y
			startPos := uint64(0)
			if pass != 0 {
				startPos = uint64(((slice + 1) * segLen) % q)
			}
			refCol := uint32((startPos + rel) % uint64(q))
			compressG(&B[cur], &B[prev], &B[idx(refLane, refCol)], pass != 0)
		}
	}

	for pass := uint32(0); pass < time; pass++ {
		for slice := uint32(0); slice < argonSyncPts; slice++ {
			var wg sync.WaitGroup
			for l := uint32(0); l < p; l++ {
				wg.Add(1)
				go func(l uint32) {
					defer wg.Done()
					fillSegment(pass, slice, l)
				}(l)
			}
			wg.Wait()
		}
	}

	var c argonBlock = B[idx(0, q-1)]
	for l := uint32(1); l < p; l++ {
		last := &B[idx(l, q-1)]
		for i := range c {
			c[i] ^= last[i]
		}
	}
	cb := make([]byte, 1024)
	for i := range c {
		binary.LittleEndian.PutUint64(cb[i*8:], c[i])
	}
	out := hPrime(int(keyLen), cb)
	// scrub working memory
	for i := range B {
		B[i] = argonBlock{}
	}
	return out
}
