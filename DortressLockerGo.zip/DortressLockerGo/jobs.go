// Batch jobs: scan -> confirm -> run, with live progress and an activity log.
// (c) Dortress Technologies Private Limited
package main

import (
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"sync"
	"sync/atomic"
	"time"
)

type LogEntry struct {
	Seq   int64  `json:"seq"`
	Time  string `json:"time"`
	Level string `json:"level"`
	Text  string `json:"text"`
}

type Logger struct {
	mu   sync.Mutex
	seq  int64
	ents []LogEntry
}

func (l *Logger) Add(level, format string, a ...any) {
	l.mu.Lock()
	defer l.mu.Unlock()
	l.seq++
	l.ents = append(l.ents, LogEntry{l.seq, time.Now().Format("15:04:05"), level, fmt.Sprintf(format, a...)})
	if len(l.ents) > 800 {
		l.ents = l.ents[len(l.ents)-800:]
	}
}

func (l *Logger) Since(seq int64) []LogEntry {
	l.mu.Lock()
	defer l.mu.Unlock()
	out := []LogEntry{}
	for _, e := range l.ents {
		if e.Seq > seq {
			out = append(out, e)
		}
	}
	return out
}

type Job struct {
	mu        sync.Mutex
	ID        int64
	Mode      string  `json:"mode"`
	Phase     string  `json:"phase"` // scanning | confirm | running | done | failed | cancelled
	Title     string  `json:"title"`
	Files     int     `json:"files"`
	Total     int64   `json:"total"`
	Done      int64   `json:"done"`
	Mbps      float64 `json:"mbps"`
	Current   string  `json:"current"`
	OK        int     `json:"ok"`
	Failed    int     `json:"failed"`
	Skipped   int     `json:"skipped"`
	Seconds   float64 `json:"seconds"`
	Passes    int     `json:"passes"`
	Error     string  `json:"error"`
	files     []string
	confirm   chan bool
	cancel    atomic.Bool
	startedAt time.Time
	done      atomic.Int64
}

func (j *Job) snapshot() map[string]any {
	j.mu.Lock()
	defer j.mu.Unlock()
	done := j.done.Load()
	mbps, secs := j.Mbps, j.Seconds
	if j.Phase == "running" {
		secs = time.Since(j.startedAt).Seconds()
		if secs > 0 {
			mbps = float64(done) * 8 / 1e6 / secs
		}
	}
	return map[string]any{"id": j.ID, "mode": j.Mode, "phase": j.Phase, "title": j.Title, "files": j.Files,
		"total": j.Total, "done": done, "mbps": mbps, "current": j.Current, "ok": j.OK,
		"failed": j.Failed, "skipped": j.Skipped, "seconds": secs, "passes": j.Passes,
		"pass_name": passNames[j.Passes], "error": j.Error}
}

func (j *Job) Active() bool {
	j.mu.Lock()
	defer j.mu.Unlock()
	return j.Phase == "scanning" || j.Phase == "confirm" || j.Phase == "running"
}

func (j *Job) set(f func()) {
	j.mu.Lock()
	f()
	j.mu.Unlock()
}

var passNames = map[int]string{0: "Turbo", 1: "Fast", 3: "Strong", 7: "Paranoid"}

// StartJob scans targets; encryption waits for confirmation before running.
func (a *App) StartJob(mode string, targets []string, passes int) (*Job, error) {
	a.mu.Lock()
	defer a.mu.Unlock()
	if a.dmk == nil {
		return nil, errors.New("vault is locked")
	}
	if a.job != nil && a.job.Active() {
		return nil, errors.New("another job is already running")
	}
	if mode != "encrypt" && mode != "decrypt" {
		return nil, errors.New("bad mode")
	}
	if _, ok := passNames[passes]; !ok {
		passes = 1
	}
	a.jobSeq++
	j := &Job{ID: a.jobSeq, Mode: mode, Phase: "scanning", Title: "Scanning…", Passes: passes, confirm: make(chan bool, 1)}
	a.job = j
	dmk := append([]byte(nil), a.dmk...)
	a.log.Add("info", "Scanning %d location(s) for %s…", len(targets), mode+"ion")
	go a.runJob(j, targets, dmk)
	return j, nil
}

func (a *App) runJob(j *Job, targets []string, dmk []byte) {
	defer wipe(dmk)
	skipped := 0
	files := CollectFiles(targets, j.Mode == "decrypt", func(p, why string) {
		skipped++
		if skipped <= 100 {
			a.log.Add("warn", "Skipped %s  (%s)", p, why)
		}
	})
	if skipped > 100 {
		a.log.Add("warn", "…and %d more skipped", skipped-100)
	}
	var total int64
	for _, f := range files {
		if st, err := os.Stat(f); err == nil {
			total += st.Size()
		}
	}
	j.set(func() { j.files, j.Files, j.Total, j.Skipped = files, len(files), total, skipped })
	if j.cancel.Load() {
		j.set(func() { j.Phase, j.Title = "cancelled", "Cancelled" })
		return
	}
	if len(files) == 0 {
		msg := "No files that can be encrypted were found there."
		if j.Mode == "decrypt" {
			msg = "No locked (.dlock) files were found there."
		}
		j.set(func() { j.Phase, j.Title, j.Error = "done", "Nothing to do", msg })
		a.log.Add("warn", "%s", msg)
		return
	}
	a.log.Add("info", "%d file(s) found · %s", len(files), HumanBytes(float64(total)))
	if j.Mode == "encrypt" {
		j.set(func() { j.Phase, j.Title = "confirm", "Waiting for confirmation" })
		var ok bool
		select {
		case ok = <-j.confirm:
		case <-time.After(30 * time.Minute):
		}
		if !ok || j.cancel.Load() {
			j.set(func() { j.Phase, j.Title = "cancelled", "Cancelled" })
			a.log.Add("warn", "Encryption cancelled before it started.")
			return
		}
	}
	verb := map[string]string{"encrypt": "Encrypting", "decrypt": "Decrypting"}[j.Mode]
	j.set(func() {
		j.Phase, j.Title, j.startedAt = "running", fmt.Sprintf("%s %d file(s)…", verb, len(files)), time.Now()
	})
	workers := clamp(CPU*2, 4, 8)
	work := make(chan string)
	var wg sync.WaitGroup
	var okN, failN, skipN atomic.Int64
	for w := 0; w < workers; w++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for fp := range work {
				name := filepath.Base(fp)
				j.set(func() { j.Current = name })
				prog := func(n int) { j.done.Add(int64(n)) }
				var out string
				var err error
				if j.Mode == "encrypt" {
					out, err = EncryptFile(fp, dmk, prog, j.Passes, &j.cancel)
				} else {
					out, err = DecryptFile(fp, dmk, prog, &j.cancel)
				}
				switch {
				case err == nil:
					okN.Add(1)
					if j.Mode == "encrypt" {
						a.log.Add("ok", "Locked: %s", out)
					} else {
						a.log.Add("ok", "Unlocked: %s", out)
					}
				case errors.Is(err, ErrCanceled) || j.cancel.Load():
					skipN.Add(1)
				case os.IsPermission(err):
					skipN.Add(1)
					a.log.Add("warn", "Skipped (in use / no permission): %s", fp)
				default:
					failN.Add(1)
					a.log.Add("err", "Failed: %s - %v", fp, err)
				}
			}
		}()
	}
	for _, f := range files {
		if j.cancel.Load() {
			skipN.Add(1)
			continue
		}
		work <- f
	}
	close(work)
	wg.Wait()
	el := time.Since(j.startedAt).Seconds()
	done := j.done.Load()
	mbps := 0.0
	if el > 0 {
		mbps = float64(done) * 8 / 1e6 / el
	}
	phase, title := "done", "Done"
	if j.cancel.Load() {
		phase, title = "cancelled", "Cancelled"
	}
	j.set(func() {
		j.Phase, j.Title, j.Seconds, j.Mbps, j.Current = phase, title, el, mbps, ""
		j.OK, j.Failed, j.Skipped = int(okN.Load()), int(failN.Load()), j.Skipped+int(skipN.Load())
	})
	if done > 0 {
		a.mu.Lock()
		a.lastMbps = mbps
		a.mu.Unlock()
	}
	lvl := "ok"
	if failN.Load() > 0 {
		lvl = "warn"
	}
	past := map[string]string{"encrypt": "encrypted", "decrypt": "decrypted"}[j.Mode]
	a.log.Add(lvl, "%d file(s) %s · %s in %.1fs at %.0f Mbps · %d failed · %d skipped",
		okN.Load(), past, HumanBytes(float64(done)), el, mbps, failN.Load(), j.Skipped)
}
