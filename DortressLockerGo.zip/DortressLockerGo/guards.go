// Safety guards: never touch the system drive, Windows, or folders of running programs.
// (c) Dortress Technologies Private Limited
package main

import (
	"io/fs"
	"os"
	"path/filepath"
	"runtime"
	"sort"
	"strings"
	"sync"
	"time"
)

var protectedNames = map[string]bool{
	"windows": true, "program files": true, "program files (x86)": true, "programdata": true,
	"$recycle.bin": true, "system volume information": true, "recovery": true, "boot": true, "efi": true,
	"$windows.~bt": true, "$windows.~ws": true, "windowsapps": true, "appdata": true, "msocache": true,
	"pagefile.sys": true, "hiberfil.sys": true, "swapfile.sys": true, "bootmgr": true,
	"dumpstack.log.tmp": true, "config.msi": true, "perflogs": true, "intel": true, "amd": true, "nvidia": true,
}

var posixProtected = []string{
	"/bin", "/boot", "/dev", "/etc", "/lib", "/lib32", "/lib64", "/proc", "/run", "/sbin", "/sys",
	"/usr", "/var", "/opt", "/snap", "/srv", "/root", "/System", "/Library", "/Applications", "/private",
}

var (
	procMu    sync.Mutex
	procAt    time.Time
	procCache []string
)

func IsWindows() bool { return runtime.GOOS == "windows" }

func SystemDrive() string {
	if s := os.Getenv("SystemDrive"); s != "" {
		return strings.ToUpper(s)
	}
	return "C:"
}

func normcase(p string) string {
	if IsWindows() {
		return strings.ToLower(filepath.Clean(p))
	}
	return filepath.Clean(p)
}

func runningProcessDirs() []string {
	procMu.Lock()
	defer procMu.Unlock()
	if time.Since(procAt) < 30*time.Second {
		return procCache
	}
	set := map[string]bool{}
	for _, exe := range processExePaths() {
		if exe != "" {
			set[normcase(filepath.Dir(exe))] = true
		}
	}
	procCache = procCache[:0]
	for d := range set {
		procCache = append(procCache, d)
	}
	sort.Strings(procCache)
	procAt = time.Now()
	return procCache
}

func pathParts(p string) []string {
	var parts []string
	for _, s := range strings.FieldsFunc(p, func(r rune) bool { return r == '/' || r == '\\' }) {
		parts = append(parts, strings.ToLower(s))
	}
	return parts
}

func CheckPathAllowed(path string) (bool, string) {
	p, err := filepath.Abs(path)
	if err != nil {
		return false, "invalid path"
	}
	if IsWindows() {
		vol := filepath.VolumeName(p)
		if vol == "" || strings.HasPrefix(vol, `\\`) {
			return false, "Network/UNC paths are not supported"
		}
		if strings.EqualFold(vol, SystemDrive()) {
			return false, "System drive " + SystemDrive() + " is never touched"
		}
	} else {
		if p == "/" {
			return false, "Filesystem root is protected"
		}
		for _, root := range posixProtected {
			if p == root || strings.HasPrefix(p, root+"/") {
				return false, "System location " + root + " is protected"
			}
		}
	}
	for _, part := range pathParts(p) {
		if protectedNames[part] {
			return false, "Protected system folder '" + part + "'"
		}
	}
	app := normcase(AppDataDir())
	np := normcase(p)
	if np == app || strings.HasPrefix(np, app+string(os.PathSeparator)) {
		return false, "Dortress Locker's own vault is protected"
	}
	for _, d := range runningProcessDirs() {
		if np == d || strings.HasPrefix(np, d+string(os.PathSeparator)) {
			return false, "Folder belongs to a running program/service"
		}
	}
	return true, "ok"
}

// skipEntry reports why a path must not be processed (symlink, junction, system file).
func skipEntry(path string) string {
	st, err := os.Lstat(path)
	if err != nil {
		return "cannot read"
	}
	if st.Mode()&os.ModeSymlink != 0 {
		return "symbolic link"
	}
	return platformSkip(st)
}

func CollectFiles(targets []string, wantEncrypted bool, onSkip func(p, why string)) []string {
	var out []string
	seen := map[string]bool{}
	consider := func(fp string) {
		key := normcase(fp)
		if seen[key] {
			return
		}
		seen[key] = true
		low := strings.ToLower(fp)
		if strings.HasSuffix(low, EXT+".part") {
			return
		}
		if wantEncrypted != strings.HasSuffix(low, EXT) {
			return
		}
		if ok, why := CheckPathAllowed(fp); !ok {
			onSkip(fp, why)
			return
		}
		if r := skipEntry(fp); r != "" {
			onSkip(fp, r)
			return
		}
		out = append(out, fp)
	}
	for _, t := range targets {
		t, _ = filepath.Abs(t)
		if ok, why := CheckPathAllowed(t); !ok {
			onSkip(t, why)
			continue
		}
		st, err := os.Stat(t)
		if err != nil {
			onSkip(t, "not found")
			continue
		}
		if !st.IsDir() {
			consider(t)
			continue
		}
		_ = filepath.WalkDir(t, func(p string, d fs.DirEntry, err error) error {
			if err != nil {
				onSkip(p, "cannot read")
				if d != nil && d.IsDir() {
					return fs.SkipDir
				}
				return nil
			}
			if d.IsDir() {
				if p == t {
					return nil
				}
				if ok, why := CheckPathAllowed(p); !ok {
					onSkip(p, why)
					return fs.SkipDir
				}
				if r := skipEntry(p); r != "" {
					onSkip(p, r)
					return fs.SkipDir
				}
				return nil
			}
			if d.Type()&fs.ModeSymlink != 0 {
				onSkip(p, "symbolic link")
				return nil
			}
			if d.Type().IsRegular() {
				consider(p)
			}
			return nil
		})
	}
	return out
}

type Drive struct {
	Path     string `json:"path"`
	Type     string `json:"type"`
	Total    uint64 `json:"total"`
	Free     uint64 `json:"free"`
	IsSystem bool   `json:"is_system"`
	Allowed  bool   `json:"allowed"`
}
